package com.skymesh.editor;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 材质表：That Sky Level 的材质 ID -> 名称 -> 显示颜色 映射。
 * 颜色表参照 SkyModelViewer-Android 的 LevelMeshesReader.MATERIAL_COLORS。
 * 使用 256 项数组，未映射的索引默认为 (0.7, 0.7, 0.7) 灰色。
 */
public final class MaterialTable {

    public static final class MaterialEntry {
        public final int id;
        public final String name;
        public final float r, g, b;

        public MaterialEntry(int id, String name, float r, float g, float b) {
            this.id = id;
            this.name = name;
            this.r = r;
            this.g = g;
            this.b = b;
        }
    }

    private static volatile MaterialTable instance;

    private final Map<Integer, MaterialEntry> nameMap = new LinkedHashMap<>();
    /** 256 项颜色表，索引即材质 ID */
    private final float[][] colors = new float[256][3];

    private MaterialTable() {
        // 默认所有材质为灰色 (0.7, 0.7, 0.7) — 与参考项目一致
        for (int i = 0; i < 256; i++) {
            colors[i] = new float[]{0.7f, 0.7f, 0.7f};
        }

        // 材质颜色表 — 完全参照 SkyModelViewer-Android LevelMeshesReader.MATERIAL_COLORS
        set(0, "None", 0.5f, 0.5f, 0.5f);
        set(2, "Transparent", 0.6f, 0.7f, 0.8f);
        set(3, "Void", 0.2f, 0.2f, 0.2f);
        set(4, "Particle", 0.9f, 0.8f, 0.6f);
        set(5, "WoodSlippery", 0.6f, 0.45f, 0.3f);
        set(6, "VoidMinor", 0.3f, 0.3f, 0.3f);
        set(7, "WoodPlank", 0.65f, 0.5f, 0.35f);
        set(16, "Cliff", 0.55f, 0.5f, 0.45f);
        set(17, "Soil", 0.6f, 0.5f, 0.35f);
        set(18, "CliffLight", 0.65f, 0.6f, 0.5f);
        set(19, "WallDamaged", 0.4f, 0.35f, 0.3f);
        set(20, "Wall", 0.5f, 0.5f, 0.55f);
        set(21, "Gold", 0.9f, 0.8f, 0.3f);
        set(22, "Glacier", 0.7f, 0.85f, 0.95f);
        set(23, "TileCeiling", 0.8f, 0.8f, 0.85f);
        set(24, "TileFloor", 0.75f, 0.75f, 0.8f);
        set(25, "TileWall", 0.7f, 0.7f, 0.75f);
        set(26, "WallBrick", 0.6f, 0.45f, 0.35f);
        set(27, "SoilWet", 0.4f, 0.35f, 0.25f);
        set(28, "CliffWet", 0.35f, 0.35f, 0.35f);
        set(29, "Bone", 0.85f, 0.85f, 0.8f);
        set(30, "Wood", 0.6f, 0.45f, 0.3f);
        set(31, "Ceramics", 0.8f, 0.7f, 0.6f);
        set(32, "Sand", 0.85f, 0.78f, 0.55f);
        set(33, "SandWet", 0.7f, 0.65f, 0.45f);
        set(34, "SandLight", 0.9f, 0.85f, 0.65f);
        set(35, "Snow", 0.95f, 0.95f, 0.98f);
        set(36, "SandDeep", 0.75f, 0.68f, 0.45f);
        set(37, "Mud", 0.45f, 0.4f, 0.3f);
        set(48, "Grass", 0.4f, 0.6f, 0.3f);
        set(49, "GrassWet", 0.3f, 0.5f, 0.25f);
        set(50, "GrassLight", 0.5f, 0.7f, 0.35f);
        set(51, "GrassMoss", 0.35f, 0.55f, 0.3f);
        set(52, "Cloth", 0.7f, 0.5f, 0.5f);
        set(80, "Cloud", 0.9f, 0.9f, 1.0f);
    }

    private void set(int id, String name, float r, float g, float b) {
        colors[id] = new float[]{r, g, b};
        nameMap.put(id, new MaterialEntry(id, name, r, g, b));
    }

    public static MaterialTable instance() {
        if (instance == null) {
            synchronized (MaterialTable.class) {
                if (instance == null) {
                    instance = new MaterialTable();
                }
            }
        }
        return instance;
    }

    /** 按材质 ID 取颜色，未知返回默认灰 (0.7, 0.7, 0.7)。out 为长度 3 的数组，也可传 null 新建。 */
    public float[] color(int id, float[] out) {
        if (out == null) out = new float[3];
        if (id < 0 || id >= 256) {
            out[0] = 0.7f; out[1] = 0.7f; out[2] = 0.7f;
            return out;
        }
        float[] c = colors[id];
        out[0] = c[0]; out[1] = c[1]; out[2] = c[2];
        return out;
    }

    public String name(int id) {
        MaterialEntry e = nameMap.get(id);
        return e != null ? e.name : ("Unknown_" + id);
    }

    public Map<Integer, MaterialEntry> all() {
        return nameMap;
    }

    /** 从名称反查 ID，找不到返回 48 (Grass) */
    public int idFromName(String name) {
        if (name == null) return 48;
        for (MaterialEntry e : nameMap.values()) {
            if (e.name.equalsIgnoreCase(name)) return e.id;
        }
        return 48;
    }
}
