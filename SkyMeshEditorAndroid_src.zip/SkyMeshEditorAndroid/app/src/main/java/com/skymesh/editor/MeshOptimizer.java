package com.skymesh.editor;

import java.util.Arrays;

/**
 * MeshOptimizer - meshoptimizer 顶点缓冲区编解码器的 Java 标量(scalar)实现。
 * 从 C++ vertexcodec.cpp 的标量解码路径移植，处理 Java byte 有符号的问题。
 *
 * 解码器支持 version 0 和 version 1 格式。
 * 编码器使用简化实现：version 1，所有通道使用 channel 0 (u8 zigzag)，所有控制位使用 literal (ctrl=3)。
 */
public class MeshOptimizer {

    // ======================== 常量 ========================

    static final int kVertexHeader = 0xa0;
    static final int kVertexBlockSizeBytes = 8192;
    static final int kVertexBlockMaxSize = 256;
    static final int kByteGroupSize = 16;
    static final int kByteGroupDecodeLimit = 24;
    static final int kTailMinSizeV0 = 32;
    static final int kTailMinSizeV1 = 24;
    static final int kDecodeVertexVersion = 1;

    static final int[] kBitsV0 = {0, 2, 4, 8};
    static final int[] kBitsV1 = {0, 1, 2, 4, 8};

    // ======================== 辅助函数 ========================

    /** 循环左移：(v << r) | (v >>> ((32 - r) & 31)) */
    static int rotate(int v, int r) {
        return (v << r) | (v >>> ((32 - r) & 31));
    }

    /** unzigzag8：(0 - (v & 1)) ^ (v >>> 1)，结果为 0-255 的无符号值 */
    static int unzigzag8(int v) {
        v &= 0xFF;
        return ((0 - (v & 1)) ^ (v >>> 1)) & 0xFF;
    }

    /** unzigzag16：(0 - (v & 1)) ^ (v >>> 1)，结果为 0-65535 的无符号值 */
    static int unzigzag16(int v) {
        v &= 0xFFFF;
        return ((0 - (v & 1)) ^ (v >>> 1)) & 0xFFFF;
    }

    /** zigzag8：(0 - (v >>> 7)) ^ (v << 1)，结果为 0-255 的无符号值 */
    static int zigzag8(int v) {
        v &= 0xFF;
        return ((0 - (v >>> 7)) ^ (v << 1)) & 0xFF;
    }

    /** 反转一个字节的 8 个 bit */
    static int reverseBits8(int b) {
        b &= 0xFF;
        b = ((b & 0xF0) >>> 4) | ((b & 0x0F) << 4);
        b = ((b & 0xCC) >>> 2) | ((b & 0x33) << 2);
        b = ((b & 0xAA) >>> 1) | ((b & 0x55) << 1);
        return b & 0xFF;
    }

    /** 计算每个顶点块的最大顶点数 */
    static int getVertexBlockSize(int vertexSize) {
        int result = (kVertexBlockSizeBytes / vertexSize) & ~(kByteGroupSize - 1);
        return (result < kVertexBlockMaxSize) ? result : kVertexBlockMaxSize;
    }

    // ======================== 解码器 ========================

    /**
     * 解码一个 16 字节的字节组。
     *
     * @param data        输入数据
     * @param dataOffset  输入数据起始偏移
     * @param buffer      输出缓冲区
     * @param bufferOffset 输出缓冲区起始偏移
     * @param bits        每个值的比特数 (0, 1, 2, 4, 8)
     * @return 新的数据偏移，或 -1 表示错误
     */
    private static int decodeBytesGroup(byte[] data, int dataOffset,
                                        byte[] buffer, int bufferOffset, int bits) {
        switch (bits) {
            case 0:
                // 全零
                Arrays.fill(buffer, bufferOffset, bufferOffset + kByteGroupSize, (byte) 0);
                return dataOffset;

            case 1: {
                // 2 字节头 + 变长数据
                // 每个 header 字节包含 8 个 1-bit 值（bit 顺序反转）
                int dataVar = dataOffset + 2;
                int sentinel = 1; // (1 << 1) - 1
                for (int group = 0; group < 2; group++) {
                    int byteVal = reverseBits8(data[dataOffset + group] & 0xFF);
                    for (int i = 0; i < 8; i++) {
                        int enc = (byteVal >>> 7) & 1;
                        byteVal = (byteVal << 1) & 0xFF;
                        if (enc == sentinel) {
                            buffer[bufferOffset++] = data[dataVar++];
                        } else {
                            buffer[bufferOffset++] = (byte) enc;
                        }
                    }
                }
                return dataVar;
            }

            case 2: {
                // 4 字节头 + 变长数据
                // 每个 header 字节包含 4 个 2-bit 值
                int dataVar = dataOffset + 4;
                int sentinel = 3; // (1 << 2) - 1
                for (int group = 0; group < 4; group++) {
                    int byteVal = data[dataOffset + group] & 0xFF;
                    for (int i = 0; i < 4; i++) {
                        int enc = (byteVal >>> 6) & 3;
                        byteVal = (byteVal << 2) & 0xFF;
                        if (enc == sentinel) {
                            buffer[bufferOffset++] = data[dataVar++];
                        } else {
                            buffer[bufferOffset++] = (byte) enc;
                        }
                    }
                }
                return dataVar;
            }

            case 4: {
                // 8 字节头 + 变长数据
                // 每个 header 字节包含 2 个 4-bit 值
                int dataVar = dataOffset + 8;
                int sentinel = 0x0F; // (1 << 4) - 1
                for (int group = 0; group < 8; group++) {
                    int byteVal = data[dataOffset + group] & 0xFF;
                    for (int i = 0; i < 2; i++) {
                        int enc = (byteVal >>> 4) & 0x0F;
                        byteVal = (byteVal << 4) & 0xFF;
                        if (enc == sentinel) {
                            buffer[bufferOffset++] = data[dataVar++];
                        } else {
                            buffer[bufferOffset++] = (byte) enc;
                        }
                    }
                }
                return dataVar;
            }

            case 8:
                // 直接拷贝 16 字节
                System.arraycopy(data, dataOffset, buffer, bufferOffset, kByteGroupSize);
                return dataOffset + kByteGroupSize;

            default:
                return -1; // 不应该到达
        }
    }

    /**
     * 解码字节序列。
     *
     * @param data        输入数据
     * @param dataOffset  输入数据起始偏移
     * @param dataEnd     输入数据结束偏移（不包含）
     * @param buffer      输出缓冲区
     * @param bufferOffset 输出缓冲区起始偏移
     * @param bufferSize  要解码的字节数（必须是 kByteGroupSize 的倍数）
     * @param bits        比特数表（4 个元素）
     * @return 新的数据偏移，或 -1 表示错误
     */
    private static int decodeBytes(byte[] data, int dataOffset, int dataEnd,
                                   byte[] buffer, int bufferOffset, int bufferSize, int[] bits) {
        int headerSize = (bufferSize / kByteGroupSize + 3) / 4;
        if (dataEnd - dataOffset < headerSize) return -1;

        int headerStart = dataOffset;
        dataOffset += headerSize;

        for (int i = 0; i < bufferSize; i += kByteGroupSize) {
            if (dataEnd - dataOffset < kByteGroupDecodeLimit) return -1;

            int headerOffset = i / kByteGroupSize;
            int bitsk = (data[headerStart + headerOffset / 4] >> ((headerOffset % 4) * 2)) & 3;

            dataOffset = decodeBytesGroup(data, dataOffset, buffer, bufferOffset + i, bits[bitsk]);
            if (dataOffset < 0) return -1;
        }

        return dataOffset;
    }

    /**
     * 解码 delta（通道 0：u8 zigzag）。
     * buffer 布局：4 个通道，每个 vertexCount 字节。
     * 输出到 transposed，按顶点交错。
     */
    private static void decodeDeltas1U8(byte[] buffer, int bufferOffset,
                                        byte[] transposed, int targetOffset,
                                        int vertexCount, int vertexSize,
                                        byte[] lastVertex, int lastVertexOffset) {
        for (int k = 0; k < 4; k++) {
            int vertexOffset = k;
            int p = lastVertex[lastVertexOffset + k] & 0xFF;

            for (int i = 0; i < vertexCount; i++) {
                int v = buffer[bufferOffset + i] & 0xFF;
                v = (unzigzag8(v) + p) & 0xFF;
                transposed[targetOffset + vertexOffset] = (byte) v;
                p = v;
                vertexOffset += vertexSize;
            }
            bufferOffset += vertexCount;
        }
    }

    /**
     * 解码 delta（通道 1：u16 zigzag）。
     * buffer 布局：2 组（k=0, k=2），每组 2*vertexCount 字节。
     */
    private static void decodeDeltas1U16(byte[] buffer, int bufferOffset,
                                         byte[] transposed, int targetOffset,
                                         int vertexCount, int vertexSize,
                                         byte[] lastVertex, int lastVertexOffset) {
        for (int k = 0; k < 4; k += 2) {
            int vertexOffset = k;
            int p = (lastVertex[lastVertexOffset + k] & 0xFF) |
                    ((lastVertex[lastVertexOffset + k + 1] & 0xFF) << 8);

            for (int i = 0; i < vertexCount; i++) {
                int v = (buffer[bufferOffset + i] & 0xFF) |
                        ((buffer[bufferOffset + vertexCount + i] & 0xFF) << 8);
                v = (unzigzag16(v) + p) & 0xFFFF;
                transposed[targetOffset + vertexOffset] = (byte) v;
                transposed[targetOffset + vertexOffset + 1] = (byte) (v >>> 8);
                p = v;
                vertexOffset += vertexSize;
            }
            bufferOffset += vertexCount * 2;
        }
    }

    /**
     * 解码 delta（通道 2：u32 rotate xor）。
     * buffer 布局：1 组（k=0），4*vertexCount 字节。
     */
    private static void decodeDeltas1U32(byte[] buffer, int bufferOffset,
                                         byte[] transposed, int targetOffset,
                                         int vertexCount, int vertexSize,
                                         byte[] lastVertex, int lastVertexOffset, int rot) {
        int vertexOffset = 0;
        int p = (lastVertex[lastVertexOffset] & 0xFF) |
                ((lastVertex[lastVertexOffset + 1] & 0xFF) << 8) |
                ((lastVertex[lastVertexOffset + 2] & 0xFF) << 16) |
                ((lastVertex[lastVertexOffset + 3] & 0xFF) << 24);

        for (int i = 0; i < vertexCount; i++) {
            int v = (buffer[bufferOffset + i] & 0xFF) |
                    ((buffer[bufferOffset + vertexCount + i] & 0xFF) << 8) |
                    ((buffer[bufferOffset + 2 * vertexCount + i] & 0xFF) << 16) |
                    ((buffer[bufferOffset + 3 * vertexCount + i] & 0xFF) << 24);
            v = rotate(v, rot) ^ p;
            transposed[targetOffset + vertexOffset] = (byte) v;
            transposed[targetOffset + vertexOffset + 1] = (byte) (v >>> 8);
            transposed[targetOffset + vertexOffset + 2] = (byte) (v >>> 16);
            transposed[targetOffset + vertexOffset + 3] = (byte) (v >>> 24);
            p = v;
            vertexOffset += vertexSize;
        }
    }

    /**
     * 解码一个顶点块。
     *
     * @param data            输入数据
     * @param dataOffset      输入数据起始偏移
     * @param dataEnd         输入数据结束偏移
     * @param vertexData      输出顶点数据
     * @param vertexDataOffset 输出顶点数据起始偏移
     * @param vertexCount     本块顶点数
     * @param vertexSize      每顶点字节数
     * @param lastVertex      上一个顶点（会被更新）
     * @param channels        通道配置（version 0 时为 null）
     * @param version         格式版本
     * @return 新的数据偏移，或 -1 表示错误
     */
    private static int decodeVertexBlock(byte[] data, int dataOffset, int dataEnd,
                                         byte[] vertexData, int vertexDataOffset,
                                         int vertexCount, int vertexSize,
                                         byte[] lastVertex, byte[] channels, int version) {
        byte[] deltaBuffer = new byte[kVertexBlockMaxSize * 4];  // 1024
        byte[] transposed = new byte[kVertexBlockSizeBytes];      // 8192

        int vertexCountAligned = (vertexCount + kByteGroupSize - 1) & ~(kByteGroupSize - 1);

        int controlSize = version == 0 ? 0 : vertexSize / 4;
        if (dataEnd - dataOffset < controlSize) return -1;

        int controlStart = dataOffset;
        dataOffset += controlSize;

        for (int k = 0; k < vertexSize; k += 4) {
            int ctrlByte = version == 0 ? 0 : data[controlStart + k / 4] & 0xFF;

            for (int j = 0; j < 4; j++) {
                int ctrl = (ctrlByte >> (j * 2)) & 3;

                if (ctrl == 3) {
                    // literal encoding：直接拷贝 vertexCount 字节
                    if (dataEnd - dataOffset < vertexCount) return -1;
                    System.arraycopy(data, dataOffset, deltaBuffer, j * vertexCount, vertexCount);
                    dataOffset += vertexCount;
                } else if (ctrl == 2) {
                    // zero encoding：全零
                    Arrays.fill(deltaBuffer, j * vertexCount, j * vertexCount + vertexCount, (byte) 0);
                } else {
                    // encodeBytes：ctrl 为 0 或 1
                    int[] bits;
                    if (version == 0) {
                        bits = kBitsV0;
                    } else {
                        // kBitsV1 + ctrl：取 kBitsV1[ctrl..ctrl+3]
                        bits = new int[]{kBitsV1[ctrl], kBitsV1[ctrl + 1], kBitsV1[ctrl + 2], kBitsV1[ctrl + 3]};
                    }
                    dataOffset = decodeBytes(data, dataOffset, dataEnd,
                            deltaBuffer, j * vertexCount, vertexCountAligned, bits);
                    if (dataOffset < 0) return -1;
                }
            }

            int channel = version == 0 ? 0 : (channels[k / 4] & 0xFF);
            int channelType = channel & 3;

            switch (channelType) {
                case 0:
                    decodeDeltas1U8(deltaBuffer, 0, transposed, k,
                            vertexCount, vertexSize, lastVertex, k);
                    break;
                case 1:
                    decodeDeltas1U16(deltaBuffer, 0, transposed, k,
                            vertexCount, vertexSize, lastVertex, k);
                    break;
                case 2:
                    int rot = (32 - (channel >> 4)) & 31;
                    decodeDeltas1U32(deltaBuffer, 0, transposed, k,
                            vertexCount, vertexSize, lastVertex, k, rot);
                    break;
                default:
                    return -1; // 无效通道类型
            }
        }

        // 拷贝转置后的数据到输出
        System.arraycopy(transposed, 0, vertexData, vertexDataOffset, vertexCount * vertexSize);

        // 更新 lastVertex 为本块最后一个顶点
        System.arraycopy(transposed, vertexSize * (vertexCount - 1), lastVertex, 0, vertexSize);

        return dataOffset;
    }

    /**
     * 解码顶点缓冲区。
     *
     * @param destination 输出缓冲区，大小为 vertexCount * vertexSize
     * @param vertexCount 顶点数
     * @param vertexSize  每顶点字节数（必须是 4 的倍数，1-256）
     * @param buffer      编码后的数据
     * @param bufferSize  编码数据大小
     * @return 0 成功，负数表示错误
     */
    public static int decodeVertexBuffer(byte[] destination, int vertexCount, int vertexSize,
                                         byte[] buffer, int bufferSize) {
        if (vertexSize <= 0 || vertexSize > 256 || vertexSize % 4 != 0) return -1;

        int dataOffset = 0;
        int dataEnd = bufferSize;

        if (dataEnd - dataOffset < 1) return -2;

        int dataHeader = buffer[dataOffset++] & 0xFF;

        if ((dataHeader & 0xf0) != kVertexHeader) return -1;

        int version = dataHeader & 0x0f;
        if (version > kDecodeVertexVersion) return -1;

        int tailSize = vertexSize + (version == 0 ? 0 : vertexSize / 4);
        int tailSizeMin = version == 0 ? kTailMinSizeV0 : kTailMinSizeV1;
        int tailSizePad = tailSize < tailSizeMin ? tailSizeMin : tailSize;

        if (dataEnd - dataOffset < tailSizePad) return -2;

        int tail = dataEnd - tailSize;

        // 从 tail 读取 last_vertex（第一个顶点的数据）
        byte[] lastVertex = new byte[256];
        System.arraycopy(buffer, tail, lastVertex, 0, vertexSize);

        // 读取 channels
        byte[] channels = null;
        if (version != 0) {
            channels = new byte[vertexSize / 4];
            System.arraycopy(buffer, tail + vertexSize, channels, 0, vertexSize / 4);
        }

        int vertexBlockSize = getVertexBlockSize(vertexSize);

        int vertexOffset = 0;
        while (vertexOffset < vertexCount) {
            int blockSize = (vertexOffset + vertexBlockSize < vertexCount)
                    ? vertexBlockSize : vertexCount - vertexOffset;

            int result = decodeVertexBlock(buffer, dataOffset, dataEnd,
                    destination, vertexOffset * vertexSize,
                    blockSize, vertexSize, lastVertex, channels, version);
            if (result < 0) return -2;

            dataOffset = result;
            vertexOffset += blockSize;
        }

        if (dataEnd - dataOffset != tailSizePad) return -3;

        return 0;
    }

    /**
     * 检测编码数据的版本。
     *
     * @param buffer     编码数据
     * @param bufferSize 数据大小
     * @return 版本号 (0 或 1)，或 -1 表示无效
     */
    public static int decodeVertexVersion(byte[] buffer, int bufferSize) {
        if (bufferSize < 1) return -1;

        int header = buffer[0] & 0xFF;

        if ((header & 0xf0) != kVertexHeader) return -1;

        int version = header & 0x0f;
        if (version > kDecodeVertexVersion) return -1;

        return version;
    }

    // ======================== 编码器（简化实现） ========================

    /**
     * 计算编码后数据的最大大小。
     *
     * @param vertexCount 顶点数
     * @param vertexSize  每顶点字节数
     * @return 最大编码大小
     */
    public static int encodeVertexBufferBound(int vertexCount, int vertexSize) {
        int vertexBlockSize = getVertexBlockSize(vertexSize);
        int vertexBlockCount = (vertexCount + vertexBlockSize - 1) / vertexBlockSize;

        int vertexBlockControlSize = vertexSize / 4;
        int vertexBlockHeaderSize = (vertexBlockSize / kByteGroupSize + 3) / 4;
        int vertexBlockDataSize = vertexBlockSize;

        int tailSize = vertexSize + (vertexSize / 4);
        int tailSizeMin = Math.max(kTailMinSizeV0, kTailMinSizeV1);
        int tailSizePad = Math.max(tailSize, tailSizeMin);

        return 1 + vertexBlockCount * vertexSize *
                (vertexBlockControlSize + vertexBlockHeaderSize + vertexBlockDataSize) + tailSizePad;
    }

    /**
     * 编码顶点缓冲区（简化实现）。
     * 使用 version 1，所有通道使用 channel 0 (u8 zigzag)，所有控制位使用 literal (ctrl=3)。
     *
     * @param buffer      输出缓冲区，大小至少为 encodeVertexBufferBound 返回值
     * @param bufferSize  输出缓冲区大小
     * @param vertices    顶点数据
     * @param vertexCount 顶点数
     * @param vertexSize  每顶点字节数
     * @return 编码后大小，或 0 表示错误
     */
    public static int encodeVertexBuffer(byte[] buffer, int bufferSize,
                                         byte[] vertices, int vertexCount, int vertexSize) {
        if (vertexSize <= 0 || vertexSize > 256 || vertexSize % 4 != 0) return 0;

        int version = 1;

        if (bufferSize < 1) return 0;

        int offset = 0;
        buffer[offset++] = (byte) (kVertexHeader | version);  // 0xa1

        // 保存第一个顶点
        byte[] firstVertex = new byte[256];
        byte[] lastVertex = new byte[256];
        if (vertexCount > 0) {
            System.arraycopy(vertices, 0, firstVertex, 0, vertexSize);
            System.arraycopy(firstVertex, 0, lastVertex, 0, vertexSize);
        }

        // 所有通道使用 channel 0 (u8 zigzag)
        byte[] channels = new byte[vertexSize / 4];  // 全 0

        int vertexBlockSize = getVertexBlockSize(vertexSize);
        int vertexOffset = 0;

        byte[] deltaBuffer = new byte[kVertexBlockMaxSize];

        while (vertexOffset < vertexCount) {
            int blockSize = (vertexOffset + vertexBlockSize < vertexCount)
                    ? vertexBlockSize : vertexCount - vertexOffset;

            // 写控制字节：全部 0xFF（每个 2-bit 字段为 3 = literal）
            int controlSize = vertexSize / 4;
            for (int i = 0; i < controlSize; i++) {
                buffer[offset++] = (byte) 0xFF;
            }

            // 对每个字节 k，计算 zigzag delta 并直接写入（literal encoding）
            for (int k = 0; k < vertexSize; k++) {
                int p = lastVertex[k] & 0xFF;
                int baseOffset = vertexOffset * vertexSize + k;

                for (int i = 0; i < blockSize; i++) {
                    int v = vertices[baseOffset + i * vertexSize] & 0xFF;
                    int d = (v - p) & 0xFF;       // 无符号字节减法
                    int z = zigzag8(d);            // zigzag 编码
                    deltaBuffer[i] = (byte) z;
                    p = v;
                }

                // literal：直接拷贝 blockSize 字节
                System.arraycopy(deltaBuffer, 0, buffer, offset, blockSize);
                offset += blockSize;
            }

            // 更新 lastVertex 为本块最后一个顶点
            if (blockSize > 0) {
                System.arraycopy(vertices, (vertexOffset + blockSize - 1) * vertexSize,
                        lastVertex, 0, vertexSize);
            }

            vertexOffset += blockSize;
        }

        // 写 tail
        int tailSize = vertexSize + vertexSize / 4;
        int tailSizeMin = kTailMinSizeV1;  // version 1
        int tailSizePad = Math.max(tailSize, tailSizeMin);

        // 填充
        for (int i = 0; i < tailSizePad - tailSize; i++) {
            buffer[offset++] = 0;
        }

        // 第一个顶点
        System.arraycopy(firstVertex, 0, buffer, offset, vertexSize);
        offset += vertexSize;

        // channels
        System.arraycopy(channels, 0, buffer, offset, vertexSize / 4);
        offset += vertexSize / 4;

        return offset;
    }
}
