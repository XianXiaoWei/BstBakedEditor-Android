package com.skymesh.editor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 主 Activity。纯 Android 框架 API，无 AndroidX 依赖，无 lambda 表达式。
 * 负责: 场景初始化、面板(左/右)展开收起、工具/笔刷选择、导入导出、摇杆/方向键控制。
 */
public class MainActivity extends Activity implements GLRenderer.Callback {

    private static final int REQ_IMPORT_MESHES = 1;
    private static final int REQ_IMPORT_OBJ = 2;
    private static final int REQ_EXPORT = 3;

    private EditorGLView glView;
    private GLRenderer renderer;
    private Scene scene;

    // 面板
    private View leftPanel;
    private View rightPanel;

    // 状态栏
    private TextView statusInfo;

    // 左面板 - 物体列表
    private LinearLayout objectListContainer;

    // 左面板 - 属性
    private EditText etObjectName;
    private EditText etPosX, etPosY, etPosZ;
    private EditText etRotX, etRotY, etRotZ;
    private EditText etScaleX, etScaleY, etScaleZ;
    private SeekBar seekBrushStrength;

    // 右面板 - 数据可视化
    private TextView tvDataInfo;
    private TextView tvCloudInfo;
    private TextView tvVertexInfo;
    private TextView tvMetaInfo;

    // 可视化模式按钮
    private Button btnVisMaterial, btnVisCloud, btnVisNormal, btnVisAo;
    private Button btnVisDetail, btnVisMisc, btnVisWireframe, btnVisChunk;

    // 摇杆
    private JoystickView joystick;
    private float joystickX = 0, joystickY = 0;
    private boolean joystickActive = false;
    private final Handler joystickHandler = new Handler();
    private final Runnable joystickRunnable = new Runnable() {
        @Override
        public void run() {
            if (joystickActive && (Math.abs(joystickX) > 0.01f || Math.abs(joystickY) > 0.01f)) {
                renderer.getCamera().moveByJoystick(joystickX, joystickY);
                glView.requestRender();
                updateStatus();
                joystickHandler.postDelayed(this, 33);
            }
        }
    };

    // 上下移动按钮 (长按持续)
    private final Handler zoomHandler = new Handler();
    private final Runnable zoomInRunnable = new Runnable() {
        @Override
        public void run() {
            float speed = (float) (renderer.getCamera().getDistance() * 0.05);
            renderer.getCamera().moveVertical(0.3f, speed);
            glView.requestRender();
            updateStatus();
            zoomHandler.postDelayed(this, 33);
        }
    };
    private final Runnable zoomOutRunnable = new Runnable() {
        @Override
        public void run() {
            float speed = (float) (renderer.getCamera().getDistance() * 0.05);
            renderer.getCamera().moveVertical(-0.3f, speed);
            glView.requestRender();
            updateStatus();
            zoomHandler.postDelayed(this, 33);
        }
    };

    private boolean syncing = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        scene = new Scene();
        scene.add(MeshFactory.createPlane("Ground", 16));
        scene.selected = -1;

        glView = (EditorGLView) findViewById(R.id.editor_gl_view);
        renderer = glView.getRenderer();
        renderer.setScene(scene);
        renderer.setCallback(this);

        // 绑定视图
        leftPanel = findViewById(R.id.left_panel);
        rightPanel = findViewById(R.id.right_panel);
        statusInfo = (TextView) findViewById(R.id.status_info);
        objectListContainer = (LinearLayout) findViewById(R.id.object_list_container);
        etObjectName = (EditText) findViewById(R.id.et_object_name);
        etPosX = (EditText) findViewById(R.id.et_pos_x);
        etPosY = (EditText) findViewById(R.id.et_pos_y);
        etPosZ = (EditText) findViewById(R.id.et_pos_z);
        etRotX = (EditText) findViewById(R.id.et_rot_x);
        etRotY = (EditText) findViewById(R.id.et_rot_y);
        etRotZ = (EditText) findViewById(R.id.et_rot_z);
        etScaleX = (EditText) findViewById(R.id.et_scale_x);
        etScaleY = (EditText) findViewById(R.id.et_scale_y);
        etScaleZ = (EditText) findViewById(R.id.et_scale_z);
        seekBrushStrength = (SeekBar) findViewById(R.id.seek_brush_strength);
        tvDataInfo = (TextView) findViewById(R.id.tv_data_info);
        tvCloudInfo = (TextView) findViewById(R.id.tv_cloud_info);
        tvVertexInfo = (TextView) findViewById(R.id.tv_vertex_info);
        tvMetaInfo = (TextView) findViewById(R.id.tv_meta_info);
        btnVisMaterial = (Button) findViewById(R.id.btn_vis_material);
        btnVisCloud = (Button) findViewById(R.id.btn_vis_cloud);
        btnVisNormal = (Button) findViewById(R.id.btn_vis_normal);
        btnVisAo = (Button) findViewById(R.id.btn_vis_ao);
        btnVisDetail = (Button) findViewById(R.id.btn_vis_detail);
        btnVisMisc = (Button) findViewById(R.id.btn_vis_misc);
        btnVisWireframe = (Button) findViewById(R.id.btn_vis_wireframe);
        btnVisChunk = (Button) findViewById(R.id.btn_vis_chunk);
        joystick = (JoystickView) findViewById(R.id.joystick);

        setupPanelToggles();
        setupToolButtons();
        setupBrushTypeButtons();
        setupImportExportButtons();
        setupPrimitiveButtons();
        setupCameraButtons();
        setupJoystick();
        setupSeekBar();
        setupInspectorButtons();
        setupVisButtons();

        // 相机移动时更新状态栏 (辅助显示)
        glView.setOnCameraMoveListener(new EditorGLView.OnCameraMoveListener() {
            @Override
            public void onCameraMove() {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        updateStatus();
                    }
                });
            }
        });

        updateToolButtonHighlight();
        onSelectionChanged();
    }

    // ======================== 面板展开/收起 ========================

    private void setupPanelToggles() {
        // 左面板
        findViewById(R.id.btn_left_expand).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leftPanel.setVisibility(View.VISIBLE);
                findViewById(R.id.btn_left_expand).setVisibility(View.GONE);
            }
        });
        findViewById(R.id.btn_left_collapse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                leftPanel.setVisibility(View.GONE);
                findViewById(R.id.btn_left_expand).setVisibility(View.VISIBLE);
            }
        });
        // 右面板
        findViewById(R.id.btn_right_expand).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rightPanel.setVisibility(View.VISIBLE);
                findViewById(R.id.btn_right_expand).setVisibility(View.GONE);
            }
        });
        findViewById(R.id.btn_right_collapse).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                rightPanel.setVisibility(View.GONE);
                findViewById(R.id.btn_right_expand).setVisibility(View.VISIBLE);
            }
        });
    }

    // ======================== 工具按钮 ========================

    private void setupToolButtons() {
        findViewById(R.id.btn_tool_select).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setTool(GLRenderer.Tool.SELECT); }
        });
        findViewById(R.id.btn_tool_move).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setTool(GLRenderer.Tool.MOVE); }
        });
        findViewById(R.id.btn_tool_rotate).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setTool(GLRenderer.Tool.ROTATE); }
        });
        findViewById(R.id.btn_tool_scale).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setTool(GLRenderer.Tool.SCALE); }
        });
        findViewById(R.id.btn_tool_brush).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                setTool(GLRenderer.Tool.BRUSH);
                if (renderer.getBrushType() == GLRenderer.BrushType.MATERIAL) {
                    showMaterialDialog();
                }
            }
        });
    }

    private void setTool(GLRenderer.Tool tool) {
        renderer.setTool(tool);
        glView.requestRender();
        updateStatus();
        updateToolButtonHighlight();
    }

    private void updateToolButtonHighlight() {
        GLRenderer.Tool t = renderer.getTool();
        int activeBg = 0xFF3D3D50;
        int activeText = 0xFFE0E0F0;
        int normalBg = 0xFF2D2D3D;
        int normalText = 0xFFA0A0B0;

        int[] toolBtns = {
            R.id.btn_tool_select, R.id.btn_tool_move, R.id.btn_tool_rotate,
            R.id.btn_tool_scale, R.id.btn_tool_brush
        };
        GLRenderer.Tool[] tools = {
            GLRenderer.Tool.SELECT, GLRenderer.Tool.MOVE, GLRenderer.Tool.ROTATE,
            GLRenderer.Tool.SCALE, GLRenderer.Tool.BRUSH
        };
        for (int i = 0; i < toolBtns.length; i++) {
            Button btn = (Button) findViewById(toolBtns[i]);
            if (btn == null) continue;
            boolean active = (tools[i] == t);
            btn.setBackgroundColor(active ? activeBg : normalBg);
            btn.setTextColor(active ? activeText : normalText);
        }
    }

    // ======================== 笔刷类型 ========================

    private void setupBrushTypeButtons() {
        findViewById(R.id.btn_brush_material).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renderer.setBrushType(GLRenderer.BrushType.MATERIAL);
                renderer.setTool(GLRenderer.Tool.BRUSH);
                showMaterialDialog();
                updateStatus();
                glView.requestRender();
            }
        });
        findViewById(R.id.btn_brush_raise).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renderer.setBrushType(GLRenderer.BrushType.SCULPT_RAISE);
                renderer.setTool(GLRenderer.Tool.BRUSH);
                updateStatus();
                glView.requestRender();
                toast("凸起笔刷: 拖动网格表面使顶点沿法线凸起");
            }
        });
        findViewById(R.id.btn_brush_lower).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                renderer.setBrushType(GLRenderer.BrushType.SCULPT_LOWER);
                renderer.setTool(GLRenderer.Tool.BRUSH);
                updateStatus();
                glView.requestRender();
                toast("凹陷笔刷: 拖动网格表面使顶点沿法线凹陷");
            }
        });
    }

    // ======================== 材质选择对话框 ========================

    private void showMaterialDialog() {
        MaterialTable mt = MaterialTable.instance();
        final List<MaterialTable.MaterialEntry> entries = new ArrayList<MaterialTable.MaterialEntry>(mt.all().values());
        String[] names = new String[entries.size()];
        for (int i = 0; i < entries.size(); i++) {
            names[i] = entries.get(i).name + " (" + entries.get(i).id + ")";
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("选择笔刷材质");
        builder.setItems(names, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                renderer.setBrushMaterial(entries.get(which).id);
                updateStatus();
                glView.requestRender();
            }
        });
        builder.show();
    }

    // ======================== 导入/导出按钮 ========================

    private void setupImportExportButtons() {
        findViewById(R.id.btn_import_meshes).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQ_IMPORT_MESHES);
            }
        });
        findViewById(R.id.btn_import_obj).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.setType("*/*");
                startActivityForResult(intent, REQ_IMPORT_OBJ);
            }
        });
        findViewById(R.id.btn_export).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE, "scene.meshes");
                startActivityForResult(intent, REQ_EXPORT);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_MESHES) {
            importMeshes(uri);
        } else if (requestCode == REQ_IMPORT_OBJ) {
            importObj(uri);
        } else if (requestCode == REQ_EXPORT) {
            exportMeshes(uri);
        }
    }

    // ======================== 添加几何体按钮 ========================

    private void setupPrimitiveButtons() {
        findViewById(R.id.btn_add_cube).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { addPrimitive("Cube", 0); }
        });
        findViewById(R.id.btn_add_sphere).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { addPrimitive("Sphere", 1); }
        });
        findViewById(R.id.btn_add_cylinder).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { addPrimitive("Cylinder", 2); }
        });
        findViewById(R.id.btn_add_plane).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { addPrimitive("Plane", 3); }
        });
    }

    private void addPrimitive(String baseName, int type) {
        String name = baseName + scene.objects.size();
        SceneObject obj;
        switch (type) {
            case 0: obj = MeshFactory.createCube(name); break;
            case 1: obj = MeshFactory.createSphere(name); break;
            case 2: obj = MeshFactory.createCylinder(name); break;
            default: obj = MeshFactory.createPlane(name); break;
        }
        scene.add(obj);
        renderer.markDirty();
        glView.requestRender();
        onSelectionChanged();
    }

    // ======================== 摇杆 ========================

    private void setupJoystick() {
        joystick.setOnJoystickListener(new JoystickView.OnJoystickListener() {
            @Override
            public void onMove(float x, float y) {
                joystickX = x;
                // y 取反: 摇杆向上 = y 负值 → 相机前进
                joystickY = -y;
                if (!joystickActive) {
                    joystickActive = true;
                    joystickHandler.post(joystickRunnable);
                }
            }
            @Override
            public void onRelease() {
                joystickActive = false;
                joystickX = 0;
                joystickY = 0;
                joystickHandler.removeCallbacks(joystickRunnable);
            }
        });
    }

    // ======================== 上下移动按钮 (长按持续) ========================

    private void setupCameraButtons() {
        Button btnUp = (Button) findViewById(R.id.btn_cam_up);
        Button btnDown = (Button) findViewById(R.id.btn_cam_down);

        btnUp.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        zoomHandler.post(zoomInRunnable);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        zoomHandler.removeCallbacks(zoomInRunnable);
                        return true;
                }
                return false;
            }
        });
        btnDown.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        zoomHandler.post(zoomOutRunnable);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        zoomHandler.removeCallbacks(zoomOutRunnable);
                        return true;
                }
                return false;
            }
        });
    }

    // ======================== 笔刷大小 SeekBar ========================

    private void setupSeekBar() {
        seekBrushStrength.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                renderer.setBrushRadius(1.0f + progress * 0.3f);
            }
            @Override
            public void onStartTrackingTouch(SeekBar sb) {}
            @Override
            public void onStopTrackingTouch(SeekBar sb) {}
        });
        renderer.setBrushRadius(1.0f + seekBrushStrength.getProgress() * 0.3f);
    }

    // ======================== 属性面板按钮 ========================

    private void setupInspectorButtons() {
        findViewById(R.id.btn_apply_transform).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { applyTransform(); }
        });
        findViewById(R.id.btn_delete_object).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                scene.deleteSelected();
                renderer.markDirty();
                glView.requestRender();
                onSelectionChanged();
            }
        });
    }

    // ======================== 可视化模式按钮 ========================

    private void setupVisButtons() {
        btnVisMaterial.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.MATERIAL); }
        });
        btnVisCloud.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.CLOUD); }
        });
        btnVisNormal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.NORMAL); }
        });
        btnVisAo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.AO); }
        });
        btnVisDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.DETAIL); }
        });
        btnVisMisc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.MISC); }
        });
        btnVisWireframe.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.WIREFRAME); }
        });
        btnVisChunk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { setVisMode(GLRenderer.VisMode.CHUNK); }
        });
        updateVisButtonHighlight();
    }

    private void setVisMode(GLRenderer.VisMode mode) {
        renderer.setVisMode(mode);
        updateVisButtonHighlight();
        refreshDataPanel();
        glView.requestRender();
        toast("可视化模式: " + visModeName(mode));
    }

    private String visModeName(GLRenderer.VisMode mode) {
        switch (mode) {
            case MATERIAL: return "地形材质/纹理";
            case CLOUD: return "云数据";
            case NORMAL: return "法线";
            case AO: return "AO/粗糙度";
            case DETAIL: return "细节纹理";
            case MISC: return "其他数据";
            case WIREFRAME: return "网格线框";
            case CHUNK: return "分块边界";
            default: return "未知";
        }
    }

    private void updateVisButtonHighlight() {
        GLRenderer.VisMode vm = renderer.getVisMode();
        int normalBg = 0xFF2D2D3D;
        int activeBg = 0xFF4760A0;
        int normalText = 0xFFA0A0B0;
        int activeText = 0xFFFFFFFF;

        btnVisMaterial.setBackgroundColor(vm == GLRenderer.VisMode.MATERIAL ? activeBg : normalBg);
        btnVisMaterial.setTextColor(vm == GLRenderer.VisMode.MATERIAL ? activeText : normalText);
        btnVisCloud.setBackgroundColor(vm == GLRenderer.VisMode.CLOUD ? activeBg : normalBg);
        btnVisCloud.setTextColor(vm == GLRenderer.VisMode.CLOUD ? activeText : normalText);
        btnVisNormal.setBackgroundColor(vm == GLRenderer.VisMode.NORMAL ? activeBg : normalBg);
        btnVisNormal.setTextColor(vm == GLRenderer.VisMode.NORMAL ? activeText : normalText);
        btnVisAo.setBackgroundColor(vm == GLRenderer.VisMode.AO ? activeBg : normalBg);
        btnVisAo.setTextColor(vm == GLRenderer.VisMode.AO ? activeText : normalText);
        btnVisDetail.setBackgroundColor(vm == GLRenderer.VisMode.DETAIL ? activeBg : normalBg);
        btnVisDetail.setTextColor(vm == GLRenderer.VisMode.DETAIL ? activeText : normalText);
        btnVisMisc.setBackgroundColor(vm == GLRenderer.VisMode.MISC ? activeBg : normalBg);
        btnVisMisc.setTextColor(vm == GLRenderer.VisMode.MISC ? activeText : normalText);
        btnVisWireframe.setBackgroundColor(vm == GLRenderer.VisMode.WIREFRAME ? activeBg : normalBg);
        btnVisWireframe.setTextColor(vm == GLRenderer.VisMode.WIREFRAME ? activeText : normalText);
        btnVisChunk.setBackgroundColor(vm == GLRenderer.VisMode.CHUNK ? activeBg : normalBg);
        btnVisChunk.setTextColor(vm == GLRenderer.VisMode.CHUNK ? activeText : normalText);
    }

    // ======================== 生命周期 ========================

    @Override
    protected void onResume() {
        super.onResume();
        glView.onResume();
    }

    @Override
    protected void onPause() {
        joystickHandler.removeCallbacks(joystickRunnable);
        zoomHandler.removeCallbacks(zoomInRunnable);
        zoomHandler.removeCallbacks(zoomOutRunnable);
        glView.onPause();
        super.onPause();
    }

    // ======================== GLRenderer.Callback ========================

    @Override
    public void onSelectionChanged() {
        refreshOutliner();
        refreshInspector();
        refreshDataPanel();
        updateStatus();
        glView.requestRender();
    }

    @Override
    public void onObjectEdited() {
        refreshInspector();
        refreshDataPanel();
        updateStatus();
        glView.requestRender();
    }

    // ======================== 物体列表 (大纲) ========================

    private void refreshOutliner() {
        objectListContainer.removeAllViews();
        if (scene.objects.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("暂无物体，点击添加");
            empty.setGravity(Gravity.CENTER);
            empty.setPadding(0, 48, 0, 48);
            empty.setTextColor(0xFFA0A0B0);
            objectListContainer.addView(empty);
            return;
        }
        for (int i = 0; i < scene.objects.size(); i++) {
            final SceneObject obj = scene.objects.get(i);
            String prefix;
            if (obj.kind == ObjKind.MeshesTerrain) prefix = "[Mesh] ";
            else if (obj.kind == ObjKind.Imported) prefix = "[Import] ";
            else prefix = "[Prim] ";

            TextView tv = new TextView(this);
            tv.setText(prefix + obj.name);
            tv.setPadding(24, 24, 24, 24);
            tv.setTextSize(14);
            final int idx = i;
            if (idx == scene.selected) {
                tv.setBackgroundColor(0xFF4760A0);
                tv.setTextColor(0xFFFFFFFF);
            } else {
                tv.setTextColor(0xFFD0D0E0);
            }
            tv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    scene.selected = idx;
                    renderer.markDirty();
                    glView.requestRender();
                    onSelectionChanged();
                }
            });
            objectListContainer.addView(tv);
        }
    }

    // ======================== 属性面板 ========================

    private void refreshInspector() {
        SceneObject obj = scene.selectedObject();
        if (obj == null) {
            etObjectName.setText("");
            etPosX.setText(""); etPosY.setText(""); etPosZ.setText("");
            etRotX.setText(""); etRotY.setText(""); etRotZ.setText("");
            etScaleX.setText(""); etScaleY.setText(""); etScaleZ.setText("");
            return;
        }
        syncing = true;
        etObjectName.setText(obj.name);
        etPosX.setText(fmt(obj.position.x));
        etPosY.setText(fmt(obj.position.y));
        etPosZ.setText(fmt(obj.position.z));
        etRotX.setText(fmt(obj.rotation.x));
        etRotY.setText(fmt(obj.rotation.y));
        etRotZ.setText(fmt(obj.rotation.z));
        etScaleX.setText(fmt(obj.scale.x));
        etScaleY.setText(fmt(obj.scale.y));
        etScaleZ.setText(fmt(obj.scale.z));
        syncing = false;
    }

    private void applyTransform() {
        if (syncing) return;
        SceneObject obj = scene.selectedObject();
        if (obj == null) {
            Toast.makeText(this, "未选中物体", Toast.LENGTH_SHORT).show();
            return;
        }
        String newName = etObjectName.getText().toString().trim();
        if (!newName.isEmpty()) obj.name = newName;

        obj.position.x = parse(etPosX, obj.position.x);
        obj.position.y = parse(etPosY, obj.position.y);
        obj.position.z = parse(etPosZ, obj.position.z);
        obj.rotation.x = parse(etRotX, obj.rotation.x);
        obj.rotation.y = parse(etRotY, obj.rotation.y);
        obj.rotation.z = parse(etRotZ, obj.rotation.z);
        obj.scale.x = Math.max(0.01f, parse(etScaleX, obj.scale.x));
        obj.scale.y = Math.max(0.01f, parse(etScaleY, obj.scale.y));
        obj.scale.z = Math.max(0.01f, parse(etScaleZ, obj.scale.z));

        renderer.markDirty();
        glView.requestRender();
        refreshOutliner();
        updateStatus();
        Toast.makeText(this, "变换已应用", Toast.LENGTH_SHORT).show();
    }

    // ======================== 右面板 - 数据可视化 ========================

    private void refreshDataPanel() {
        refreshDataInfo();
        refreshCloudInfo();
        refreshVertexInfo();
        refreshMetaInfo();
    }

    private void refreshDataInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("场景统计:\n");
        sb.append("  物体数: ").append(scene.objects.size()).append("\n");
        sb.append("  总顶点: ").append(scene.totalVertices()).append("\n");
        sb.append("  总三角形: ").append(scene.totalTriangles()).append("\n\n");

        int totalChunks = 0, totalClouds = 0, totalSubs = 0;
        for (SceneObject obj : scene.objects) {
            if (obj.kind == ObjKind.MeshesTerrain) {
                totalChunks += obj.chunkCount;
                totalClouds += obj.cloudCount;
                totalSubs += obj.subchunkCount;
            }
        }
        sb.append("Meshes 数据:\n");
        sb.append("  Chunk: ").append(totalChunks).append("\n");
        sb.append("  Cloud: ").append(totalClouds).append("\n");
        sb.append("  Subchunk: ").append(totalSubs).append("\n");
        sb.append("  可视化: ").append(visModeName(renderer.getVisMode())).append("\n");

        // 计算包围盒
        if (!scene.objects.isEmpty()) {
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
            for (SceneObject obj : scene.objects) {
                for (MeshVertex v : obj.vertices) {
                    float wx = v.position.x + obj.position.x;
                    float wy = v.position.y + obj.position.y;
                    float wz = v.position.z + obj.position.z;
                    if (wx < minX) minX = wx; if (wx > maxX) maxX = wx;
                    if (wy < minY) minY = wy; if (wy > maxY) maxY = wy;
                    if (wz < minZ) minZ = wz; if (wz > maxZ) maxZ = wz;
                }
            }
            sb.append("\n包围盒:\n");
            sb.append("  Min: (").append(fmt(minX)).append(", ").append(fmt(minY)).append(", ").append(fmt(minZ)).append(")\n");
            sb.append("  Max: (").append(fmt(maxX)).append(", ").append(fmt(maxY)).append(", ").append(fmt(maxZ)).append(")\n");
            sb.append("  Size: ").append(fmt(maxX - minX)).append(" x ").append(fmt(maxY - minY)).append(" x ").append(fmt(maxZ - minZ));
        }
        tvDataInfo.setText(sb.toString());
    }

    private void refreshMetaInfo() {
        StringBuilder sb = new StringBuilder();
        GLRenderer.VisMode vm = renderer.getVisMode();
        sb.append("当前可视化: ").append(visModeName(vm)).append("\n\n");

        // 统计 meshes 文件元数据
        boolean hasMeshes = false;
        for (SceneObject obj : scene.objects) {
            if (obj.kind == ObjKind.MeshesTerrain) {
                hasMeshes = true;
                sb.append("[").append(obj.name).append("]\n");
                sb.append("  Chunk: ").append(obj.chunkCount).append("\n");
                sb.append("  Cloud: ").append(obj.cloudCount).append("\n");
                sb.append("  Subchunk: ").append(obj.subchunkCount).append("\n");
                sb.append("  顶点: ").append(obj.vertices.size()).append("\n");
                sb.append("  三角形: ").append(obj.indices.size() / 3).append("\n\n");
            }
        }
        if (!hasMeshes) {
            sb.append("无 Meshes 文件\n");
            sb.append("(导入 .meshes 文件后显示元数据)\n\n");
        }

        // 当前模式说明
        sb.append("--- 数据段说明 ---\n");
        switch (vm) {
            case MATERIAL:
                sb.append("材质/纹理: 每个顶点最多4个材质槽\n");
                sb.append("  按权重最大的材质着色\n");
                sb.append("  可用材质笔刷编辑\n");
                break;
            case CLOUD:
                sb.append("云数据: 材质ID=80的顶点\n");
                sb.append("  亮白色=云, 暗色=非云\n");
                break;
            case NORMAL:
                sb.append("法线: XYZ→RGB\n");
                sb.append("  红=X, 绿=Y, 蓝=Z\n");
                break;
            case AO:
                sb.append("AO/粗糙度: input2通道\n");
                sb.append("  存储环境光遮蔽数据\n");
                break;
            case DETAIL:
                sb.append("细节纹理: input3通道\n");
                sb.append("  存储细节纹理坐标\n");
                break;
            case MISC:
                sb.append("其他数据: input4通道\n");
                sb.append("  存储裙边等辅助数据\n");
                break;
            case WIREFRAME:
                sb.append("线框: 显示三角形边\n");
                sb.append("  选中物体=金色\n");
                break;
            case CHUNK:
                sb.append("分块: 显示AABB边界\n");
                sb.append("  绿色框=Chunk范围\n");
                break;
            default:
                break;
        }

        tvMetaInfo.setText(sb.toString());
    }

    private void refreshCloudInfo() {
        StringBuilder sb = new StringBuilder();
        boolean anyCloud = false;
        for (int i = 0; i < scene.objects.size(); i++) {
            SceneObject obj = scene.objects.get(i);
            if (obj.hasClouds) {
                anyCloud = true;
                sb.append("[").append(i).append("] ").append(obj.name).append("\n");
                sb.append("  云数量: ").append(obj.cloudCount).append("\n");
                sb.append("  Chunk: ").append(obj.chunkCount).append("\n\n");
            }
        }
        if (!anyCloud) {
            tvCloudInfo.setText("无云数据\n(导入含云数据的 meshes 文件后显示)");
        } else {
            tvCloudInfo.setText(sb.toString());
        }
    }

    private void refreshVertexInfo() {
        SceneObject obj = scene.selectedObject();
        if (obj == null) {
            tvVertexInfo.setText("无选中物体\n点击物体列表或视口选择");
            return;
        }
        StringBuilder sb = new StringBuilder();
        sb.append("物体: ").append(obj.name).append("\n");
        sb.append("类型: ");
        switch (obj.kind) {
            case MeshesTerrain: sb.append("Meshes地形"); break;
            case Imported: sb.append("导入模型"); break;
            default: sb.append("基础几何"); break;
        }
        sb.append("\n");
        sb.append("顶点数: ").append(obj.vertices.size()).append("\n");
        sb.append("三角形: ").append(obj.indices.size() / 3).append("\n");
        sb.append("材质ID: ").append(obj.baseMaterialId).append(" (").append(MaterialTable.instance().name(obj.baseMaterialId)).append(")\n");

        // 材质分布统计
        int[] matCount = new int[256];
        for (MeshVertex v : obj.vertices) {
            int best = 0;
            float bw = -1;
            for (int k = 0; k < 4; k++) {
                if (v.materialWeights[k] > bw) {
                    bw = v.materialWeights[k];
                    best = k;
                }
            }
            int mid = v.materialIds[best] & 0xFF;
            if (mid >= 0 && mid < 256) matCount[mid]++;
        }
        sb.append("\n材质分布:\n");
        boolean hasMat = false;
        for (int i = 0; i < 256; i++) {
            if (matCount[i] > 0) {
                sb.append("  ").append(MaterialTable.instance().name(i)).append(" (").append(i).append("): ").append(matCount[i]).append("\n");
                hasMat = true;
            }
        }
        if (!hasMat) sb.append("  (无材质数据)\n");

        // 数据通道统计 (纹理处理方式)
        if (obj.kind == ObjKind.MeshesTerrain && !obj.vertices.isEmpty()) {
            sb.append("\n纹理数据通道:\n");
            // input2 (AO/粗糙度)
            float i2min = 1, i2max = 0;
            float i3min = 1, i3max = 0;
            float i4min = 1, i4max = 0;
            int multiMatCount = 0;
            for (MeshVertex v : obj.vertices) {
                // 统计多材质混合顶点
                int usedSlots = 0;
                for (int k = 0; k < 4; k++) {
                    if (v.materialWeights[k] > 0.01f) usedSlots++;
                }
                if (usedSlots > 1) multiMatCount++;

                // input2 range
                for (int k = 0; k < 4; k++) {
                    if (v.input2[k] < i2min) i2min = v.input2[k];
                    if (v.input2[k] > i2max) i2max = v.input2[k];
                    if (v.input3[k] < i3min) i3min = v.input3[k];
                    if (v.input3[k] > i3max) i3max = v.input3[k];
                    if (v.input4[k] < i4min) i4min = v.input4[k];
                    if (v.input4[k] > i4max) i4max = v.input4[k];
                }
            }
            sb.append("  多材质混合顶点: ").append(multiMatCount).append("\n");
            sb.append("  input2(AO): [").append(fmt(i2min)).append("-").append(fmt(i2max)).append("]\n");
            sb.append("  input3(细节): [").append(fmt(i3min)).append("-").append(fmt(i3max)).append("]\n");
            sb.append("  input4(裙边): [").append(fmt(i4min)).append("-").append(fmt(i4max)).append("]\n");
            sb.append("\n纹理处理:\n");
            sb.append("  每顶点4材质槽+权重\n");
            sb.append("  input2=AO/粗糙度贴图\n");
            sb.append("  input3=细节纹理UV\n");
            sb.append("  input4=裙边/辅助数据\n");
        }

        // 顶点位置范围 (模型空间)
        if (!obj.vertices.isEmpty()) {
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
            for (MeshVertex v : obj.vertices) {
                if (v.position.x < minX) minX = v.position.x;
                if (v.position.x > maxX) maxX = v.position.x;
                if (v.position.y < minY) minY = v.position.y;
                if (v.position.y > maxY) maxY = v.position.y;
                if (v.position.z < minZ) minZ = v.position.z;
                if (v.position.z > maxZ) maxZ = v.position.z;
            }
            sb.append("\n模型空间范围:\n");
            sb.append("  X: [").append(fmt(minX)).append(", ").append(fmt(maxX)).append("]\n");
            sb.append("  Y: [").append(fmt(minY)).append(", ").append(fmt(maxY)).append("]\n");
            sb.append("  Z: [").append(fmt(minZ)).append(", ").append(fmt(maxZ)).append("]\n");
        }

        tvVertexInfo.setText(sb.toString());
    }

    // ======================== 状态栏 ========================

    private void updateStatus() {
        int verts = scene.totalVertices();
        int tris = scene.totalTriangles();
        int objs = scene.objects.size();
        SceneObject sel = scene.selectedObject();
        String selName = sel != null ? sel.name : "无";
        String toolName;
        switch (renderer.getTool()) {
            case MOVE: toolName = "移动"; break;
            case ROTATE: toolName = "旋转"; break;
            case SCALE: toolName = "缩放"; break;
            case BRUSH: toolName = "笔刷"; break;
            default: toolName = "选择"; break;
        }
        String brushInfo = "";
        if (renderer.getTool() == GLRenderer.Tool.BRUSH) {
            switch (renderer.getBrushType()) {
                case SCULPT_RAISE: brushInfo = "| 凸起"; break;
                case SCULPT_LOWER: brushInfo = "| 凹陷"; break;
                default:
                    brushInfo = "| 材质:" + MaterialTable.instance().name(renderer.getBrushMaterial());
                    break;
            }
        }
        // 相机辅助信息
        Camera cam = renderer.getCamera();
        String camInfo = String.format(" | Yaw:%.0f° Pitch:%.0f° Dist:%.1f",
                Math.toDegrees(cam.yaw), Math.toDegrees(cam.pitch), cam.distance);
        statusInfo.setText("V:" + verts + " T:" + tris + " O:" + objs
                + " | " + toolName + " | " + selName + " " + brushInfo + camInfo);
    }

    // ======================== 文件导入/导出 ========================

    private void importMeshes(Uri uri) {
        byte[] data = readUri(uri);
        if (data == null) { toast("读取文件失败"); return; }
        MeshesParser.MeshesFile mf = MeshesParser.parse(data);
        if (!mf.valid) { toast("解析失败: " + mf.error); return; }
        String name = getDisplayName(uri);
        SceneObject obj = MeshesParser.toSceneObject(mf, name);
        if (obj != null) {
            scene.add(obj);
            renderer.markDirty();
            glView.requestRender();
            onSelectionChanged();
            toast("导入成功: " + mf.vertexCount + " 顶点");
        } else {
            toast("转换失败");
        }
    }

    private void importObj(Uri uri) {
        byte[] data = readUri(uri);
        if (data == null) { toast("读取文件失败"); return; }
        String name = getDisplayName(uri);
        SceneObject obj = ObjImporter.load(data, name);
        if (obj != null && !obj.vertices.isEmpty()) {
            scene.add(obj);
            renderer.markDirty();
            glView.requestRender();
            onSelectionChanged();
            toast("导入成功: " + obj.vertices.size() + " 顶点");
        } else {
            toast("OBJ 解析失败");
        }
    }

    private void exportMeshes(Uri uri) {
        byte[] data = MeshesExporter.exportScene(scene, getDisplayName(uri));
        if (data == null) { toast("导出失败: 场景为空"); return; }
        writeUri(uri, data);
        toast("导出成功: " + data.length + " 字节");
    }

    // ======================== 文件 I/O ========================

    private byte[] readUri(Uri uri) {
        try {
            ContentResolver cr = getContentResolver();
            InputStream is = cr.openInputStream(uri);
            if (is == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
            is.close();
            return bos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    private void writeUri(Uri uri, byte[] data) {
        try {
            ContentResolver cr = getContentResolver();
            OutputStream os = cr.openOutputStream(uri);
            if (os == null) { toast("无法写入文件"); return; }
            os.write(data);
            os.flush();
            os.close();
        } catch (Exception e) {
            toast("写入失败: " + e.getMessage());
        }
    }

    private String getDisplayName(Uri uri) {
        if (uri == null) return "file";
        String last = uri.getLastPathSegment();
        if (last == null) return "file";
        int dot = last.lastIndexOf('.');
        if (dot > 0) return last.substring(0, dot);
        return last;
    }

    // ======================== 辅助 ========================

    private static String fmt(float f) {
        return String.format("%.2f", f);
    }

    private static float parse(EditText et, float defaultVal) {
        String s = et.getText().toString().trim();
        if (s.isEmpty()) return defaultVal;
        try {
            return Float.parseFloat(s);
        } catch (NumberFormatException e) {
            return defaultVal;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
