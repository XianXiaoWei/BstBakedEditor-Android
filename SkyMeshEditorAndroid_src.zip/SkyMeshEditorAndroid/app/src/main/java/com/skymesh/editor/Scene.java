package com.skymesh.editor;

import java.util.ArrayList;
import java.util.List;

/**
 * 场景：物体集合 + 选中。对应 C++ Scene。
 */
public final class Scene {
    public final List<SceneObject> objects = new ArrayList<>();
    public int selected = -1;

    public SceneObject add(SceneObject o) {
        objects.add(o);
        selected = objects.size() - 1;
        return o;
    }

    public SceneObject selectedObject() {
        if (selected < 0 || selected >= objects.size()) return null;
        return objects.get(selected);
    }

    public void deleteSelected() {
        if (selected < 0 || selected >= objects.size()) return;
        objects.remove(selected);
        selected = -1;
    }

    public int totalVertices() {
        int n = 0;
        for (SceneObject o : objects) n += o.vertices.size();
        return n;
    }

    public int totalTriangles() {
        int n = 0;
        for (SceneObject o : objects) n += o.indices.size() / 3;
        return n;
    }
}
