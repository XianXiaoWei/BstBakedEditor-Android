package com.skymesh.editor;

import android.opengl.GLES20;

/**
 * OpenGL ES 着色器工具类。对应 C++ 端的 Shader 工具。
 * 负责编译 vertex/fragment shader 并链接成 program。
 */
public final class ShaderUtil {

    private ShaderUtil() {}

    /**
     * 编译并链接一个 OpenGL ES 2.0 program。
     *
     * @param vertexSource   顶点着色器源码（GLSL ES 1.00）
     * @param fragmentSource  片段着色器源码（GLSL ES 1.00）
     * @return program 对象 ID；失败返回 0
     */
    public static int createProgram(String vertexSource, String fragmentSource) {
        int vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexSource);
        if (vertexShader == 0) {
            return 0;
        }

        int fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentSource);
        if (fragmentShader == 0) {
            GLES20.glDeleteShader(vertexShader);
            return 0;
        }

        int program = GLES20.glCreateProgram();
        if (program == 0) {
            GLES20.glDeleteShader(vertexShader);
            GLES20.glDeleteShader(fragmentShader);
            return 0;
        }

        GLES20.glAttachShader(program, vertexShader);
        GLES20.glAttachShader(program, fragmentShader);
        GLES20.glLinkProgram(program);

        int[] linkStatus = new int[1];
        GLES20.glGetProgramiv(program, GLES20.GL_LINK_STATUS, linkStatus, 0);
        if (linkStatus[0] != GLES20.GL_TRUE) {
            String log = GLES20.glGetProgramInfoLog(program);
            android.util.Log.e("ShaderUtil", "Could not link program:\n" + log);
            GLES20.glDeleteProgram(program);
            program = 0;
        }

        // 链接后即可删除 shader（driver 仍保留引用）
        GLES20.glDeleteShader(vertexShader);
        GLES20.glDeleteShader(fragmentShader);

        return program;
    }

    /**
     * 编译单个 shader。
     *
     * @param type   GLES20.GL_VERTEX_SHADER 或 GLES20.GL_FRAGMENT_SHADER
     * @param source 着色器源码
     * @return shader 对象 ID；失败返回 0
     */
    private static int loadShader(int type, String source) {
        int shader = GLES20.glCreateShader(type);
        if (shader == 0) {
            return 0;
        }

        GLES20.glShaderSource(shader, source);
        GLES20.glCompileShader(shader);

        int[] compiled = new int[1];
        GLES20.glGetShaderiv(shader, GLES20.GL_COMPILE_STATUS, compiled, 0);
        if (compiled[0] != GLES20.GL_TRUE) {
            String log = GLES20.glGetShaderInfoLog(shader);
            android.util.Log.e("ShaderUtil", "Could not compile shader "
                    + (type == GLES20.GL_VERTEX_SHADER ? "VERTEX" : "FRAGMENT")
                    + ":\n" + log);
            GLES20.glDeleteShader(shader);
            return 0;
        }

        return shader;
    }

    /**
     * 检查 OpenGL 错误，有错误时输出日志。
     *
     * @param tag 日志标签
     */
    public static void checkGLError(String tag) {
        int error;
        while ((error = GLES20.glGetError()) != GLES20.GL_NO_ERROR) {
            android.util.Log.e(tag, "GL error: 0x" + Integer.toHexString(error));
        }
    }
}
