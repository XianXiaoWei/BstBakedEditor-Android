package com.skymesh.editor;

/**
 * 场景物体类型。对应 C++ enum class ObjKind。
 */
public enum ObjKind {
    /** 基础几何体（立方体/球/圆柱/平面） */
    Primitive,
    /** 导入的 OBJ 模型 */
    Imported,
    /** That Sky Level 的 .meshes 地形 */
    MeshesTerrain
}
