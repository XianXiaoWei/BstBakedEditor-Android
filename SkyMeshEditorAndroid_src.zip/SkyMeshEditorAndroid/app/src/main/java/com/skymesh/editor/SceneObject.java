package com.skymesh.editor;

import android.opengl.Matrix;

import java.util.ArrayList;
import java.util.List;

/**
 * 场景物体：统一表示 meshes 地形 / 基础几何体 / 导入模型。对应 C++ SceneObject。
 * ownMesh=true 表示有自己的顶点/索引数据(可编辑网格)。
 */
public final class SceneObject {
    public String name;
    public ObjKind kind = ObjKind.Primitive;

    public final Vec3 position = new Vec3(0, 0, 0);
    public final Vec3 rotation = new Vec3(0, 0, 0); // 角度（度）
    public final Vec3 scale = new Vec3(1, 1, 1);

    /** 可编辑网格数据(基元/导入/meshes地形都有) */
    public final List<MeshVertex> vertices = new ArrayList<>();
    /** 三角索引 */
    public final List<Integer> indices = new ArrayList<>();
    /** 基元/导入模型的单一材质 */
    public int baseMaterialId = 48;

    // meshes 文件专属数据(仅 MeshesTerrain)
    public int chunkCount = 0, cloudCount = 0, subchunkCount = 0;
    public boolean hasClouds = false;
    /** 导入时的完整 meshes 解析数据 (用于导出时保留原始结构) */
    public MeshesParser.MeshesFile sourceMeshes = null;
    /** 顶点数据是否被修改 (笔刷编辑过) */
    public boolean vertexModified = false;
    /** 每顶点的有效材质ID (来自 subchunk, -1=未设置, 用顶点权重) */
    public int[] effectiveMaterialIds = null;

    public SceneObject() {}

    /** 主材质颜色：基元用 baseMaterialId，meshes 用顶点权重 */
    public Vec3 mainColor(Vec3 out) {
        if (out == null) out = new Vec3();
        if (kind == ObjKind.MeshesTerrain) {
            if (!vertices.isEmpty()) return vertexColor(vertices.get(0), out);
            out.set(0.5f, 0.5f, 0.55f);
            return out;
        }
        float[] c = MaterialTable.instance().color(baseMaterialId, null);
        out.set(c[0], c[1], c[2]);
        return out;
    }

    /** 取顶点的加权混合材质颜色 (参照 SkyModelViewer LevelMeshesReader) */
    public static Vec3 vertexColor(MeshVertex v, Vec3 out) {
        if (out == null) out = new Vec3();
        float w0 = v.materialWeights[0], w1 = v.materialWeights[1];
        float w2 = v.materialWeights[2], w3 = v.materialWeights[3];
        float tw = w0 + w1 + w2 + w3;
        if (tw < 0.001f) {
            // 权重全为 0: 直接用第一个材质颜色
            float[] c = MaterialTable.instance().color(v.materialIds[0], null);
            out.set(c[0], c[1], c[2]);
        } else {
            // 按权重加权平均 4 个材质颜色
            float[] c0 = MaterialTable.instance().color(v.materialIds[0], null);
            float[] c1 = MaterialTable.instance().color(v.materialIds[1], null);
            float[] c2 = MaterialTable.instance().color(v.materialIds[2], null);
            float[] c3 = MaterialTable.instance().color(v.materialIds[3], null);
            out.set(
                (c0[0]*w0 + c1[0]*w1 + c2[0]*w2 + c3[0]*w3) / tw,
                (c0[1]*w0 + c1[1]*w1 + c2[1]*w2 + c3[1]*w3) / tw,
                (c0[2]*w0 + c1[2]*w1 + c2[2]*w2 + c3[2]*w3) / tw
            );
        }
        return out;
    }

    /**
     * 模型矩阵 M = T * Rx * Ry * Rz * S（与 Qt 端顺序一致）。
     * @param out 长度 16 的 float 数组
     */
    public float[] modelMatrix(float[] out) {
        if (out == null) out = new float[16];
        Matrix.setIdentityM(out, 0);
        Matrix.translateM(out, 0, position.x, position.y, position.z);
        Matrix.rotateM(out, 0, rotation.x, 1, 0, 0);
        Matrix.rotateM(out, 0, rotation.y, 0, 1, 0);
        Matrix.rotateM(out, 0, rotation.z, 0, 0, 1);
        Matrix.scaleM(out, 0, scale.x, scale.y, scale.z);
        return out;
    }

    /** 世界空间包围球半径(用于拾取) */
    public float pickRadius() {
        float r = 1.0f;
        if (!vertices.isEmpty()) {
            r = 0;
            for (MeshVertex v : vertices) {
                float l = v.position.len();
                if (l > r) r = l;
            }
        }
        float sm = Math.max(Math.max(scale.x, scale.y), scale.z);
        return r * sm * 1.1f + 0.2f;
    }
}
