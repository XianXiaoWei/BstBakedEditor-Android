package com.skymesh.editor;

import android.opengl.Matrix;

/**
 * 轨道相机 — 完全参照 SkyModelViewer-Android 的实现。
 * <p>
 * 三参数轨道相机: yaw/pitch/distance + target。
 * 相机位置 = target - forward × distance (相机在目标反方向，始终看向目标)。
 */
public final class Camera {
    public final Vec3 target = new Vec3(0, 0, 0);
    public float yaw = -2.3561944902f;   // ≈ -135° (弧度)
    public float pitch = -0.35f;          // ≈ -20° (弧度)
    public double distance = 12.0;

    private final float[] view = new float[16];
    private final float[] eye = new float[3];

    // near/far 自适应
    private float near = 0.1f;
    private float far = 2000.0f;
    private float fov = 45.0f;

    /** 计算前向向量 (球坐标→笛卡尔) */
    private float[] computeForward() {
        float cp = (float) Math.cos(pitch);
        float fx = cp * (float) Math.cos(yaw);
        float fy = (float) Math.sin(pitch);
        float fz = cp * (float) Math.sin(yaw);
        // normalize
        float len = (float) Math.sqrt(fx * fx + fy * fy + fz * fz);
        if (len > 1e-6f) { fx /= len; fy /= len; fz /= len; }
        return new float[]{fx, fy, fz};
    }

    /** 相机世界坐标 */
    public float[] position() {
        float[] f = computeForward();
        eye[0] = (float) (target.x - f[0] * distance);
        eye[1] = (float) (target.y - f[1] * distance);
        eye[2] = (float) (target.z - f[2] * distance);
        return eye;
    }

    /** view 矩阵 (lookAt) */
    public float[] viewMatrix() {
        // 钳制 pitch 防止万向锁
        pitch = Math.max(-1.45f, Math.min(1.45f, pitch));

        float[] f = computeForward();
        float[] pos = new float[]{
            (float) (target.x - f[0] * distance),
            (float) (target.y - f[1] * distance),
            (float) (target.z - f[2] * distance)
        };
        Matrix.setLookAtM(view, 0,
                pos[0], pos[1], pos[2],
                target.x, target.y, target.z,
                0, 1, 0);
        return view;
    }

    /**
     * 单指旋转 — 参照 SkyModelViewer: yaw += dx, pitch -= dy
     * dx>0 (右滑) → yaw增大 → 场景左转
     * dy>0 (下滑) → pitch减小 → 视线下压
     */
    public void orbit(float dx, float dy) {
        yaw += dx * 0.01f;
        pitch -= dy * 0.01f;
    }

    /**
     * 双指缩放 — factor 是 1/scaleFactor
     * factor<1 (张开) → distance减小 → 放大
     * factor>1 (捏合) → distance增大 → 缩小
     */
    public void zoom(float factor) {
        distance *= factor;
        distance = Math.max(0.001, Math.min(1e9, distance));
        updateClipPlanes();
    }

    /** 自适应裁剪面 */
    private void updateClipPlanes() {
        float dist = (float) distance;
        if (dist < 0.001f) dist = 0.001f;
        near = Math.max(dist / 1000.0f, 1e-4f);
        far = Math.max(dist * 1000.0f, 1000.0f);
    }

    public float getNear() { return near; }
    public float getFar() { return far; }
    public float getFov() { return fov; }
    public double getDistance() { return distance; }

    // ======================== 标准视角 (Blender 风格) ========================

    /** 前视图 (从 -Z 方向看) */
    public void setViewFront() { yaw = (float) Math.PI; pitch = 0; }
    /** 后视图 (从 +Z 方向看) */
    public void setViewBack() { yaw = 0; pitch = 0; }
    /** 顶视图 (从 +Y 方向看) */
    public void setViewTop() { yaw = 0; pitch = 1.4f; }
    /** 底视图 (从 -Y 方向看) */
    public void setViewBottom() { yaw = 0; pitch = -1.4f; }
    /** 左视图 (从 -X 方向看) */
    public void setViewLeft() { yaw = (float) (Math.PI / 2); pitch = 0; }
    /** 右视图 (从 +X 方向看) */
    public void setViewRight() { yaw = (float) (-Math.PI / 2); pitch = 0; }

    /** 上下移动相机目标 (Y轴) — 速度与距离成正比 */
    public void moveVertical(float dy, float speed) {
        target.y += dy * speed;
    }

    /** 双指拖动平移视角 — 参照 SkyModelViewer */
    public void pan(float dx, float dy) {
        float[] f = computeForward();
        // right = normalize(cross(forward, up))
        float[] up = {0f, 1f, 0f};
        float rx = f[1] * up[2] - f[2] * up[1];
        float ry = f[2] * up[0] - f[0] * up[2];
        float rz = f[0] * up[1] - f[1] * up[0];
        float rlen = (float) Math.sqrt(rx * rx + ry * ry + rz * rz);
        if (rlen > 1e-6f) { rx /= rlen; ry /= rlen; rz /= rlen; }
        // up' = cross(right, forward)
        float ux = ry * f[2] - rz * f[1];
        float uy = rz * f[0] - rx * f[2];
        float uz = rx * f[1] - ry * f[0];

        float s = (float) (distance * 0.002);
        target.x += -rx * dx * s + ux * dy * s;
        target.y += -ry * dx * s + uy * dy * s;
        target.z += -rz * dx * s + uz * dy * s;
    }

    /** 摇杆控制: 沿地面平面平移相机目标 (jx=左右, jy=前后) */
    public void moveByJoystick(float jx, float jy) {
        float[] f = computeForward();
        // forward 投影到 XZ 平面
        float fx = f[0], fz = f[2];
        float flen = (float) Math.sqrt(fx * fx + fz * fz);
        if (flen > 0.001f) { fx /= flen; fz /= flen; }
        // right = normalize(cross(forward, up))
        float[] up = {0f, 1f, 0f};
        float rx = f[1] * up[2] - f[2] * up[1];
        float ry = f[2] * up[0] - f[0] * up[2];
        float rz = f[0] * up[1] - f[1] * up[0];
        float rlen = (float) Math.sqrt(rx * rx + ry * ry + rz * rz);
        if (rlen > 1e-6f) { rx /= rlen; ry /= rlen; rz /= rlen; }

        float speed = (float) (distance * 0.05);
        target.x += (rx * jx + fx * jy) * speed;
        target.y += (ry * jx) * speed;  // right.y ≈ 0
        target.z += (rz * jx + fz * jy) * speed;
    }
}
