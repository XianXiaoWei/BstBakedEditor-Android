package com.skymesh.editor;

import android.opengl.Matrix;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * MeshesExporter - 将场景中所有物体融合导出为 .meshes 格式。
 * <p>
 * 核心策略 (按优先级):
 * 1. 如果场景仅有一个 MeshesTerrain 物体且未修改顶点 → 原样输出原始文件字节
 * 2. 如果场景仅有一个 MeshesTerrain 物体且修改了顶点 (笔刷) → 仅替换压缩顶点数据,
 *    所有 chunk/subchunk/index/DESC/LOD0 原样保留 (splice 方式)
 * 3. 如果场景有 MeshesTerrain + 其他物体 → 保留原始结构 + 追加新 chunk
 * 4. 如果没有 MeshesTerrain 物体 → 从零构建 (确保不丢面)
 */
public class MeshesExporter {

    private static final int MAGIC_LVL0 = 0x304C564C;
    private static final int VERTEX_SIZE = 36;
    private static final int MAX_VTX_PER_CHUNK = 252;

    // ======================== 小端写入助手 ========================

    private static class Writer {
        ByteArrayOutputStream buf = new ByteArrayOutputStream();

        void u32(int v) {
            byte[] b = new byte[4];
            ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putInt(v);
            write(b);
        }

        void u16(int v) {
            byte[] b = new byte[2];
            ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putShort((short) v);
            write(b);
        }

        void u8(int v) {
            buf.write(v & 0xFF);
        }

        void f32(float v) {
            byte[] b = new byte[4];
            ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).putFloat(v);
            write(b);
        }

        void v3(float[] v) {
            f32(v[0]);
            f32(v[1]);
            f32(v[2]);
        }

        void bytes(byte[] b) {
            write(b);
        }

        private void write(byte[] b) {
            buf.write(b, 0, b.length);
        }

        byte[] toByteArray() {
            return buf.toByteArray();
        }

        int size() {
            return buf.size();
        }
    }

    // ======================== 字节读写助手 ========================

    private static int readU32(byte[] data, int offset) {
        return ByteBuffer.wrap(data, offset, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    private static void writeU32(byte[] data, int offset, int value) {
        ByteBuffer.wrap(data, offset, 4).order(ByteOrder.LITTLE_ENDIAN).putInt(value);
    }

    // ======================== Subchunk 重建 (参照 bstbake_unpack.py _build_chunks) ========================

    /**
     * 重建结果: 新的 subchunk 列表。
     * 不再返回排序索引 - 保持原始三角形顺序。
     */
    private static class RebuildResult {
        /** 排序后的局部索引 (已弃用, 始终为 null - 保持原始顺序) */
        byte[] sortedIndices;
        /** 新的 subchunk 列表, 每个元素是 int[7]: {materialId, triCount, vtxCount, triStart, triEnd, vtxStart, vtxEnd} */
        List<int[]> subchunks;
    }

    /**
     * 为单个 chunk 重建 subchunk 分配 — MIN-MAX 算法 (与原始文件生成方式一致)。
     * <p>
     * 算法原理 (通过逆向分析原始 .meshes 文件确认, 165/165 chunk 100% 匹配):
     * - 每个材质对应一个 subchunk (不会因不连续而产生多个)
     * - triStart = 第一个拥有该材质的三角形索引
     * - triEnd = 最后一个拥有该材质的三角形索引
     * - triCount = 拥有该材质的三角形精确数量 (可能 < triEnd - triStart + 1)
     * - vtxStart = 拥有该材质的顶点中, 最小的局部顶点索引
     * - vtxEnd = 拥有该材质的顶点中, 最大的局部顶点索引
     * - vtxCount = 所有拥有该材质的三角形的 3 个顶点的唯一局部索引数量
     * <p>
     * 排序 (关键!):
     * - subchunk 按 triEnd 升序, 然后 matId 升序排列
     * - triEnd 小的 (局部材质) 排在前面 → 先渲染
     * - triEnd 大的 (基础材质, 如 mat=48 覆盖全部三角形) 排在后面 → 后渲染
     * - 原因: 游戏使用深度测试, 基础材质先渲染会写入深度缓冲区,
     *   阻挡后续局部材质的渲染, 导致 "丢顶点" 现象
     * <p>
     * 渲染原理 (参照 GrassSh.gl.vert):
     * - 游戏按 subchunk 顺序绘制, 每个 subchunk 设置 u_materialId = subchunk.matId
     * - 绘制范围: triStart 到 triEnd (所有三角形, 不只是 triCount 个)
     * - subchunk 会重叠: 同一三角形可能在多个 subchunk 中 (多 pass 材质混合)
     * - 顶点着色器: ids = ivec4(a_material0 * 256); matched = equal(ids, ivec4(u_materialId));
     *   weight = dot(vec4(matched), a_material1); v_color.w = weight
     * - 即: 从顶点 4 个材质槽中选出匹配 u_materialId 的槽, 取其权重作为 coverage
     * - 权重=0 的顶点不贡献 (透明), 但仍参与绘制
     * <p>
     * 与活跃区块算法的区别:
     * - 活跃区块算法: 材质不连续时产生多个 subchunk, 导致 subchunk 数量可能超过游戏限制
     * - MIN-MAX 算法: 每个材质仅一个 subchunk, subchunk 数量 = 材质数量 (通常 2-4)
     * - 原始文件使用 MIN-MAX 算法, 每块仅 2-4 个 subchunk
     *
     * @param c             要重建的 chunk
     * @param localIndices  全局 u8 局部索引数组 (不修改, 仅读取)
     * @param vertices      全局顶点列表 (已编辑)
     * @return RebuildResult: 新的 subchunk 列表
     */
    private static RebuildResult rebuildChunkSubchunks(
            MeshesParser.MeshesChunk c,
            byte[] localIndices,
            List<MeshVertex> vertices) {

        RebuildResult result = new RebuildResult();
        int triCount = c.idxCount / 3;
        int vtxCount = c.vtxCount;

        result.sortedIndices = null;

        // 边界情况: 空 chunk
        if (triCount == 0) {
            result.subchunks = new ArrayList<int[]>();
            result.subchunks.add(new int[]{16, 0, vtxCount, 0, 0, 0, Math.max(0, vtxCount - 1)});
            return result;
        }

        // 每个材质的信息: {minTri, maxTri, triCount, usedVtxMin, usedVtxMax, matchTriVtxSet}
        // usedVtxMin/Max: 拥有该材质的顶点的局部索引范围 (用于 vtxStart/vtxEnd)
        // matchTriVtxSet: 所有拥有该材质的三角形的 3 个顶点的唯一局部索引集合 (用于 vtxCount)
        Map<Integer, int[]> matInfo = new HashMap<Integer, int[]>();  // mat -> {minTri, maxTri, triCount, usedVtxMin, usedVtxMax}
        Map<Integer, Set<Integer>> matVtxSets = new HashMap<Integer, Set<Integer>>();  // mat -> matchTriVtxSet

        for (int t = 0; t < triCount; t++) {
            int idxBase = c.idxStart + t * 3;
            if (idxBase + 2 >= localIndices.length) break;
            int li0 = localIndices[idxBase] & 0xFF;
            int li1 = localIndices[idxBase + 1] & 0xFF;
            int li2 = localIndices[idxBase + 2] & 0xFF;

            int gv0 = c.vtxStart + li0;
            int gv1 = c.vtxStart + li1;
            int gv2 = c.vtxStart + li2;

            // 收集此三角形所有顶点的材质 (权重 > 0 且 id > 0)
            Set<Integer> faceMats = new HashSet<Integer>();
            collectFaceMaterials(gv0, vertices, faceMats);
            collectFaceMaterials(gv1, vertices, faceMats);
            collectFaceMaterials(gv2, vertices, faceMats);

            // 无有效材质时用主材质投票
            if (faceMats.isEmpty()) {
                int m0 = getDominantVertexMaterial(gv0, vertices);
                int m1 = getDominantVertexMaterial(gv1, vertices);
                int m2 = getDominantVertexMaterial(gv2, vertices);
                int fm = voteDominant(m0, m1, m2);
                faceMats.add(Integer.valueOf(fm > 0 ? fm : 16));
            }

            // 为每个材质更新信息
            for (Integer mat : faceMats) {
                int[] info = matInfo.get(mat);
                Set<Integer> vtxSet = matVtxSets.get(mat);
                if (info == null) {
                    info = new int[]{t, t, 0, Integer.MAX_VALUE, Integer.MIN_VALUE};
                    matInfo.put(mat, info);
                    vtxSet = new HashSet<Integer>();
                    matVtxSets.put(mat, vtxSet);
                }
                // 更新 tri 范围
                info[0] = Math.min(info[0], t);  // minTri
                info[1] = Math.max(info[1], t);  // maxTri
                info[2]++;                        // triCount

                // 更新 vtxStart/vtxEnd: 只收集拥有该材质的顶点的局部索引
                for (int li = 0; li < 3; li++) {
                    int gv = (li == 0) ? gv0 : (li == 1) ? gv1 : gv2;
                    int localIdx = (li == 0) ? li0 : (li == 1) ? li1 : li2;
                    if (vertexHasMaterial(gv, vertices, mat)) {
                        info[3] = Math.min(info[3], localIdx);  // usedVtxMin
                        info[4] = Math.max(info[4], localIdx);  // usedVtxMax
                    }
                }

                // 收集所有拥有该材质的三角形的 3 个顶点 (用于 vtxCount)
                vtxSet.add(li0);
                vtxSet.add(li1);
                vtxSet.add(li2);
            }
        }

        // 构建 subchunk 列表
        List<int[]> subBuffer = new ArrayList<int[]>();
        for (Map.Entry<Integer, int[]> entry : matInfo.entrySet()) {
            Integer mat = entry.getKey();
            int[] info = entry.getValue();
            Set<Integer> vtxSet = matVtxSets.get(mat);

            int triStart = info[0];
            int triEnd = info[1];
            int triCnt = info[2];
            int vtxStart = (info[3] != Integer.MAX_VALUE) ? info[3] : 0;
            int vtxEnd = (info[4] != Integer.MIN_VALUE) ? info[4] : Math.max(0, vtxCount - 1);
            int vtxCnt = vtxSet.size();

            subBuffer.add(new int[]{
                    mat.intValue(),
                    Math.min(triCnt, 255),
                    Math.min(vtxCnt, 255),
                    Math.min(triStart, 255),
                    Math.min(triEnd, 255),
                    Math.min(vtxStart, 255),
                    Math.min(vtxEnd, 255)
            });
        }

        // 按 triEnd 升序, 然后按 matId 升序排序 (与原始文件一致)
        // 原理: 原始文件通过逆向分析确认 subchunk 按 triEnd+matId 排序
        // - triEnd 小的 (局部材质) 排在前面, 先渲染
        // - triEnd 大的 (基础材质, 覆盖全部三角形) 排在后面, 后渲染
        // - 如果游戏使用深度测试, 基础材质先渲染会写入深度缓冲区,
        //   阻挡后续局部材质的渲染, 导致 "丢顶点" 现象
        // - triEnd 相同时按 matId 升序 (与原始文件一致)
        java.util.Collections.sort(subBuffer, new java.util.Comparator<int[]>() {
            @Override
            public int compare(int[] a, int[] b) {
                // a[4]=triEnd, a[0]=matId
                if (a[4] != b[4]) return Integer.compare(a[4], b[4]);
                return Integer.compare(a[0], b[0]);
            }
        });

        // 限制 subchunk 数量 ≤ 250 (u8 安全余量)
        while (subBuffer.size() > 250) {
            int minIdx = 0;
            int minCount = subBuffer.get(0)[1];
            for (int i = 1; i < subBuffer.size(); i++) {
                if (subBuffer.get(i)[1] < minCount) {
                    minCount = subBuffer.get(i)[1];
                    minIdx = i;
                }
            }
            subBuffer.remove(minIdx);
        }

        result.subchunks = subBuffer;
        return result;
    }

    /** 检查顶点是否拥有指定材质 (权重 > 0 且 id 匹配) */
    private static boolean vertexHasMaterial(int globalVtxIdx, List<MeshVertex> vertices, int matId) {
        if (globalVtxIdx < 0 || globalVtxIdx >= vertices.size()) return false;
        MeshVertex v = vertices.get(globalVtxIdx);
        for (int k = 0; k < 4; k++) {
            if (v.materialWeights[k] > 0.0f && v.materialIds[k] == matId) {
                return true;
            }
        }
        return false;
    }

    /**
     * 三角形主材质投票: 3 顶点主材的多数票, 平局取第一个。
     * 参照 bstbake_unpack.py 的 votes 逻辑。
     */
    private static int voteDominant(int m0, int m1, int m2) {
        if (m0 == m1) return m0;  // m0 和 m1 一致
        if (m0 == m2) return m0;  // m0 和 m2 一致
        if (m1 == m2) return m1;  // m1 和 m2 一致
        return m0;  // 三个都不同, 取第一个 (与 Python max() 行为一致)
    }

    /** 收集顶点的所有有效材质 (权重 > 0 且 id > 0) 到集合, 参照 bstbake_unpack.py */
    private static void collectFaceMaterials(int globalVtxIdx, List<MeshVertex> vertices, Set<Integer> mats) {
        if (globalVtxIdx < 0 || globalVtxIdx >= vertices.size()) return;
        MeshVertex v = vertices.get(globalVtxIdx);
        for (int k = 0; k < 4; k++) {
            if (v.materialWeights[k] > 0.0f && v.materialIds[k] > 0) {
                mats.add(v.materialIds[k]);
            }
        }
    }

    /** 取顶点权重最大的材质 ID (参照 bstbake_unpack.py _vtx_dom_mat) */
    private static int getDominantVertexMaterial(int globalVtxIdx, List<MeshVertex> vertices) {
        if (globalVtxIdx < 0 || globalVtxIdx >= vertices.size()) return 0;
        MeshVertex v = vertices.get(globalVtxIdx);
        int bestMat = 0;
        float bestWeight = -1;
        for (int k = 0; k < 4; k++) {
            if (v.materialWeights[k] > bestWeight) {
                bestWeight = v.materialWeights[k];
                bestMat = v.materialIds[k];
            }
        }
        return bestMat;
    }

    // ======================== 顶点打包 ========================

    /**
     * 把 MeshVertex 打包成 36 字节。
     * <p>
     * 打包前会对 4 个材质槽按权重降序排序, 确保 slot 0 是主材质 (权重最大)。
     * 原因: 游戏的物理碰撞和音效系统使用 slot 0 (materialIds[0]) 作为主材质,
     * 而笔刷编辑可能将新材质插入任意槽位, 导致 slot 0 不再是权重最大的材质。
     * 原始 .meshes 文件中 100% 顶点的 slot 0 都是权重最大的材质。
     */
    private static void packVertex(MeshVertex v, byte[] out, int offset) {
        // position f32×3
        ByteBuffer.wrap(out, offset, 12).order(ByteOrder.LITTLE_ENDIAN)
                .putFloat(v.position.x)
                .putFloat(v.position.y)
                .putFloat(v.position.z);

        // normal snorm8×4
        out[offset + 12] = snorm(v.normal[0]);
        out[offset + 13] = snorm(v.normal[1]);
        out[offset + 14] = snorm(v.normal[2]);
        out[offset + 15] = snorm(v.normal[3]);

        // 材质槽按权重降序排序 (slot 0 = 主材质, 权重最大)
        // 使用简单选择排序 (仅 4 个元素), 不修改原始顶点数据
        int[] sortedIds = new int[4];
        float[] sortedWeights = new float[4];
        for (int k = 0; k < 4; k++) {
            sortedIds[k] = v.materialIds[k];
            sortedWeights[k] = v.materialWeights[k];
        }
        for (int i = 0; i < 3; i++) {
            int maxIdx = i;
            for (int j = i + 1; j < 4; j++) {
                if (sortedWeights[j] > sortedWeights[maxIdx]) {
                    maxIdx = j;
                }
            }
            if (maxIdx != i) {
                int tmpId = sortedIds[i]; sortedIds[i] = sortedIds[maxIdx]; sortedIds[maxIdx] = tmpId;
                float tmpW = sortedWeights[i]; sortedWeights[i] = sortedWeights[maxIdx]; sortedWeights[maxIdx] = tmpW;
            }
        }

        // materialIds u8×4 (排序后)
        for (int k = 0; k < 4; k++)
            out[offset + 16 + k] = (byte) clampInt(sortedIds[k], 0, 255);

        // materialWeights unorm8×4 (排序后)
        for (int k = 0; k < 4; k++)
            out[offset + 20 + k] = unorm(sortedWeights[k]);

        // input2 unorm8×4
        for (int k = 0; k < 4; k++)
            out[offset + 24 + k] = unorm(v.input2[k]);

        // input3 unorm8×4
        for (int k = 0; k < 4; k++)
            out[offset + 28 + k] = unorm(v.input3[k]);

        // input4 unorm8×4
        for (int k = 0; k < 4; k++)
            out[offset + 32 + k] = unorm(v.input4[k]);
    }

    /**
     * snorm 编码 (float → i8)。
     * 使用四舍五入 (meshopt 标准), 避免截断导致的精度丢失。
     * 截断会导致 -128 → -127 (因 -128/127 = -1.0079 被 clamp 到 -1.0, 再 *127 = -127)。
     * 四舍五入修复了除 -128 外所有值的精度问题。
     */
    private static byte snorm(float f) {
        if (f < -1.0f) f = -1.0f;
        if (f > 1.0f) f = 1.0f;
        float v = f * 127.0f;
        // Round half away from zero (meshopt quantizeSnorm 标准)
        return (byte) (v >= 0 ? (int) (v + 0.5f) : (int) (v - 0.5f));
    }

    /**
     * unorm 编码 (float → u8)。
     * <p>
     * 关键修复: 确保非零权重不会被编码为 0。
     * <p>
     * 问题: 笔刷编辑后, 某些材质权重可能非常小 (如 0.001)。
     * 使用截断 (int)(f * 255) 会将 0.001 * 255 = 0.255 截断为 0,
     * 导致游戏读取权重为 0, 顶点在该材质的渲染 pass 中不可见 → "丢顶点"。
     * <p>
     * 修复: 如果 f > 0 但编码值为 0, 强制设为 1 (最小可表示的非零值)。
     * 这样 subchunk 重建 (基于 f > 0) 与编码后的顶点数据保持一致。
     * <p>
     * 对于原始未编辑的数据, byte/255.0 * 255 = byte (精确), 不受影响。
     */
    private static byte unorm(float f) {
        if (f < 0.0f) f = 0.0f;
        if (f > 1.0f) f = 1.0f;
        int v = (int) (f * 255.0f);
        // 确保非零权重不会被编码为 0 (防止笔刷编辑后的丢顶点)
        if (f > 0.0f && v == 0) v = 1;
        return (byte) v;
    }

    private static int clampInt(int v, int lo, int hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    // ======================== 导出主入口 ========================

    /**
     * 融合场景所有物体 → .meshes 二进制。
     *
     * @param scene    场景
     * @param fileName 文件名（用于 DESC 描述）
     * @return .meshes 格式的字节数组，如果场景为空返回 null
     */
    public static byte[] exportScene(Scene scene, String fileName) {
        if (scene == null || scene.objects.isEmpty()) return null;

        // 查找第一个有 sourceMeshes 的 MeshesTerrain 物体
        SceneObject meshesObj = null;
        List<SceneObject> otherObjs = new ArrayList<>();

        for (SceneObject obj : scene.objects) {
            if (meshesObj == null && obj.kind == ObjKind.MeshesTerrain && obj.sourceMeshes != null) {
                meshesObj = obj;
            } else {
                otherObjs.add(obj);
            }
        }

        if (meshesObj != null && otherObjs.isEmpty()) {
            // 仅有 meshes 物体: 最安全的方式
            return exportPreservingOriginal(meshesObj, fileName);
        } else if (meshesObj != null) {
            // 有额外物体: 保留原始结构 + 追加新 chunk
            return exportWithOriginalStructure(meshesObj, otherObjs, fileName);
        } else {
            // 无原始数据: 从零构建
            return exportFromScratch(scene, fileName);
        }
    }

    // ======================== 方式1: 保留原始结构 (最安全) ========================

    /**
     * 保留原始文件结构导出 — 替换压缩顶点数据 + 保留原始索引 + 重建 subchunks + 更新 chunk AABB。
     * <p>
     * 顶点数据: 重新 meshopt 编码 (可能被笔刷编辑过)。
     * 索引数据: 保留原始三角形顺序 (不排序)。
     * Chunk 结构: idxStart/vtxStart/idxCount/vtxCount 不变, AABB 更新 (雕刻后顶点可能超出原始范围)。
     * Subchunk: 地形 chunk 用 MIN-MAX 算法完全重建 (与原始文件生成方式一致),
     *           每个材质一个 subchunk, triStart/triEnd 为材质出现的三角形范围,
     *           triCount 为精确数量, vtxStart/vtxEnd/vtxCount 为对应顶点范围。
     *           subchunk 按 triEnd+matId 升序排列 (基础材质排在最后, 避免深度缓冲区遮挡)。
     *           云 chunk 的 subchunks 原样保留。
     * <p>
     * 渲染器使用顶点权重混合 (vertexColor), 不依赖 subchunk 材质 ID。
     * subchunk 用于游戏引擎的多 pass 材质渲染和碰撞检测。
     */
    private static byte[] exportPreservingOriginal(SceneObject meshesObj, String fileName) {
        MeshesParser.MeshesFile mf = meshesObj.sourceMeshes;
        List<MeshVertex> vertices = meshesObj.vertices;

        // 1. 如果顶点未修改, 直接输出原始文件
        if (!meshesObj.vertexModified && mf.rawFileData != null) {
            return mf.rawFileData;
        }

        // 2. 需要重新编码顶点
        int totalVerts = vertices.size();
        if (totalVerts == 0 || mf.geo0Raw == null) return null;

        byte[] rawVerts = new byte[totalVerts * VERTEX_SIZE];
        for (int i = 0; i < totalVerts; i++) {
            packVertex(vertices.get(i), rawVerts, i * VERTEX_SIZE);
        }
        int bound = MeshoptCodec.encodeVertexBufferBound(totalVerts, VERTEX_SIZE);
        byte[] compVerts = new byte[bound];
        int compSize = MeshoptCodec.encodeVertexBuffer(compVerts, bound, rawVerts, totalVerts, VERTEX_SIZE);
        if (compSize == 0) return null;

        // 3. 重建 GEO0: 压缩顶点 + 原始索引(不排序) + 更新 chunks + 重建 subchunks
        //    渲染器使用顶点权重混合 (vertexColor), 不依赖 subchunk 材质 ID。
        //    subchunk 仅用于游戏引擎的多 pass 材质渲染。
        //
        //    算法 (MIN-MAX, 与原始文件生成方式一致):
        //    - 保持原始三角形顺序 (不排序! 排序会破坏碰撞检测)
        //    - 每个材质一个 subchunk: triStart/triEnd = 材质出现的三角形范围
        //    - triCount = 精确的三角形数量 (游戏用于渲染和碰撞)
        //    - vtxStart/vtxEnd/vtxCount = 对应顶点范围 (精确匹配原始文件)
        //    - subchunk 按 triEnd+matId 升序排列 (165/165 chunk 100% 匹配原始文件)
        //    - subchunk 数量 = 材质数量 (通常 2-4, 与原始文件一致)
        int indexCount = mf.localIndices != null ? mf.localIndices.length : 0;
        int chunkCount = mf.chunkCount;
        int cloudCount = mf.cloudCount;

        // 3a. 保留原始局部索引 (不排序! 保持原始三角形顺序)
        byte[] localIndicesCopy = new byte[indexCount];
        if (mf.localIndices != null) {
            System.arraycopy(mf.localIndices, 0, localIndicesCopy, 0, Math.min(indexCount, mf.localIndices.length));
        }

        // 3b. 为每个地形 chunk 重建 subchunks (MIN-MAX 算法, 保持原始顺序); 云 chunk 保留原始
        List<int[]> newSubchunks = new ArrayList<>();
        int[] newSubStarts = new int[chunkCount + cloudCount];
        int[] newSubCounts = new int[chunkCount + cloudCount];

        for (int ci = 0; ci < chunkCount && ci < mf.chunks.size(); ci++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(ci);
            newSubStarts[ci] = newSubchunks.size();
            RebuildResult rb = rebuildChunkSubchunks(c, localIndicesCopy, vertices);
            // 不替换原始索引! 保持原始三角形顺序 (避免破坏碰撞检测)
            newSubchunks.addAll(rb.subchunks);
            newSubCounts[ci] = rb.subchunks.size();
        }

        // 云 chunk 的 subchunks 保持原样 (云顶点不被编辑)
        for (int ci = chunkCount; ci < chunkCount + cloudCount && ci < mf.chunks.size(); ci++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(ci);
            newSubStarts[ci] = newSubchunks.size();
            for (int si = 0; si < c.subchunkCount; si++) {
                int scIdx = c.subchunkStart + si;
                if (scIdx >= 0 && scIdx < mf.subchunks.size()) {
                    MeshesParser.MeshesSubchunk sc = mf.subchunks.get(scIdx);
                    newSubchunks.add(new int[]{
                            sc.materialId, sc.triCount, sc.vtxCount,
                            sc.triStart, sc.triEnd, sc.vtxStart, sc.vtxEnd
                    });
                }
            }
            newSubCounts[ci] = c.subchunkCount;
        }

        int newSubchunkCount = newSubchunks.size();

        // 3c. 构建 GEO0 段
        Writer geo = new Writer();
        geo.u32(indexCount);           // index_count
        geo.u32(totalVerts);           // vertex_count
        geo.u32(chunkCount);           // chunk_count
        geo.u32(cloudCount);           // cloud_count
        geo.u32(newSubchunkCount);     // subchunk_count (已更新)
        geo.u32(compSize);             // compressed vertex size
        // 压缩顶点数据
        byte[] compData = new byte[compSize];
        System.arraycopy(compVerts, 0, compData, 0, compSize);
        geo.bytes(compData);
        // u8 局部索引 (保持原始顺序, 不排序)
        for (int i = 0; i < indexCount; i++) geo.u8(localIndicesCopy[i]);
        // chunks (地形 + 云): 更新 subchunkStart / subchunkCount / AABB
        for (int ci = 0; ci < chunkCount + cloudCount && ci < mf.chunks.size(); ci++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(ci);
            geo.u32(c.idxStart);
            geo.u32(c.vtxStart);
            geo.u32(newSubStarts[ci]);  // 更新后的 subchunkStart
            geo.u16(c.idxCount);
            geo.u8(c.vtxCount);
            geo.u8(newSubCounts[ci]);   // 更新后的 subchunkCount
            // 更新 chunk AABB (顶点可能被雕刻移动, 旧的 AABB 会导致碰撞检测失效)
            if (ci < chunkCount) {
                float[] cmin = {1e30f, 1e30f, 1e30f};
                float[] cmax = {-1e30f, -1e30f, -1e30f};
                for (int vi = c.vtxStart; vi < c.vtxStart + c.vtxCount && vi < vertices.size(); vi++) {
                    MeshVertex v = vertices.get(vi);
                    cmin[0] = Math.min(cmin[0], v.position.x);
                    cmin[1] = Math.min(cmin[1], v.position.y);
                    cmin[2] = Math.min(cmin[2], v.position.z);
                    cmax[0] = Math.max(cmax[0], v.position.x);
                    cmax[1] = Math.max(cmax[1], v.position.y);
                    cmax[2] = Math.max(cmax[2], v.position.z);
                }
                // 添加 0.1 余量 (与参考项目一致)
                cmin[0] -= 0.1f; cmin[1] -= 0.1f; cmin[2] -= 0.1f;
                cmax[0] += 0.1f; cmax[1] += 0.1f; cmax[2] += 0.1f;
                geo.v3(cmin);
                geo.v3(cmax);
            } else {
                // 云 chunk 保留原始 AABB
                geo.v3(c.min);
                geo.v3(c.max);
            }
            geo.u32(0); geo.u32(0); geo.u32(0); geo.u32(0); // pad
        }
        // subchunks: 地形 (材质ID已更新) + 云 (原始)
        for (int[] sub : newSubchunks) {
            geo.u8(sub[0]); // materialId
            geo.u8(sub[1]); // triCount
            geo.u8(sub[2]); // vtxCount
            geo.u8(sub[3]); // triStart
            geo.u8(sub[4]); // triEnd
            geo.u8(sub[5]); // vtxStart
            geo.u8(sub[6]); // vtxEnd
            geo.u8(0);      // pad
        }

        byte[] newGeo0 = geo.toByteArray();

        // 4. 计算 bounding box (顶点可能被雕刻修改过)
        float[] gmin = {1e30f, 1e30f, 1e30f};
        float[] gmax = {-1e30f, -1e30f, -1e30f};
        for (MeshVertex v : vertices) {
            gmin[0] = Math.min(gmin[0], v.position.x); gmin[1] = Math.min(gmin[1], v.position.y); gmin[2] = Math.min(gmin[2], v.position.z);
            gmax[0] = Math.max(gmax[0], v.position.x); gmax[1] = Math.max(gmax[1], v.position.y); gmax[2] = Math.max(gmax[2], v.position.z);
        }

        // 5. 保留原始 DESC 和 LOD0
        byte[] desc = mf.descRaw;
        if (desc == null || desc.length == 0) {
            desc = ("SkyMeshEditor:" + (fileName != null ? fileName : "exported")).getBytes();
        }
        byte[] lodRaw = mf.lod0Raw;
        if (lodRaw == null || lodRaw.length == 0) {
            lodRaw = new byte[]{0x1B, 0, 1, 0, (byte) 0xC0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        }

        // 6. 构建 Header + TOC + DESC + LOD0 + GEO0
        return buildHeader(desc, lodRaw, newGeo0, mf.version, gmax, gmin);
    }

    // ======================== 方式2: 保留原始结构 + 追加新 chunk ========================

    /**
     * 保留原始 meshes 文件结构导出, 同时追加其他物体为新 chunk。
     * 顶点数据会被更新(可能被笔刷编辑过), chunk/subchunk/index 结构保持不变。
     */
    private static byte[] exportWithOriginalStructure(SceneObject meshesObj, List<SceneObject> otherObjs, String fileName) {
        MeshesParser.MeshesFile mf = meshesObj.sourceMeshes;
        List<MeshVertex> vertices = meshesObj.vertices;

        // 1. meshopt 编码顶点 (使用编辑后的顶点数据)
        int totalVerts = vertices.size();
        if (totalVerts == 0) return null;

        byte[] rawVerts = new byte[totalVerts * VERTEX_SIZE];
        for (int i = 0; i < totalVerts; i++) {
            packVertex(vertices.get(i), rawVerts, i * VERTEX_SIZE);
        }

        // 2. 收集其他物体的世界空间顶点和三角形
        List<MeshVertex> extraVerts = new ArrayList<>();
        List<int[]> extraTris = new ArrayList<>();  // 每个元素是 int[3], 引用 extraVerts 的索引
        List<Integer> extraVertMatId = new ArrayList<>();

        for (SceneObject obj : otherObjs) {
            int base = extraVerts.size();
            float[] m = obj.modelMatrix(null);
            for (MeshVertex v : obj.vertices) {
                MeshVertex wv = new MeshVertex(v);
                float[] pos4 = {v.position.x, v.position.y, v.position.z, 1.0f};
                float[] out4 = new float[4];
                Matrix.multiplyMV(out4, 0, m, 0, pos4, 0);
                wv.position.set(out4[0], out4[1], out4[2]);
                float[] nrm4 = {v.normal[0], v.normal[1], v.normal[2], 0.0f};
                float[] outN = new float[4];
                Matrix.multiplyMV(outN, 0, m, 0, nrm4, 0);
                wv.normal[0] = outN[0];
                wv.normal[1] = outN[1];
                wv.normal[2] = outN[2];
                if (obj.kind != ObjKind.MeshesTerrain) {
                    wv.materialIds[0] = obj.baseMaterialId;
                    wv.materialWeights[0] = 1.0f;
                    for (int k = 1; k < 4; k++) {
                        wv.materialIds[k] = 0;
                        wv.materialWeights[k] = 0;
                    }
                }
                extraVerts.add(wv);
                int best = 0; float bw = -1;
                for (int k = 0; k < 4; k++) {
                    if (wv.materialWeights[k] > bw) { bw = wv.materialWeights[k]; best = k; }
                }
                extraVertMatId.add(wv.materialIds[best]);
            }
            for (int i = 0; i + 2 < obj.indices.size(); i += 3) {
                extraTris.add(new int[]{
                    base + obj.indices.get(i),
                    base + obj.indices.get(i + 1),
                    base + obj.indices.get(i + 2)
                });
            }
        }

        // 3. 为额外物体构建 chunk (确保不丢面, 顶点可跨 chunk 复制)
        List<ChunkOut> extraChunks = new ArrayList<>();
        List<SubOut> extraSubs = new ArrayList<>();
        List<Byte> extraLocalIndices = new ArrayList<>();  // u8 局部索引
        List<MeshVertex> chunkedExtraVerts = new ArrayList<>();  // 分块后的顶点 (可能含重复)

        int triIdx = 0;
        while (triIdx < extraTris.size()) {
            ChunkOut c = new ChunkOut();
            c.vtxStart = totalVerts + chunkedExtraVerts.size();
            c.idxStart = (mf.localIndices != null ? mf.localIndices.length : 0) + extraLocalIndices.size();
            c.subStart = (mf.subchunkCount) + extraSubs.size();

            Map<Integer, Integer> vtxMap = new HashMap<Integer, Integer>();
            List<MeshVertex> chunkVerts = new ArrayList<>();
            List<Byte> chunkIdx = new ArrayList<>();
            List<Integer> chunkTriMats = new ArrayList<>();  // 每个三角形的材质

            // 添加三角形到当前 chunk, 不超过 MAX_VTX_PER_CHUNK 顶点
            while (triIdx < extraTris.size()) {
                int[] tri = extraTris.get(triIdx);
                int needed = 0;
                for (int v : tri) {
                    if (!vtxMap.containsKey(Integer.valueOf(v))) needed++;
                }
                if (chunkVerts.size() + needed > MAX_VTX_PER_CHUNK && !chunkVerts.isEmpty()) {
                    break;  // 开始新 chunk
                }
                for (int v : tri) {
                    Integer key = Integer.valueOf(v);
                    if (!vtxMap.containsKey(key)) {
                        vtxMap.put(key, Integer.valueOf(chunkVerts.size()));
                        chunkVerts.add(extraVerts.get(v));
                    }
                    chunkIdx.add((byte)(vtxMap.get(key).intValue() & 0xFF));
                }
                // 取三角形第一个顶点的材质
                chunkTriMats.add(extraVertMatId.get(tri[0]));
                triIdx++;
            }

            c.vtxCount = chunkVerts.size();
            c.idxCount = chunkIdx.size();
            chunkedExtraVerts.addAll(chunkVerts);
            for (byte b : chunkIdx) extraLocalIndices.add(b);

            // 构建 subchunks (按材质分组连续三角形)
            int scStart = 0;
            while (scStart < chunkTriMats.size()) {
                int mat = chunkTriMats.get(scStart);
                int scEnd = scStart;
                while (scEnd + 1 < chunkTriMats.size() && chunkTriMats.get(scEnd + 1) == mat) {
                    scEnd++;
                }
                int nTri = scEnd - scStart + 1;
                // 如果三角形数超过 255, 拆分
                int scTriStart = scStart;
                while (nTri > 0) {
                    int batch = Math.min(nTri, 255);
                    SubOut sc = new SubOut();
                    sc.matId = mat;
                    sc.triCount = batch;
                    sc.vtxCount = Math.min(chunkVerts.size(), 255);
                    sc.triStart = Math.min(scTriStart, 255);
                    sc.triEnd = Math.min(scTriStart + batch - 1, 255);
                    sc.vtxStart = 0;
                    sc.vtxEnd = Math.min(chunkVerts.size() - 1, 255);
                    extraSubs.add(sc);
                    scTriStart += batch;
                    nTri -= batch;
                }
                scStart = scEnd + 1;
            }

            c.subCount = extraSubs.size() - (c.subStart - mf.subchunkCount);

            // 包围盒
            c.min = new float[]{1e30f, 1e30f, 1e30f};
            c.max = new float[]{-1e30f, -1e30f, -1e30f};
            for (MeshVertex v : chunkVerts) {
                c.min[0] = Math.min(c.min[0], v.position.x); c.min[1] = Math.min(c.min[1], v.position.y); c.min[2] = Math.min(c.min[2], v.position.z);
                c.max[0] = Math.max(c.max[0], v.position.x); c.max[1] = Math.max(c.max[1], v.position.y); c.max[2] = Math.max(c.max[2], v.position.z);
            }
            c.min[0] -= 0.1f; c.min[1] -= 0.1f; c.min[2] -= 0.1f;
            c.max[0] += 0.1f; c.max[1] += 0.1f; c.max[2] += 0.1f;
            extraChunks.add(c);
        }

        // 4. 合并顶点: 原始顶点 + 额外顶点
        int allVertCount = totalVerts + chunkedExtraVerts.size();
        byte[] allRawVerts = new byte[allVertCount * VERTEX_SIZE];
        System.arraycopy(rawVerts, 0, allRawVerts, 0, totalVerts * VERTEX_SIZE);
        for (int i = 0; i < chunkedExtraVerts.size(); i++) {
            packVertex(chunkedExtraVerts.get(i), allRawVerts, (totalVerts + i) * VERTEX_SIZE);
        }
        int bound = MeshoptCodec.encodeVertexBufferBound(allVertCount, VERTEX_SIZE);
        byte[] compVerts = new byte[bound];
        int compSize = MeshoptCodec.encodeVertexBuffer(compVerts, bound, allRawVerts, allVertCount, VERTEX_SIZE);
        if (compSize == 0) return null;

        // 5. 合并索引 (地形索引会被 subchunk 重建时排序, 额外索引保持原序)
        byte[] localIndices;
        if (mf.localIndices != null) {
            localIndices = new byte[mf.localIndices.length];
            System.arraycopy(mf.localIndices, 0, localIndices, 0, mf.localIndices.length);
        } else {
            localIndices = new byte[0];
        }
        int allIdxCount = localIndices.length + extraLocalIndices.size();

        // 6. 计算 bounds
        float[] gmin = {1e30f, 1e30f, 1e30f};
        float[] gmax = {-1e30f, -1e30f, -1e30f};
        for (MeshVertex v : vertices) {
            gmin[0] = Math.min(gmin[0], v.position.x); gmin[1] = Math.min(gmin[1], v.position.y); gmin[2] = Math.min(gmin[2], v.position.z);
            gmax[0] = Math.max(gmax[0], v.position.x); gmax[1] = Math.max(gmax[1], v.position.y); gmax[2] = Math.max(gmax[2], v.position.z);
        }
        for (MeshVertex v : chunkedExtraVerts) {
            gmin[0] = Math.min(gmin[0], v.position.x); gmin[1] = Math.min(gmin[1], v.position.y); gmin[2] = Math.min(gmin[2], v.position.z);
            gmax[0] = Math.max(gmax[0], v.position.x); gmax[1] = Math.max(gmax[1], v.position.y); gmax[2] = Math.max(gmax[2], v.position.z);
        }

        // 7. 保留原始 DESC 和 LOD0
        byte[] desc = mf.descRaw;
        if (desc == null || desc.length == 0) {
            desc = ("SkyMeshEditor:" + (fileName != null ? fileName : "exported")).getBytes();
        }
        byte[] lodRaw = mf.lod0Raw;
        if (lodRaw == null || lodRaw.length == 0) {
            lodRaw = new byte[]{0x1B, 0, 1, 0, (byte) 0xC0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
        }

        // 8. 构建 GEO0 段
        // 8a. 重建地形 subchunks (MIN-MAX 算法, 保持原始三角形顺序)
        List<int[]> rebuiltTerrainSubs = new ArrayList<>();
        int[] terrainNewSubStarts = new int[mf.chunkCount];
        int[] terrainNewSubCounts = new int[mf.chunkCount];
        for (int ci = 0; ci < mf.chunkCount && ci < mf.chunks.size(); ci++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(ci);
            terrainNewSubStarts[ci] = rebuiltTerrainSubs.size();
            RebuildResult rb = rebuildChunkSubchunks(c, localIndices, vertices);
            // 不替换原始索引! 保持原始三角形顺序 (避免破坏碰撞检测)
            rebuiltTerrainSubs.addAll(rb.subchunks);
            terrainNewSubCounts[ci] = rb.subchunks.size();
        }
        int rebuiltTerrainSubCount = rebuiltTerrainSubs.size();

        // 8b. 调整额外 chunk 的 subStart (地形 subchunk 数可能变了)
        int subOffset = rebuiltTerrainSubCount;
        for (ChunkOut c : extraChunks) {
            c.subStart = subOffset;
            subOffset += c.subCount;
        }

        // 8c. 云 chunk 的 subchunkStart 也需要调整
        int cloudSubStart = subOffset; // 云 subchunk 紧跟在额外 subchunk 后面

        // 8d. 计算云 subchunk 总数
        int cloudSubCount = 0;
        for (int i = mf.chunkCount; i < mf.chunkCount + mf.cloudCount && i < mf.chunks.size(); i++) {
            cloudSubCount += mf.chunks.get(i).subchunkCount;
        }

        int totalChunkCount = mf.chunkCount + extraChunks.size();
        int totalCloudCount = mf.cloudCount;
        int totalSubCount = rebuiltTerrainSubCount + extraSubs.size() + cloudSubCount;

        Writer geo = new Writer();
        geo.u32(allIdxCount);           // index_count
        geo.u32(allVertCount);          // vertex_count
        geo.u32(totalChunkCount);       // chunk_count (地形, 不含云)
        geo.u32(totalCloudCount);       // cloud_chunk_count
        geo.u32(totalSubCount);         // subchunk_count (已更新)
        geo.u32(compSize);              // compressed vertex size
        byte[] compData = new byte[compSize];
        System.arraycopy(compVerts, 0, compData, 0, compSize);
        geo.bytes(compData);

        // u8 索引: 地形(保持原始顺序) + 额外
        for (byte idx : localIndices) geo.u8(idx);
        for (Byte idx : extraLocalIndices) geo.u8(idx.intValue());

        // chunks: 地形 (更新 subchunkStart/subchunkCount/AABB)
        for (int ci = 0; ci < mf.chunkCount && ci < mf.chunks.size(); ci++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(ci);
            geo.u32(c.idxStart);
            geo.u32(c.vtxStart);
            geo.u32(terrainNewSubStarts[ci]);  // 更新后的 subchunkStart
            geo.u16(c.idxCount);
            geo.u8(c.vtxCount);
            geo.u8(terrainNewSubCounts[ci]);   // 更新后的 subchunkCount
            // 更新 chunk AABB (顶点可能被雕刻移动)
            float[] cmin = {1e30f, 1e30f, 1e30f};
            float[] cmax = {-1e30f, -1e30f, -1e30f};
            for (int vi = c.vtxStart; vi < c.vtxStart + c.vtxCount && vi < vertices.size(); vi++) {
                MeshVertex v = vertices.get(vi);
                cmin[0] = Math.min(cmin[0], v.position.x);
                cmin[1] = Math.min(cmin[1], v.position.y);
                cmin[2] = Math.min(cmin[2], v.position.z);
                cmax[0] = Math.max(cmax[0], v.position.x);
                cmax[1] = Math.max(cmax[1], v.position.y);
                cmax[2] = Math.max(cmax[2], v.position.z);
            }
            cmin[0] -= 0.1f; cmin[1] -= 0.1f; cmin[2] -= 0.1f;
            cmax[0] += 0.1f; cmax[1] += 0.1f; cmax[2] += 0.1f;
            geo.v3(cmin);
            geo.v3(cmax);
            geo.u32(0); geo.u32(0); geo.u32(0); geo.u32(0); // pad
        }
        // 额外 chunks
        for (ChunkOut c : extraChunks) {
            geo.u32(c.idxStart);
            geo.u32(c.vtxStart);
            geo.u32(c.subStart);
            geo.u16(c.idxCount);
            geo.u8(c.vtxCount);
            geo.u8(c.subCount);
            geo.v3(c.min);
            geo.v3(c.max);
            geo.u32(0); geo.u32(0); geo.u32(0); geo.u32(0); // pad
        }

        // cloud chunks: 更新 subchunkStart
        int cloudSubOffset = cloudSubStart;
        for (int i = mf.chunkCount; i < mf.chunkCount + mf.cloudCount && i < mf.chunks.size(); i++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(i);
            geo.u32(c.idxStart);
            geo.u32(c.vtxStart);
            geo.u32(cloudSubOffset);  // 更新后的 subchunkStart
            geo.u16(c.idxCount);
            geo.u8(c.vtxCount);
            geo.u8(c.subchunkCount);
            geo.v3(c.min);
            geo.v3(c.max);
            geo.u32(0); geo.u32(0); geo.u32(0); geo.u32(0); // pad
            cloudSubOffset += c.subchunkCount;
        }

        // subchunks: 地形(材质ID已更新) + 额外 + 云
        for (int[] sub : rebuiltTerrainSubs) {
            geo.u8(sub[0]); // materialId
            geo.u8(sub[1]); // triCount
            geo.u8(sub[2]); // vtxCount
            geo.u8(sub[3]); // triStart
            geo.u8(sub[4]); // triEnd
            geo.u8(sub[5]); // vtxStart
            geo.u8(sub[6]); // vtxEnd
            geo.u8(0);      // pad
        }
        for (SubOut sc : extraSubs) {
            geo.u8(sc.matId);
            geo.u8(sc.triCount);
            geo.u8(sc.vtxCount);
            geo.u8(sc.triStart);
            geo.u8(sc.triEnd);
            geo.u8(sc.vtxStart);
            geo.u8(sc.vtxEnd);
            geo.u8(0); // pad
        }
        // 云 subchunks: 保留原始数据 (云顶点不被编辑)
        for (int i = mf.chunkCount; i < mf.chunkCount + mf.cloudCount && i < mf.chunks.size(); i++) {
            MeshesParser.MeshesChunk c = mf.chunks.get(i);
            for (int si = 0; si < c.subchunkCount; si++) {
                int scIdx = c.subchunkStart + si;
                if (scIdx >= 0 && scIdx < mf.subchunks.size()) {
                    MeshesParser.MeshesSubchunk sc = mf.subchunks.get(scIdx);
                    geo.u8(sc.materialId);
                    geo.u8(sc.triCount);
                    geo.u8(sc.vtxCount);
                    geo.u8(sc.triStart);
                    geo.u8(sc.triEnd);
                    geo.u8(sc.vtxStart);
                    geo.u8(sc.vtxEnd);
                    geo.u8(0); // pad
                }
            }
        }

        // 9. 构建 Header + TOC
        return buildHeader(desc, lodRaw, geo.toByteArray(), mf.version, gmax, gmin);
    }

    // ======================== 方式3: 从零构建 (无原始数据) ========================

    /**
     * 从零构建完整 .meshes 文件。
     * 使用贪心分块算法, 确保不丢面: 跨 chunk 的三角形通过顶点复制保留。
     */
    private static byte[] exportFromScratch(Scene scene, String fileName) {
        // 1. 收集所有物体的世界空间顶点和三角形
        List<MeshVertex> allVerts = new ArrayList<>();
        List<int[]> allTris = new ArrayList<>();
        List<Integer> vertMatId = new ArrayList<>();

        for (SceneObject obj : scene.objects) {
            int base = allVerts.size();
            float[] m = obj.modelMatrix(null);

            for (MeshVertex v : obj.vertices) {
                MeshVertex wv = new MeshVertex(v);
                float[] pos4 = {v.position.x, v.position.y, v.position.z, 1.0f};
                float[] out4 = new float[4];
                Matrix.multiplyMV(out4, 0, m, 0, pos4, 0);
                wv.position.set(out4[0], out4[1], out4[2]);
                float[] nrm4 = {v.normal[0], v.normal[1], v.normal[2], 0.0f};
                float[] outN = new float[4];
                Matrix.multiplyMV(outN, 0, m, 0, nrm4, 0);
                wv.normal[0] = outN[0];
                wv.normal[1] = outN[1];
                wv.normal[2] = outN[2];
                if (obj.kind != ObjKind.MeshesTerrain) {
                    wv.materialIds[0] = obj.baseMaterialId;
                    wv.materialWeights[0] = 1.0f;
                    for (int k = 1; k < 4; k++) {
                        wv.materialIds[k] = 0;
                        wv.materialWeights[k] = 0;
                    }
                }
                allVerts.add(wv);
                int best = 0; float bw = -1;
                for (int k = 0; k < 4; k++) {
                    if (wv.materialWeights[k] > bw) { bw = wv.materialWeights[k]; best = k; }
                }
                vertMatId.add(wv.materialIds[best]);
            }
            for (int i = 0; i + 2 < obj.indices.size(); i += 3) {
                allTris.add(new int[]{
                    base + obj.indices.get(i),
                    base + obj.indices.get(i + 1),
                    base + obj.indices.get(i + 2)
                });
            }
        }

        if (allVerts.isEmpty() || allTris.isEmpty()) return null;

        // 2. 贪心分块: 确保不丢面, 顶点可跨 chunk 复制
        List<ChunkOut> chunks = new ArrayList<>();
        List<SubOut> subchunks = new ArrayList<>();
        List<Byte> outIndices = new ArrayList<>();   // u8 局部索引
        List<MeshVertex> outVerts = new ArrayList<>();  // 分块后的顶点 (可能含重复)

        int triIdx = 0;
        while (triIdx < allTris.size()) {
            ChunkOut c = new ChunkOut();
            c.vtxStart = outVerts.size();
            c.idxStart = outIndices.size();
            c.subStart = subchunks.size();

            Map<Integer, Integer> vtxMap = new HashMap<Integer, Integer>();
            List<MeshVertex> chunkVerts = new ArrayList<>();
            List<Byte> chunkIdx = new ArrayList<>();
            List<Integer> chunkTriMats = new ArrayList<>();

            // 添加三角形到当前 chunk
            while (triIdx < allTris.size()) {
                int[] tri = allTris.get(triIdx);
                int needed = 0;
                for (int v : tri) {
                    if (!vtxMap.containsKey(Integer.valueOf(v))) needed++;
                }
                if (chunkVerts.size() + needed > MAX_VTX_PER_CHUNK && !chunkVerts.isEmpty()) {
                    break;  // 开始新 chunk
                }
                for (int v : tri) {
                    Integer key = Integer.valueOf(v);
                    if (!vtxMap.containsKey(key)) {
                        vtxMap.put(key, Integer.valueOf(chunkVerts.size()));
                        chunkVerts.add(allVerts.get(v));
                    }
                    chunkIdx.add((byte)(vtxMap.get(key).intValue() & 0xFF));
                }
                chunkTriMats.add(vertMatId.get(tri[0]));
                triIdx++;
            }

            c.vtxCount = chunkVerts.size();
            c.idxCount = chunkIdx.size();
            outVerts.addAll(chunkVerts);
            for (byte b : chunkIdx) outIndices.add(b);

            // 构建 subchunks (按材质分组连续三角形)
            int scStart = 0;
            while (scStart < chunkTriMats.size()) {
                int mat = chunkTriMats.get(scStart);
                int scEnd = scStart;
                while (scEnd + 1 < chunkTriMats.size() && chunkTriMats.get(scEnd + 1) == mat) {
                    scEnd++;
                }
                int nTri = scEnd - scStart + 1;
                int scTriStart = scStart;
                while (nTri > 0) {
                    int batch = Math.min(nTri, 255);
                    SubOut sc = new SubOut();
                    sc.matId = mat;
                    sc.triCount = batch;
                    sc.vtxCount = Math.min(chunkVerts.size(), 255);
                    sc.triStart = Math.min(scTriStart, 255);
                    sc.triEnd = Math.min(scTriStart + batch - 1, 255);
                    sc.vtxStart = 0;
                    sc.vtxEnd = Math.min(chunkVerts.size() - 1, 255);
                    subchunks.add(sc);
                    scTriStart += batch;
                    nTri -= batch;
                }
                scStart = scEnd + 1;
            }

            c.subCount = subchunks.size() - c.subStart;

            // 包围盒
            c.min = new float[]{1e30f, 1e30f, 1e30f};
            c.max = new float[]{-1e30f, -1e30f, -1e30f};
            for (MeshVertex v : chunkVerts) {
                c.min[0] = Math.min(c.min[0], v.position.x); c.min[1] = Math.min(c.min[1], v.position.y); c.min[2] = Math.min(c.min[2], v.position.z);
                c.max[0] = Math.max(c.max[0], v.position.x); c.max[1] = Math.max(c.max[1], v.position.y); c.max[2] = Math.max(c.max[2], v.position.z);
            }
            c.min[0] -= 0.1f; c.min[1] -= 0.1f; c.min[2] -= 0.1f;
            c.max[0] += 0.1f; c.max[1] += 0.1f; c.max[2] += 0.1f;
            chunks.add(c);
        }

        // 3. meshopt 编码顶点
        int totalVerts = outVerts.size();
        byte[] rawVerts = new byte[totalVerts * VERTEX_SIZE];
        for (int i = 0; i < totalVerts; i++) {
            packVertex(outVerts.get(i), rawVerts, i * VERTEX_SIZE);
        }
        int bound = MeshoptCodec.encodeVertexBufferBound(totalVerts, VERTEX_SIZE);
        byte[] compVerts = new byte[bound];
        int compSize = MeshoptCodec.encodeVertexBuffer(compVerts, bound, rawVerts, totalVerts, VERTEX_SIZE);
        if (compSize == 0) return null;

        // 4. bounds
        float[] gmin = {1e30f, 1e30f, 1e30f};
        float[] gmax = {-1e30f, -1e30f, -1e30f};
        for (MeshVertex v : outVerts) {
            gmin[0] = Math.min(gmin[0], v.position.x); gmin[1] = Math.min(gmin[1], v.position.y); gmin[2] = Math.min(gmin[2], v.position.z);
            gmax[0] = Math.max(gmax[0], v.position.x); gmax[1] = Math.max(gmax[1], v.position.y); gmax[2] = Math.max(gmax[2], v.position.z);
        }

        // 5. DESC/LOD0
        byte[] desc = ("SkyMeshEditor:" + (fileName != null ? fileName : "exported")).getBytes();
        byte[] lodRaw = new byte[]{0x1B, 0, 1, 0, (byte) 0xC0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};

        // 6. GEO0
        Writer geo = new Writer();
        geo.u32(outIndices.size());
        geo.u32(totalVerts);
        geo.u32(chunks.size());
        geo.u32(0);  // cloud_chunk_count = 0
        geo.u32(subchunks.size());
        geo.u32(compSize);
        byte[] compData = new byte[compSize];
        System.arraycopy(compVerts, 0, compData, 0, compSize);
        geo.bytes(compData);
        for (Byte idx : outIndices) geo.u8(idx.intValue());
        for (ChunkOut c : chunks) {
            geo.u32(c.idxStart);
            geo.u32(c.vtxStart);
            geo.u32(c.subStart);
            geo.u16(c.idxCount);
            geo.u8(c.vtxCount);
            geo.u8(c.subCount);
            geo.v3(c.min);
            geo.v3(c.max);
            geo.u32(0); geo.u32(0); geo.u32(0); geo.u32(0);
        }
        for (SubOut sc : subchunks) {
            geo.u8(sc.matId);
            geo.u8(sc.triCount);
            geo.u8(sc.vtxCount);
            geo.u8(sc.triStart);
            geo.u8(sc.triEnd);
            geo.u8(sc.vtxStart);
            geo.u8(sc.vtxEnd);
            geo.u8(0);
        }

        return buildHeader(desc, lodRaw, geo.toByteArray(), 0x3C, gmax, gmin);
    }

    // ======================== 构建 Header + TOC ========================

    private static byte[] buildHeader(byte[] desc, byte[] lodRaw, byte[] geoData, int version, float[] gmax, float[] gmin) {
        int headerLen = 136;
        int descOff = headerLen;
        int lodOff = descOff + desc.length;
        int geoOff = lodOff + lodRaw.length;

        Writer hdr = new Writer();
        hdr.u32(MAGIC_LVL0);
        hdr.u32(version);
        // TOC: 100 bytes = u32(3) + 3×(4B name + 4B off + 4B len)
        Writer tw = new Writer();
        tw.u32(3);
        writeSeg(tw, "DESC", descOff, desc.length);
        writeSeg(tw, "LOD0", lodOff, lodRaw.length);
        writeSeg(tw, "GEO0", geoOff, geoData.length);
        byte[] toc = tw.toByteArray();
        byte[] tocPadded = new byte[100];
        System.arraycopy(toc, 0, tocPadded, 0, Math.min(toc.length, 100));
        hdr.bytes(tocPadded);
        hdr.u32(0); // padding
        hdr.v3(gmax);
        hdr.v3(gmin);

        // 组装最终结果
        byte[] result = new byte[hdr.size() + desc.length + lodRaw.length + geoData.length];
        int off = 0;
        byte[] hdrData = hdr.toByteArray();
        System.arraycopy(hdrData, 0, result, off, hdrData.length); off += hdrData.length;
        System.arraycopy(desc, 0, result, off, desc.length); off += desc.length;
        System.arraycopy(lodRaw, 0, result, off, lodRaw.length); off += lodRaw.length;
        System.arraycopy(geoData, 0, result, off, geoData.length);
        return result;
    }

    private static void writeSeg(Writer w, String name, int off, int len) {
        byte[] nb = new byte[4];
        byte[] nameBytes = name.getBytes();
        int copyLen = Math.min(nameBytes.length, 4);
        System.arraycopy(nameBytes, 0, nb, 0, copyLen);
        w.bytes(nb);
        w.u32(off);
        w.u32(len);
    }

    // ======================== 内部数据类 ========================

    private static class ChunkOut {
        int vtxStart, idxStart, subStart;
        int idxCount;
        int vtxCount, subCount;
        float[] min, max;
    }

    private static class SubOut {
        int matId, triCount, vtxCount, triStart, triEnd, vtxStart, vtxEnd;
    }
}
