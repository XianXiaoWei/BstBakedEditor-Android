package com.skymesh.editor;

/**
 * 可编辑网格顶点。对应 C++ 的 MeshVertex。
 * 顶点打包格式（.meshes 36 字节/顶点）：
 *   position float×3 (12B) + normal snorm8×4 (4B) + materialIds u8×4 (4B) +
 *   materialWeights unorm8×4 (4B) + input2 unorm8×4 (4B) + input3 unorm8×4 (4B) + input4 unorm8×4 (4B)
 */
public final class MeshVertex {
    public final Vec3 position = new Vec3();
    /** 法线（w 备用），对应 C++ QVector4D normal */
    public final float[] normal = new float[4];
    /** 最多 4 个材质槽 ID */
    public final int[] materialIds = new int[4];
    /** 对应材质槽权重（0..1） */
    public final float[] materialWeights = new float[4];
    /** AO / 粗糙度 */
    public final float[] input2 = new float[4];
    /** 细节纹理 */
    public final float[] input3 = new float[4];
    /** 其他 */
    public final float[] input4 = new float[4];

    public MeshVertex() {}

    public MeshVertex(MeshVertex o) {
        position.set(o.position);
        System.arraycopy(o.normal, 0, normal, 0, 4);
        System.arraycopy(o.materialIds, 0, materialIds, 0, 4);
        System.arraycopy(o.materialWeights, 0, materialWeights, 0, 4);
        System.arraycopy(o.input2, 0, input2, 0, 4);
        System.arraycopy(o.input3, 0, input3, 0, 4);
        System.arraycopy(o.input4, 0, input4, 0, 4);
    }
}
