package com.skymesh.editor;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

/**
 * OpenGL ES 2.0 编辑视图 — 参照 SkyModelViewer-Android 的触摸交互。
 * <p>
 * 触摸规则:
 * <ul>
 *   <li>单指拖动 → 旋转视角 (orbit)</li>
 *   <li>双指捏合 → 缩放 (ScaleGestureDetector 优先识别)</li>
 *   <li>双指拖动 (非缩放) → 平移视角 (pan)</li>
 * </ul>
 * 渲染模式为 RENDERMODE_WHEN_DIRTY，每次触摸后调用 requestRender() 重绘。
 */
public class EditorGLView extends GLSurfaceView {

    /** 相机移动回调 (用于更新状态栏等 UI) */
    public interface OnCameraMoveListener {
        void onCameraMove();
    }

    private final GLRenderer renderer;
    private final ScaleGestureDetector scaleDetector;
    private OnCameraMoveListener cameraMoveListener;

    private float lastX = 0f;
    private float lastY = 0f;
    private int pointerCount = 1;

    public void setOnCameraMoveListener(OnCameraMoveListener l) {
        this.cameraMoveListener = l;
    }

    public EditorGLView(Context context) {
        super(context);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        renderer = new GLRenderer();
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float factor = 1f / detector.getScaleFactor();
                renderer.onZoom(factor);
                return true;
            }
        });
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    public EditorGLView(Context context, android.util.AttributeSet attrs) {
        super(context, attrs);
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        renderer = new GLRenderer();
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float factor = 1f / detector.getScaleFactor();
                renderer.onZoom(factor);
                return true;
            }
        });
        setRenderer(renderer);
        setRenderMode(GLSurfaceView.RENDERMODE_WHEN_DIRTY);
    }

    public GLRenderer getRenderer() {
        return renderer;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        // ScaleGestureDetector 优先处理
        scaleDetector.onTouchEvent(event);

        int action = event.getActionMasked();

        switch (action) {
            case MotionEvent.ACTION_DOWN: {
                // 检查是否点击了导航 Gizmo
                if (renderer.isGizmoArea(event.getX(), event.getY())) {
                    renderer.handleGizmoClick(event.getX(), event.getY());
                    requestRender();
                    return true;
                }
                lastX = event.getX();
                lastY = event.getY();
                pointerCount = 1;
                renderer.onTouchDown(event.getX(), event.getY());
                break;
            }

            case MotionEvent.ACTION_POINTER_DOWN: {
                pointerCount = 2;
                // 双指按下时取消单指操作
                renderer.onTouchUp();
                lastX = event.getX();
                lastY = event.getY();
                break;
            }

            case MotionEvent.ACTION_MOVE: {
                if (pointerCount >= 2 && !scaleDetector.isInProgress()) {
                    // 双指拖动 (非缩放) → 平移
                    float dx = event.getX() - lastX;
                    float dy = event.getY() - lastY;
                    renderer.onPan(dx, dy);
                } else if (pointerCount < 2 && !scaleDetector.isInProgress()) {
                    // 单指拖动 → 旋转 或 工具操作
                    int idx = event.getActionIndex();
                    float x = event.getX(idx);
                    float y = event.getY(idx);
                    renderer.onTouchMove(x, y);
                }
                lastX = event.getX();
                lastY = event.getY();
                break;
            }

            case MotionEvent.ACTION_POINTER_UP: {
                pointerCount = Math.max(pointerCount - 1, 1);
                lastX = event.getX();
                lastY = event.getY();
                if (pointerCount == 1) {
                    // 回到单指模式
                    int remainingIdx = (event.getActionIndex() == 0) ? 1 : 0;
                    if (remainingIdx < event.getPointerCount()) {
                        renderer.onTouchDown(event.getX(remainingIdx), event.getY(remainingIdx));
                    }
                }
                break;
            }

            case MotionEvent.ACTION_UP: {
                if (pointerCount == 1) {
                    renderer.onTouchUp();
                }
                pointerCount = 1;
                break;
            }

            case MotionEvent.ACTION_CANCEL: {
                renderer.onTouchUp();
                pointerCount = 1;
                break;
            }
        }

        requestRender();
        if (cameraMoveListener != null && action == MotionEvent.ACTION_MOVE) {
            cameraMoveListener.onCameraMove();
        }
        return true;
    }
}
