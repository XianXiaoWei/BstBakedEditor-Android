package com.skymesh.editor;

/**
 * meshoptimizer 顶点缓冲区编解码器的 Java 移植（标量实现）。
 * 对应 C++ third_party/meshoptimizer/vertexcodec.cpp 的标量（非 SIMD）路径。
 *
 * - decodeVertexBuffer: 完整支持 version 0 与 version 1（含 channel 0/1/2 + 旋转），
 *   可解码游戏原始 .meshes 顶点数据。
 * - encodeVertexBuffer: 使用 version 1 / level 0 编码（channel 0 zigzag8），
 *   输出可被本解码器及官方 meshopt 正确解码。
 *
 * 顶点数据布局（36 字节/顶点，本编辑器固定）：
 *   position f32×3 + normal snorm8×4 + materialIds u8×4 + materialWeights unorm8×4
 *   + input2/3/4 unorm8×4
 */
final class MeshoptCodec {

    private MeshoptCodec() {}

    static final int K_VERTEX_HEADER = 0xA0;
    static final int K_DECODE_VERSION = 1;
    static final int K_BLOCK_SIZE_BYTES = 8192;
    static final int K_BLOCK_MAX_SIZE = 256;
    static final int K_BYTE_GROUP_SIZE = 16;
    static final int K_BYTE_GROUP_DECODE_LIMIT = 24;
    static final int K_TAIL_MIN_V0 = 32;
    static final int K_TAIL_MIN_V1 = 24;

    static final int[] K_BITS_V0 = {0, 2, 4, 8};
    // version 1, ctrl=0 -> {0,1,2,4}; ctrl=1 -> {1,2,4,8}
    static final int[] K_BITS_V1_C0 = {0, 1, 2, 4};
    static final int[] K_BITS_V1_C1 = {1, 2, 4, 8};

    // ------------------------------------------------------------------
    //  解码
    // ------------------------------------------------------------------

    /**
     * 解码压缩顶点缓冲区。
     * @param destination 输出，长度 >= vertexCount * vertexSize
     * @param buffer      压缩数据
     * @param bufferOffset 压缩数据起始偏移
     * @param bufferSize  压缩数据有效长度
     * @return 0 成功；-1 头部无效；-2 数据不足/损坏；-3 尾部不匹配
     */
    static int decodeVertexBuffer(byte[] destination, int vertexCount, int vertexSize,
                                  byte[] buffer, int bufferOffset, int bufferSize) {
        int pos = bufferOffset;
        int end = bufferOffset + bufferSize;
        if (end - pos < 1) return -2;
        int header = buffer[pos++] & 0xFF;
        if ((header & 0xF0) != K_VERTEX_HEADER) return -1;
        int version = header & 0x0F;
        if (version > K_DECODE_VERSION) return -1;

        int tailSize = vertexSize + (version == 0 ? 0 : vertexSize / 4);
        int tailMin = version == 0 ? K_TAIL_MIN_V0 : K_TAIL_MIN_V1;
        int tailPad = Math.max(tailSize, tailMin);
        if (end - pos < tailPad) return -2;

        int tailPos = end - tailSize;
        byte[] lastVertex = new byte[256];
        System.arraycopy(buffer, tailPos, lastVertex, 0, vertexSize);

        byte[] channels = null;
        if (version != 0) {
            channels = new byte[vertexSize / 4];
            System.arraycopy(buffer, tailPos + vertexSize, channels, 0, vertexSize / 4);
        }

        int blockSize = getVertexBlockSize(vertexSize);
        byte[] deltaBuf = new byte[K_BLOCK_MAX_SIZE * 4];
        byte[] transposed = new byte[K_BLOCK_SIZE_BYTES];

        int vertexOffset = 0;
        while (vertexOffset < vertexCount) {
            int bs = (vertexOffset + blockSize < vertexCount) ? blockSize : vertexCount - vertexOffset;
            int np = decodeVertexBlock(buffer, pos, end, destination, vertexOffset, bs,
                    vertexSize, lastVertex, channels, version, deltaBuf, transposed);
            if (np < 0) return -2;
            pos = np;
            vertexOffset += bs;
        }
        if (end - pos != tailPad) return -3;
        return 0;
    }

    private static int decodeVertexBlock(byte[] data, int pos, int end, byte[] vertexData,
                                         int vertexOffset, int vertexCount, int vertexSize,
                                         byte[] lastVertex, byte[] channels, int version,
                                         byte[] buffer, byte[] transposed) {
        int aligned = (vertexCount + K_BYTE_GROUP_SIZE - 1) & ~(K_BYTE_GROUP_SIZE - 1);
        int controlSize = version == 0 ? 0 : vertexSize / 4;
        if (end - pos < controlSize) return -1;
        int controlPos = pos;
        pos += controlSize;

        for (int k = 0; k < vertexSize; k += 4) {
            int ctrlByte = version == 0 ? 0 : (data[controlPos + k / 4] & 0xFF);
            for (int j = 0; j < 4; j++) {
                int ctrl = (ctrlByte >> (j * 2)) & 3;
                int streamOff = j * vertexCount;
                if (ctrl == 3) {
                    if (end - pos < vertexCount) return -1;
                    System.arraycopy(data, pos, buffer, streamOff, vertexCount);
                    pos += vertexCount;
                } else if (ctrl == 2) {
                    for (int i = 0; i < vertexCount; i++) buffer[streamOff + i] = 0;
                } else {
                    int[] bits = version == 0 ? K_BITS_V0 : (ctrl == 0 ? K_BITS_V1_C0 : K_BITS_V1_C1);
                    int np = decodeBytes(data, pos, end, buffer, streamOff, aligned, bits);
                    if (np < 0) return -1;
                    pos = np;
                }
            }
            int channel = version == 0 ? 0 : (channels[k / 4] & 0xFF);
            int ctype = channel & 3;
            int rot = (32 - (channel >> 4)) & 31;
            if (ctype == 0) {
                decodeDeltas1(buffer, 0, transposed, k, vertexCount, vertexSize, lastVertex, k, 1, false, rot);
            } else if (ctype == 1) {
                decodeDeltas1(buffer, 0, transposed, k, vertexCount, vertexSize, lastVertex, k, 2, false, rot);
            } else if (ctype == 2) {
                decodeDeltas1(buffer, 0, transposed, k, vertexCount, vertexSize, lastVertex, k, 4, true, rot);
            } else {
                return -1;
            }
        }
        System.arraycopy(transposed, 0, vertexData, vertexOffset * vertexSize, vertexCount * vertexSize);
        System.arraycopy(transposed, (vertexCount - 1) * vertexSize, lastVertex, 0, vertexSize);
        return pos;
    }

    private static int decodeBytes(byte[] data, int pos, int end, byte[] buffer, int bufOff,
                                   int bufSize, int[] bits) {
        int headerSize = (bufSize / K_BYTE_GROUP_SIZE + 3) / 4;
        if (end - pos < headerSize) return -1;
        int headerPos = pos;
        pos += headerSize;
        for (int i = 0; i < bufSize; i += K_BYTE_GROUP_SIZE) {
            if (end - pos < K_BYTE_GROUP_DECODE_LIMIT) return -1;
            int headerOffset = i / K_BYTE_GROUP_SIZE;
            int bitsk = (data[headerPos + headerOffset / 4] >> ((headerOffset % 4) * 2)) & 3;
            int np = decodeBytesGroup(data, pos, buffer, bufOff + i, bits[bitsk]);
            if (np < 0) return -1;
            pos = np;
        }
        return pos;
    }

    private static int decodeBytesGroup(byte[] data, int pos, byte[] buffer, int off, int bits) {
        if (bits == 0) {
            for (int i = 0; i < K_BYTE_GROUP_SIZE; i++) buffer[off + i] = 0;
            return pos;
        }
        if (bits == 8) {
            System.arraycopy(data, pos, buffer, off, K_BYTE_GROUP_SIZE);
            return pos + K_BYTE_GROUP_SIZE;
        }
        int groupsPerByte = 8 / bits;        // 1->8, 2->4, 4->2
        int fixedBytes = K_BYTE_GROUP_SIZE / groupsPerByte; // 1->2, 2->4, 4->8
        int sentinel = (1 << bits) - 1;     // 1->1, 2->3, 4->15
        int dataVar = pos + fixedBytes;
        int p = pos;
        int idx = 0;
        for (int g = 0; g < fixedBytes; g++) {
            int b = data[p++] & 0xFF;
            if (bits == 1) b = reverse8(b);
            for (int kk = 0; kk < groupsPerByte; kk++) {
                int shift = 8 - bits - kk * bits;
                int enc = (b >> shift) & sentinel;
                if (enc == sentinel) {
                    buffer[off + idx] = data[dataVar++];
                } else {
                    buffer[off + idx] = (byte) enc;
                }
                idx++;
            }
        }
        return dataVar;
    }

    /**
     * 解码 delta（逆转置 + 反 zigzag / 旋转）。
     * @param width 1=u8(channel0), 2=u16(channel1), 4=u32(channel2 xor)
     */
    private static void decodeDeltas1(byte[] buffer, int bufBase, byte[] transposed, int targetOff,
                                     int vertexCount, int vertexSize, byte[] lastVertex, int lvBase,
                                     int width, boolean xor, int rot) {
        int mask = (width == 1) ? 0xFF : (width == 2 ? 0xFFFF : -1);
        for (int k = 0; k < 4; k += width) {
            int vertexOffset = targetOff + k;
            int bufPos = bufBase + k * vertexCount;
            int lvPos = lvBase + k;
            int p = 0;
            for (int j = 0; j < width; j++) p |= (lastVertex[lvPos + j] & 0xFF) << (8 * j);
            p &= mask;
            for (int i = 0; i < vertexCount; i++) {
                int v = 0;
                for (int j = 0; j < width; j++)
                    v |= (buffer[bufPos + i + vertexCount * j] & 0xFF) << (8 * j);
                v &= mask;
                v = xor ? (Integer.rotateLeft(v, rot) ^ p) : ((unzig(v) + p) & mask);
                for (int j = 0; j < width; j++)
                    transposed[vertexOffset + j] = (byte) (v >>> (8 * j));
                p = v;
                vertexOffset += vertexSize;
            }
        }
    }

    private static int unzig(int v) {
        return (-(v & 1)) ^ (v >>> 1);
    }

    private static int reverse8(int v) {
        v &= 0xFF;
        int r = 0;
        for (int i = 0; i < 8; i++) {
            r = (r << 1) | (v & 1);
            v >>= 1;
        }
        return r;
    }

    // ------------------------------------------------------------------
    //  编码 (version 1, level 0)
    // ------------------------------------------------------------------

    /** 编码所需上界字节数。 */
    static int encodeVertexBufferBound(int vertexCount, int vertexSize) {
        int blockSize = getVertexBlockSize(vertexSize);
        int blockCount = (vertexCount + blockSize - 1) / blockSize;
        int controlSize = vertexSize / 4;
        int headerSize = (blockSize / K_BYTE_GROUP_SIZE + 3) / 4;
        int dataSize = blockSize;
        int tailSize = vertexSize + vertexSize / 4;
        int tailPad = Math.max(tailSize, Math.max(K_TAIL_MIN_V0, K_TAIL_MIN_V1));
        return 1 + blockCount * vertexSize * (controlSize + headerSize + dataSize) + tailPad;
    }

    /**
     * 编码顶点缓冲区 (version 0, 游戏要求的格式)。
     * v0: 无控制字节, 所有通道用 channel 0 (u8 zigzag), bits_table={0,2,4,8}, tail 仅含 first_vertex。
     * @return 实际字节数；0 表示失败
     */
    static int encodeVertexBuffer(byte[] buffer, int bufferSize, byte[] vertices,
                                  int vertexCount, int vertexSize) {
        final int version = 0;
        int pos = 0;
        if (bufferSize - pos < 1) return 0;
        buffer[pos++] = (byte) (K_VERTEX_HEADER | version);

        byte[] firstVertex = new byte[256];
        if (vertexCount > 0) System.arraycopy(vertices, 0, firstVertex, 0, vertexSize);
        byte[] lastVertex = new byte[256];
        System.arraycopy(firstVertex, 0, lastVertex, 0, vertexSize);
        byte[] channels = new byte[64]; // v0 不使用 channels, 但保留数组以兼容签名

        int blockSize = getVertexBlockSize(vertexSize);
        byte[] deltaBuf = new byte[K_BLOCK_MAX_SIZE];

        int vertexOffset = 0;
        while (vertexOffset < vertexCount) {
            int bs = (vertexOffset + blockSize < vertexCount) ? blockSize : vertexCount - vertexOffset;
            int np = encodeVertexBlock(buffer, pos, bufferSize, vertices, vertexOffset, bs,
                    vertexSize, lastVertex, channels, version, deltaBuf);
            if (np < 0) return 0;
            pos = np;
            vertexOffset += bs;
        }

        // v0 tail: 仅 first_vertex, 无 channels
        int tailSize = vertexSize;
        int tailPad = Math.max(tailSize, K_TAIL_MIN_V0);
        if (bufferSize - pos < tailPad) return 0;
        for (int i = 0; i < tailPad - tailSize; i++) buffer[pos++] = 0;
        System.arraycopy(firstVertex, 0, buffer, pos, vertexSize);
        pos += vertexSize;
        // v0 不写 channels
        return pos;
    }

    private static int encodeVertexBlock(byte[] data, int pos, int bufferSize, byte[] vertices,
                                         int vertexOffset, int vertexCount, int vertexSize,
                                         byte[] lastVertex, byte[] channels, int version,
                                         byte[] deltaBuf) {
        int aligned = (vertexCount + K_BYTE_GROUP_SIZE - 1) & ~(K_BYTE_GROUP_SIZE - 1);
        int controlSize = version == 0 ? 0 : vertexSize / 4;
        if (bufferSize - pos < controlSize) return -1;
        int controlPos = pos;
        pos += controlSize;
        for (int i = 0; i < controlSize; i++) data[controlPos + i] = 0;

        for (int k = 0; k < vertexSize; k++) {
            // delta (channel 0 = zigzag8)
            java.util.Arrays.fill(deltaBuf, 0, aligned, (byte) 0);
            encodeDeltasChannel0(deltaBuf, vertices, vertexOffset, vertexCount, vertexSize, lastVertex, k);

            if (version == 0) {
                // v0: 始终使用 encodeBytes + K_BITS_V0, 不能跳过零流
                int np = encodeBytes(data, pos, bufferSize, deltaBuf, aligned, K_BITS_V0);
                if (np < 0) return -1;
                pos = np;
            } else {
                // v1: ctrl-based encoding
                int ctrl = estimateControlZero(deltaBuf, aligned) ? 2 : 1;
                data[controlPos + k / 4] |= (byte) (ctrl << ((k % 4) * 2));
                if (ctrl == 3) {
                    if (bufferSize - pos < vertexCount) return -1;
                    System.arraycopy(deltaBuf, 0, data, pos, vertexCount);
                    pos += vertexCount;
                } else if (ctrl != 2) {
                    int np = encodeBytes(data, pos, bufferSize, deltaBuf, aligned, K_BITS_V1_C1);
                    if (np < 0) return -1;
                    pos = np;
                }
            }
        }
        System.arraycopy(vertices, (vertexOffset + vertexCount - 1) * vertexSize, lastVertex, 0, vertexSize);
        return pos;
    }

    private static void encodeDeltasChannel0(byte[] deltaBuf, byte[] vertices, int vertexOffset,
                                            int vertexCount, int vertexSize, byte[] lastVertex, int k) {
        int p = lastVertex[k] & 0xFF;
        int vi = vertexOffset * vertexSize + k;
        for (int i = 0; i < vertexCount; i++) {
            int v = vertices[vi] & 0xFF;
            int diff = (v - p) & 0xFF;
            deltaBuf[i] = (byte) (((-(diff >> 7)) ^ (diff << 1)) & 0xFF);
            p = v;
            vi += vertexSize;
        }
    }

    private static boolean estimateControlZero(byte[] buf, int aligned) {
        for (int i = 0; i < aligned; i += K_BYTE_GROUP_SIZE) {
            for (int j = 0; j < K_BYTE_GROUP_SIZE; j++) {
                if (buf[i + j] != 0) return false;
            }
        }
        return true;
    }

    private static int encodeBytes(byte[] data, int pos, int bufferSize, byte[] buf, int bufSize, int[] bits) {
        int headerSize = (bufSize / K_BYTE_GROUP_SIZE + 3) / 4;
        if (bufferSize - pos < headerSize) return -1;
        int headerPos = pos;
        pos += headerSize;
        for (int i = 0; i < headerSize; i++) data[headerPos + i] = 0;

        int lastBits = -1;
        for (int i = 0; i < bufSize; i += K_BYTE_GROUP_SIZE) {
            if (bufferSize - pos < K_BYTE_GROUP_DECODE_LIMIT) return -1;
            int bestBitk = 3;
            long bestSize = encodeBytesGroupMeasure(buf, i, bits[3]);
            for (int bitk = 0; bitk < 3; bitk++) {
                long size = encodeBytesGroupMeasure(buf, i, bits[bitk]);
                if (size < bestSize || (size == bestSize && bits[bitk] == lastBits && bits[bestBitk] != 8)) {
                    bestBitk = bitk;
                    bestSize = size;
                }
            }
            int headerOffset = i / K_BYTE_GROUP_SIZE;
            data[headerPos + headerOffset / 4] |= (byte) (bestBitk << ((headerOffset % 4) * 2));
            pos = encodeBytesGroup(data, pos, buf, i, bits[bestBitk]);
            lastBits = bits[bestBitk];
        }
        return pos;
    }

    private static long encodeBytesGroupMeasure(byte[] buf, int off, int bits) {
        if (bits == 0) {
            for (int i = 0; i < K_BYTE_GROUP_SIZE; i++) if (buf[off + i] != 0) return Long.MAX_VALUE;
            return 0;
        }
        if (bits == 8) return K_BYTE_GROUP_SIZE;
        long result = (long) K_BYTE_GROUP_SIZE * bits / 8;
        int sentinel = (1 << bits) - 1;
        for (int i = 0; i < K_BYTE_GROUP_SIZE; i++) if ((buf[off + i] & 0xFF) >= sentinel) result++;
        return result;
    }

    private static int encodeBytesGroup(byte[] data, int pos, byte[] buf, int off, int bits) {
        if (bits == 0) return pos;
        if (bits == 8) {
            System.arraycopy(buf, off, data, pos, K_BYTE_GROUP_SIZE);
            return pos + K_BYTE_GROUP_SIZE;
        }
        int byteSize = 8 / bits;
        int sentinel = (1 << bits) - 1;
        int p = pos;
        for (int i = 0; i < K_BYTE_GROUP_SIZE; i += byteSize) {
            int b = 0;
            for (int kk = 0; kk < byteSize; kk++) {
                int v = buf[off + i + kk] & 0xFF;
                int enc = (v >= sentinel) ? sentinel : v;
                b <<= bits;
                b |= enc;
            }
            if (bits == 1) b = reverse8(b);
            data[p++] = (byte) b;
        }
        for (int i = 0; i < K_BYTE_GROUP_SIZE; i++) {
            int v = buf[off + i] & 0xFF;
            data[p] = (byte) v;
            if (v >= sentinel) p++;
        }
        return p;
    }

    private static int getVertexBlockSize(int vertexSize) {
        int r = (K_BLOCK_SIZE_BYTES / vertexSize) & ~(K_BYTE_GROUP_SIZE - 1);
        return (r < K_BLOCK_MAX_SIZE) ? r : K_BLOCK_MAX_SIZE;
    }
}
