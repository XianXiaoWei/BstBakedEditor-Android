package com.skymesh.editor;

/**
 * 移动/旋转/缩放手柄。对应 C++ Gizmo。
 * 通过射线-射线最近距离来拾取轴，并沿轴方向拖拽。
 */
public final class Gizmo {
    public static final int NONE = -1, X = 0, Y = 1, Z = 2;

    public int modeMove = 0; // 0=Move,1=Rotate,2=Scale (仅用于语义，实际由工具决定)

    private final Vec3 startPos = new Vec3();
    private final Vec3 tmpO = new Vec3();
    private final Vec3 tmpD = new Vec3();
    private final Vec3 tmpW0 = new Vec3();
    private final Vec3 tmpCross = new Vec3();
    private final Vec3 tmpP = new Vec3();
    private final Vec3 tmpAxis = new Vec3();
    private final Vec3 tmpHit = new Vec3();

    public static Vec3 axisV(int axis) {
        switch (axis) {
            case X: return new Vec3(1, 0, 0);
            case Y: return new Vec3(0, 1, 0);
            default: return new Vec3(0, 0, 1);
        }
    }

    public static Vec3 axisColor(int axis) {
        switch (axis) {
            case X: return new Vec3(0.95f, 0.25f, 0.25f);
            case Y: return new Vec3(0.30f, 0.90f, 0.35f);
            default: return new Vec3(0.25f, 0.45f, 1.0f);
        }
    }

    /**
     * 拾取哪个轴。ro/rd 为射线原点与方向，pos 为物体位置，thr 为阈值。
     * @return NONE/X/Y/Z
     */
    public int pickAxis(Vec3 ro, Vec3 rd, Vec3 pos, float thr) {
        int best = NONE;
        float bd = thr;
        Vec3[] dirs = {new Vec3(1, 0, 0), new Vec3(0, 1, 0), new Vec3(0, 0, 1)};
        float[] ts = new float[1];
        float[] ss = new float[1];
        for (int i = 0; i < 3; i++) {
            float d = rayRay(ro, rd, pos, dirs[i], ts, ss);
            if (d < bd && ss[0] > -2.0f && ss[0] < 2.0f) {
                bd = d;
                best = i;
            }
        }
        return best;
    }

    public void beginDrag(Vec3 pos) {
        startPos.set(pos);
    }

    /** 沿轴拖拽移动，返回新位置 */
    public Vec3 dragMove(int axis, Vec3 ro, Vec3 rd, Vec3 out) {
        float[] ts = new float[1];
        float[] ss = new float[1];
        rayRay(ro, rd, startPos, axisV(axis), ts, ss);
        if (out == null) out = new Vec3();
        Vec3 av = axisV(axis);
        out.x = startPos.x + av.x * ss[0];
        out.y = startPos.y + av.y * ss[0];
        out.z = startPos.z + av.z * ss[0];
        return out;
    }

    /** 沿轴拖拽缩放，返回新缩放值 */
    public float dragScale(int axis, Vec3 ro, Vec3 rd, Vec3 curPos) {
        float[] ts = new float[1];
        float[] ss = new float[1];
        rayRay(ro, rd, curPos, axisV(axis), ts, ss);
        float s = 1.0f + ss[0] * 0.5f;
        if (s < 0.05f) s = 0.05f;
        if (s > 100.0f) s = 100.0f;
        return s;
    }

    /**
     * 两条射线 O+d2 与 P0+d1 的最近距离，输出最近点参数 t (沿 d2) 与 s (沿 d1)。
     */
    private float rayRay(Vec3 O, Vec3 d2, Vec3 P0, Vec3 d1, float[] tOut, float[] sOut) {
        Vec3.sub(P0, O, tmpW0);
        float a = Vec3.dot(d1, d1);
        float b = Vec3.dot(d1, d2);
        float c = Vec3.dot(d2, d2);
        float d = Vec3.dot(d1, tmpW0);
        float e = Vec3.dot(d2, tmpW0);
        float den = a * c - b * b;
        float s, t;
        if (Math.abs(den) < 1e-12f) {
            t = 0;
            s = (b > c) ? (d / b) : (e / c);
        } else {
            s = (b * e - c * d) / den;
            t = (a * e - b * d) / den;
        }
        // 距离 = |(P0+d1*s) - (O+d2*t)|
        Vec3.mulAdd(P0, d1, s, tmpP);
        Vec3.mulAdd(O, d2, t, tmpHit);
        Vec3.sub(tmpP, tmpHit, tmpCross);
        tOut[0] = t;
        sOut[0] = s;
        return tmpCross.len();
    }
}
