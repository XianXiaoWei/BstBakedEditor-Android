package com.skymesh.editor;

/**
 * 简易 3D 向量类，对应 C++ 端的 QVector3D。
 * 用于场景物体位置/旋转/缩放、相机、射线、Gizmo 等数学运算。
 * 矩阵运算统一使用 android.opengl.Matrix 的 float[16] / float[9]。
 */
public final class Vec3 {
    public float x, y, z;

    public Vec3() {}

    public Vec3(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
    }

    public Vec3(Vec3 o) {
        x = o.x;
        y = o.y;
        z = o.z;
    }

    public Vec3 set(float x, float y, float z) {
        this.x = x;
        this.y = y;
        this.z = z;
        return this;
    }

    public Vec3 set(Vec3 o) {
        x = o.x;
        y = o.y;
        z = o.z;
        return this;
    }

    public float len() {
        return (float) Math.sqrt(x * x + y * y + z * z);
    }

    public float lenSq() {
        return x * x + y * y + z * z;
    }

    public Vec3 normalize() {
        float l = len();
        if (l > 1e-8f) {
            x /= l;
            y /= l;
            z /= l;
        }
        return this;
    }

    public static float dot(Vec3 a, Vec3 b) {
        return a.x * b.x + a.y * b.y + a.z * b.z;
    }

    public static Vec3 cross(Vec3 a, Vec3 b, Vec3 out) {
        out.x = a.y * b.z - a.z * b.y;
        out.y = a.z * b.x - a.x * b.z;
        out.z = a.x * b.y - a.y * b.x;
        return out;
    }

    public static Vec3 add(Vec3 a, Vec3 b, Vec3 out) {
        out.x = a.x + b.x;
        out.y = a.y + b.y;
        out.z = a.z + b.z;
        return out;
    }

    public static Vec3 sub(Vec3 a, Vec3 b, Vec3 out) {
        out.x = a.x - b.x;
        out.y = a.y - b.y;
        out.z = a.z - b.z;
        return out;
    }

    public static Vec3 scale(Vec3 a, float s, Vec3 out) {
        out.x = a.x * s;
        out.y = a.y * s;
        out.z = a.z * s;
        return out;
    }

    /** out = a + d * t */
    public static Vec3 mulAdd(Vec3 a, Vec3 d, float t, Vec3 out) {
        out.x = a.x + d.x * t;
        out.y = a.y + d.y * t;
        out.z = a.z + d.z * t;
        return out;
    }
}
