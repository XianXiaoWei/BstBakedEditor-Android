package com.skymesh.editor;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * ObjImporter - 解析 OBJ 文件 (v/vn/f/usemtl)，导入为 SceneObject。
 * 对应C++中的 ObjImporter。
 * 三角化使用扇形方法。居中模型。默认材质 Grass(48)。
 */
public class ObjImporter {

    /**
     * 从文件路径加载 OBJ。
     *
     * @param path OBJ 文件路径
     * @return SceneObject，或 null 如果打开失败
     */
    public static SceneObject load(String path) {
        File f = new File(path);
        if (!f.exists() || !f.canRead()) return null;

        byte[] data;
        try {
            FileInputStream fis = new FileInputStream(f);
            data = new byte[(int) f.length()];
            fis.read(data);
            fis.close();
        } catch (Exception e) {
            return null;
        }

        String name = f.getName();
        int dotIdx = name.lastIndexOf('.');
        if (dotIdx > 0) name = name.substring(0, dotIdx);

        return load(data, name);
    }

    /**
     * 从字节数据加载 OBJ。
     *
     * @param data OBJ 文件字节数据
     * @param name 物体名称
     * @return SceneObject
     */
    public static SceneObject load(byte[] data, String name) {
        SceneObject obj = new SceneObject();
        obj.name = (name == null || name.isEmpty()) ? "Imported" : name;
        obj.kind = ObjKind.Imported;
        obj.baseMaterialId = 48; // 默认 Grass

        List<float[]> posList = new ArrayList<>();
        List<float[]> nrmList = new ArrayList<>();
        int currentMat = 48;

        try {
            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(new ByteArrayInputStream(data), StandardCharsets.UTF_8));

            String line;
            while ((line = reader.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty() || line.startsWith("#")) continue;

                String[] parts = line.split("\\s+");
                if (parts.length == 0) continue;

                if (parts[0].equals("v") && parts.length >= 4) {
                    posList.add(new float[]{
                            Float.parseFloat(parts[1]),
                            Float.parseFloat(parts[2]),
                            Float.parseFloat(parts[3])
                    });
                } else if (parts[0].equals("vn") && parts.length >= 4) {
                    nrmList.add(new float[]{
                            Float.parseFloat(parts[1]),
                            Float.parseFloat(parts[2]),
                            Float.parseFloat(parts[3])
                    });
                } else if (parts[0].equals("usemtl") && parts.length >= 2) {
                    currentMat = MaterialTable.instance().idFromName(parts[1]);
                } else if (parts[0].equals("f") && parts.length >= 4) {
                    // 三角化(扇形): v0 v1 v2, v0 v2 v3 ...
                    List<Integer> vi = new ArrayList<>();
                    List<Integer> ni = new ArrayList<>();

                    for (int i = 1; i < parts.length; i++) {
                        String[] fp = parts[i].split("/");
                        int vidx = Integer.parseInt(fp[0]) - 1; // OBJ 索引从 1 开始
                        int nidx = -1;
                        if (fp.length >= 3 && !fp[2].isEmpty()) {
                            nidx = Integer.parseInt(fp[2]) - 1;
                        }
                        vi.add(vidx);
                        ni.add(nidx);
                    }

                    for (int i = 1; i + 1 < vi.size(); i++) {
                        int[] tri = {0, i, i + 1};
                        int base = obj.vertices.size();

                        for (int t = 0; t < 3; t++) {
                            MeshVertex mv = new MeshVertex();
                            int vidx = vi.get(tri[t]);

                            if (vidx >= 0 && vidx < posList.size()) {
                                float[] p = posList.get(vidx);
                                mv.position.set(p[0], p[1], p[2]);
                            }

                            int nidx = ni.get(tri[t]);
                            if (nidx >= 0 && nidx < nrmList.size()) {
                                float[] n = nrmList.get(nidx);
                                mv.normal[0] = n[0];
                                mv.normal[1] = n[1];
                                mv.normal[2] = n[2];
                            } else {
                                mv.normal[0] = 0;
                                mv.normal[1] = 1;
                                mv.normal[2] = 0;
                            }
                            mv.normal[3] = 0;

                            mv.materialIds[0] = currentMat;
                            mv.materialWeights[0] = 1.0f;
                            mv.input2[0] = 0.99f;
                            mv.input2[1] = 0.5f;
                            mv.input2[2] = 0.5f;
                            mv.input2[3] = 0.5f;
                            mv.input3[0] = 0.04f;
                            mv.input3[1] = 0.04f;
                            mv.input3[2] = 0.04f;
                            mv.input3[3] = 0.04f;

                            obj.vertices.add(mv);
                        }

                        obj.indices.add(base);
                        obj.indices.add(base + 1);
                        obj.indices.add(base + 2);
                    }
                }
            }
            reader.close();
        } catch (Exception e) {
            // 即使解析出错，也返回已解析的部分
        }

        // 居中并缩放到合理大小
        if (!obj.vertices.isEmpty()) {
            float cx = 0, cy = 0, cz = 0;
            for (MeshVertex v : obj.vertices) {
                cx += v.position.x;
                cy += v.position.y;
                cz += v.position.z;
            }
            cx /= obj.vertices.size();
            cy /= obj.vertices.size();
            cz /= obj.vertices.size();
            for (MeshVertex v : obj.vertices) {
                v.position.x -= cx;
                v.position.y -= cy;
                v.position.z -= cz;
            }
        }

        obj.position.set(0, 1, 0);
        return obj;
    }
}
