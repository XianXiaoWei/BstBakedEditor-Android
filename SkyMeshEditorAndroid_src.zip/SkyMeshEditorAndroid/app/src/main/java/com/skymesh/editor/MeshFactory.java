package com.skymesh.editor;

/**
 * 创建基础几何体(立方体/球/圆柱/平面)填充到 SceneObject。对应 C++ MeshFactory。
 */
public final class MeshFactory {

    private MeshFactory() {}

    private static void setDefaultInputs(MeshVertex v) {
        v.input2[0] = 0.99f; v.input2[1] = 0.5f; v.input2[2] = 0.5f; v.input2[3] = 0.5f;
        v.input3[0] = 0.04f; v.input3[1] = 0.04f; v.input3[2] = 0.04f; v.input3[3] = 0.04f;
    }

    public static SceneObject createCube(String name) {
        SceneObject o = new SceneObject();
        o.name = (name == null || name.isEmpty()) ? "Cube" : name;
        o.kind = ObjKind.Primitive;
        o.baseMaterialId = 16; // Cliff
        float[][] p = {
                {-1, -1, 1}, {1, -1, 1}, {1, 1, 1}, {-1, 1, 1},
                {-1, -1, -1}, {1, -1, -1}, {1, 1, -1}, {-1, 1, -1}
        };
        int[][] faces = {
                {0, 1, 2, 3}, {5, 4, 7, 6}, {4, 0, 3, 7},
                {1, 5, 6, 2}, {3, 2, 6, 7}, {4, 5, 1, 0}
        };
        float[][] norms = {
                {0, 0, 1}, {0, 0, -1}, {-1, 0, 0},
                {1, 0, 0}, {0, 1, 0}, {0, -1, 0}
        };
        for (int f = 0; f < 6; f++) {
            int b = o.vertices.size();
            for (int i = 0; i < 4; i++) {
                MeshVertex v = new MeshVertex();
                v.position.set(p[faces[f][i]][0], p[faces[f][i]][1], p[faces[f][i]][2]);
                v.normal[0] = norms[f][0]; v.normal[1] = norms[f][1]; v.normal[2] = norms[f][2]; v.normal[3] = 0;
                v.materialIds[0] = 16; v.materialWeights[0] = 1.0f;
                setDefaultInputs(v);
                o.vertices.add(v);
            }
            o.indices.add(b); o.indices.add(b + 1); o.indices.add(b + 2);
            o.indices.add(b); o.indices.add(b + 2); o.indices.add(b + 3);
        }
        return o;
    }

    public static SceneObject createSphere(String name, int seg, int ring) {
        SceneObject o = new SceneObject();
        o.name = (name == null || name.isEmpty()) ? "Sphere" : name;
        o.kind = ObjKind.Primitive;
        o.baseMaterialId = 48;
        for (int y = 0; y <= ring; y++) {
            float vv = (float) y / ring;
            float phi = vv * (float) Math.PI;
            for (int x = 0; x <= seg; x++) {
                float u = (float) x / seg;
                float theta = u * (float) Math.PI * 2;
                MeshVertex mv = new MeshVertex();
                float sp = (float) Math.sin(phi);
                mv.position.set(sp * (float) Math.cos(theta), (float) Math.cos(phi),
                        sp * (float) Math.sin(theta));
                mv.normal[0] = mv.position.x; mv.normal[1] = mv.position.y;
                mv.normal[2] = mv.position.z; mv.normal[3] = 0;
                mv.materialIds[0] = 48; mv.materialWeights[0] = 1.0f;
                setDefaultInputs(mv);
                o.vertices.add(mv);
            }
        }
        for (int y = 0; y < ring; y++) {
            for (int x = 0; x < seg; x++) {
                int a = y * (seg + 1) + x, bb = a + seg + 1;
                o.indices.add(a); o.indices.add(bb); o.indices.add(a + 1);
                o.indices.add(bb); o.indices.add(bb + 1); o.indices.add(a + 1);
            }
        }
        return o;
    }

    public static SceneObject createCylinder(String name, int seg) {
        SceneObject o = new SceneObject();
        o.name = (name == null || name.isEmpty()) ? "Cylinder" : name;
        o.kind = ObjKind.Primitive;
        o.baseMaterialId = 30; // Wood
        for (int r = 0; r < 2; r++) {
            float y = (r == 0) ? -1 : 1;
            float ny = y;
            for (int x = 0; x <= seg; x++) {
                float t = (float) x / seg * (float) Math.PI * 2;
                MeshVertex mv = new MeshVertex();
                mv.position.set((float) Math.cos(t), y, (float) Math.sin(t));
                mv.normal[0] = (float) Math.cos(t); mv.normal[1] = ny;
                mv.normal[2] = (float) Math.sin(t); mv.normal[3] = 0;
                mv.materialIds[0] = 30; mv.materialWeights[0] = 1.0f;
                setDefaultInputs(mv);
                o.vertices.add(mv);
            }
        }
        for (int x = 0; x < seg; x++) {
            int a = x, bb = x + seg + 1;
            o.indices.add(a); o.indices.add(bb); o.indices.add(a + 1);
            o.indices.add(bb); o.indices.add(bb + 1); o.indices.add(a + 1);
        }
        return o;
    }

    public static SceneObject createPlane(String name, int size) {
        SceneObject o = new SceneObject();
        o.name = (name == null || name.isEmpty()) ? "Plane" : name;
        o.kind = ObjKind.Primitive;
        o.baseMaterialId = 32; // Sand
        float h = size * 0.5f;
        float[][] pos = {{-h, 0, -h}, {h, 0, -h}, {h, 0, h}, {-h, 0, h}};
        for (float[] pp : pos) {
            MeshVertex v = new MeshVertex();
            v.position.set(pp[0], pp[1], pp[2]);
            v.normal[0] = 0; v.normal[1] = 1; v.normal[2] = 0; v.normal[3] = 0;
            v.materialIds[0] = 32; v.materialWeights[0] = 1.0f;
            setDefaultInputs(v);
            o.vertices.add(v);
        }
        o.indices.add(0); o.indices.add(1); o.indices.add(2);
        o.indices.add(0); o.indices.add(2); o.indices.add(3);
        return o;
    }

    // ---- 默认参数的便捷重载（对应 C++ 默认参数） ----

    public static SceneObject createSphere(String name) {
        return createSphere(name, 16, 12);
    }

    public static SceneObject createCylinder(String name) {
        return createCylinder(name, 16);
    }

    public static SceneObject createPlane(String name) {
        return createPlane(name, 8);
    }
}
