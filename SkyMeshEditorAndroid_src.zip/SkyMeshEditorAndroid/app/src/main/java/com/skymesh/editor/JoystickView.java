package com.skymesh.editor;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * JoystickView is a virtual joystick component for the SkyMesh 3D editor.
 * <p>
 * It renders a circular base with a draggable knob using only Canvas and
 * Paint. Touch dragging moves the knob within the base circle and reports
 * normalised [-1, 1] values through an {@link OnJoystickListener}. When the
 * finger is lifted the knob snaps back to the centre of the base.
 * <p>
 * Pure Android framework API only. No AndroidX, no Java 8 features.
 * Compatible with AIDE Pro and Java 7 source level.
 */
public class JoystickView extends View {

    /**
     * Listener notified of joystick movement and release events.
     */
    public interface OnJoystickListener {
        /**
         * Called continuously while the knob is being dragged.
         *
         * @param x normalised horizontal offset in the range [-1, 1].
         *          -1 is fully left, 1 is fully right.
         * @param y normalised vertical offset in the range [-1, 1].
         *          -1 is fully up (top of screen), 1 is fully down.
         */
        void onMove(float x, float y);

        /**
         * Called when the user releases the knob. After this call the
         * knob is reset to the centre of the base.
         */
        void onRelease();
    }

    /** Default view size when the layout does not specify an exact size. */
    private static final int DEFAULT_SIZE_DP = 200;

    /** Fraction of the outer radius used for the knob radius. */
    private static final float KNOB_RATIO = 0.4f;

    /** Small inset applied to the outer radius so the stroke is not clipped. */
    private static final float RADIUS_INSET_DP = 4.0f;

    private final Paint basePaint;
    private final Paint knobPaint;
    private final Paint strokePaint;

    private OnJoystickListener listener;

    private float centerX;
    private float centerY;
    private float outerRadius;
    private float knobRadius;
    private float movementRadius;

    private float knobX;
    private float knobY;

    private boolean dragging;

    public JoystickView(Context context) {
        this(context, null);
    }

    public JoystickView(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public JoystickView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);

        // Outer base circle: semi-transparent dark fill.
        basePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        basePaint.setStyle(Paint.Style.FILL);
        basePaint.setColor(0x66000000);

        // Inner knob: semi-transparent blue fill.
        knobPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        knobPaint.setStyle(Paint.Style.FILL);
        knobPaint.setColor(0x882196F3);

        // Thin outline used for both circles for better definition.
        strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        strokePaint.setStyle(Paint.Style.STROKE);
        strokePaint.setColor(0xAAFFFFFF);
        strokePaint.setStrokeWidth(dpToPx(2.0f));

        knobX = 0.0f;
        knobY = 0.0f;
        dragging = false;
    }

    /**
     * Registers a listener that receives movement and release callbacks.
     *
     * @param listener the listener, or null to remove a previously set one
     */
    public void setOnJoystickListener(OnJoystickListener listener) {
        this.listener = listener;
    }

    /**
     * Converts density-independent pixels to screen pixels using the
     * current display metrics. No extra imports are required because the
     * return values of getResources()/getDisplayMetrics() are only used
     * through chained method/field access.
     */
    private float dpToPx(float dp) {
        return dp * getResources().getDisplayMetrics().density;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int defaultSize = (int) (dpToPx(DEFAULT_SIZE_DP) + 0.5f);
        int width = resolveSize(defaultSize, widthMeasureSpec);
        int height = resolveSize(defaultSize, heightMeasureSpec);
        // Keep the view square so the circle is never distorted.
        int size = Math.min(width, height);
        setMeasuredDimension(size, size);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);

        float padLeft = getPaddingLeft();
        float padTop = getPaddingTop();
        float availW = w - padLeft - getPaddingRight();
        float availH = h - padTop - getPaddingBottom();

        centerX = padLeft + availW / 2.0f;
        centerY = padTop + availH / 2.0f;

        float radius = Math.min(availW, availH) / 2.0f - dpToPx(RADIUS_INSET_DP);
        if (radius < 0.0f) {
            radius = 0.0f;
        }
        outerRadius = radius;
        knobRadius = outerRadius * KNOB_RATIO;
        movementRadius = outerRadius - knobRadius;
        if (movementRadius < 0.0f) {
            movementRadius = 0.0f;
        }

        // Reset the knob to the centre whenever the geometry changes.
        knobX = centerX;
        knobY = centerY;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Outer base circle with outline.
        canvas.drawCircle(centerX, centerY, outerRadius, basePaint);
        canvas.drawCircle(centerX, centerY, outerRadius, strokePaint);

        // Inner knob with outline.
        canvas.drawCircle(knobX, knobY, knobRadius, knobPaint);
        canvas.drawCircle(knobX, knobY, knobRadius, strokePaint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN) {
            dragging = true;
            updateKnob(event.getX(), event.getY());
            return true;
        } else if (action == MotionEvent.ACTION_MOVE) {
            if (dragging) {
                updateKnob(event.getX(), event.getY());
            }
            return true;
        } else if (action == MotionEvent.ACTION_UP
                || action == MotionEvent.ACTION_CANCEL) {
            dragging = false;
            // Snap the knob back to the centre (no animator required).
            knobX = centerX;
            knobY = centerY;
            invalidate();
            if (listener != null) {
                listener.onRelease();
            }
            return true;
        }

        return super.onTouchEvent(event);
    }

    /**
     * Moves the knob towards the touch point, constraining it to the
     * movement circle so it never leaves the outer base. Notifies the
     * listener with normalised values when applicable.
     */
    private void updateKnob(float touchX, float touchY) {
        float dx = touchX - centerX;
        float dy = touchY - centerY;
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        // Constrain the knob centre to the movement circle so the knob
        // stays fully inside the outer base.
        if (dist > movementRadius && movementRadius > 0.0f) {
            dx = (dx / dist) * movementRadius;
            dy = (dy / dist) * movementRadius;
        }

        knobX = centerX + dx;
        knobY = centerY + dy;
        invalidate();

        if (listener != null && movementRadius > 0.0f) {
            float nx = dx / movementRadius;
            float ny = dy / movementRadius;
            listener.onMove(nx, ny);
        }
    }
}
