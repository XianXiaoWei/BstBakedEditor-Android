package com.skymesh.editor;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * MeshesParser - 解析 That Sky Level .meshes 二进制文件。
 * 格式: Header(136B) + DESC段 + LOD0段 + GEO0段(meshopt顶点 + u8索引 + chunks + subchunks)
 * 对应C++中的 MeshesParser。
 */
public class MeshesParser {

    private static final int MAGIC_LVL0 = 0x304C564C; // "LVL0" 小端
    private static final int VERTEX_SIZE = 36;

    // ======================== 内部数据类 ========================

    public static class MeshesChunk {
        public int idxStart, vtxStart, subchunkStart;
        public int idxCount;
        public int vtxCount, subchunkCount;
        public float[] min = new float[3];
        public float[] max = new float[3];
        public boolean isCloud = false;
    }

    public static class MeshesSubchunk {
        public int materialId, triCount, vtxCount, triStart, triEnd, vtxStart, vtxEnd;
    }

    public static class MeshesFile {
        public boolean valid = false;
        public String error = "";
        public int version = 0x3C;
        public float[] maxPos = new float[3];
        public float[] minPos = new float[3];
        public String descSummary = "";
        public int vertexCount = 0, indexCount = 0;
        public int chunkCount = 0, cloudCount = 0, subchunkCount = 0;
        public List<MeshVertex> vertices = new ArrayList<>();
        public byte[] localIndices;       // u8 局部索引
        public List<MeshesChunk> chunks = new ArrayList<>();
        public List<MeshesSubchunk> subchunks = new ArrayList<>();
        public int meshoptVersion = 0;
        /** 原始 DESC 段字节 (用于导出时完整保留) */
        public byte[] descRaw = null;
        /** 原始 LOD0 段字节 (用于导出时完整保留) */
        public byte[] lod0Raw = null;
        /** 原始 GEO0 段完整字节 (用于导出时仅替换顶点数据，保留所有结构) */
        public byte[] geo0Raw = null;
        /** 原始压缩顶点数据大小 (GEO0 内 offset 20 处的 u32) */
        public int compVertexSize = 0;
        /** 原始完整文件字节 (用于无修改时原样输出) */
        public byte[] rawFileData = null;
    }

    // ======================== 小端读取助手 ========================

    private static class Reader {
        final byte[] d;
        final int sz;
        int pos = 0;

        Reader(byte[] data, int offset, int size) {
            this.d = data;
            this.pos = offset;
            this.sz = offset + size;
        }

        Reader(byte[] data) {
            this.d = data;
            this.sz = data.length;
        }

        int u32() {
            int v = ByteBuffer.wrap(d, pos, 4).order(ByteOrder.LITTLE_ENDIAN).getInt();
            pos += 4;
            return v;
        }

        int u16() {
            int v = ByteBuffer.wrap(d, pos, 2).order(ByteOrder.LITTLE_ENDIAN).getShort() & 0xFFFF;
            pos += 2;
            return v;
        }

        int u8() {
            return d[pos++] & 0xFF;
        }

        float f32() {
            float v = ByteBuffer.wrap(d, pos, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat();
            pos += 4;
            return v;
        }

        float[] v3() {
            float x = f32(), y = f32(), z = f32();
            return new float[]{x, y, z};
        }

        byte[] bytes(int n) {
            byte[] s = new byte[n];
            System.arraycopy(d, pos, s, 0, n);
            pos += n;
            return s;
        }

        boolean has(int n) {
            return pos + n <= sz;
        }
    }

    // ======================== SNORM/UNORM 转换 ========================

    /** SNORM i8 → float (-1..1) */
    private static float snorm8(byte b) {
        return b / 127.0f;
    }

    /** UNORM u8 → float (0..1) */
    private static float unorm8(int b) {
        return b / 255.0f;
    }

    // ======================== 解析 ========================

    /**
     * 解析 .meshes 字节流。
     *
     * @param data .meshes 文件的完整字节数据
     * @return MeshesFile 解析结果
     */
    public static MeshesFile parse(byte[] data) {
        MeshesFile mf = new MeshesFile();
        if (data.length < 136) {
            mf.error = "文件太小，不是合法 .meshes";
            return mf;
        }

        // 保存完整原始文件字节 (用于无修改时原样输出)
        mf.rawFileData = new byte[data.length];
        System.arraycopy(data, 0, mf.rawFileData, 0, data.length);

        Reader r = new Reader(data);

        // ---- Header (136 bytes) ----
        int magic = r.u32();
        if (magic != MAGIC_LVL0) {
            mf.error = "魔数不匹配，不是 .meshes 文件";
            return mf;
        }
        mf.version = r.u32();
        if (mf.version != 0x3C && mf.version != 0x3D) {
            mf.error = "不支持的版本 0x" + Integer.toHexString(mf.version);
            return mf;
        }

        // TOC (100 bytes = 0x64): u32 count + count×(4B name + 4B offset + 4B length)
        byte[] tocBuf = r.bytes(0x64);
        List<TocSeg> toc = new ArrayList<>();
        Reader tr = new Reader(tocBuf);
        int cnt = tr.u32();
        for (int i = 0; i < cnt && tr.pos + 12 <= tr.sz; i++) {
            TocSeg s = new TocSeg();
            s.name = tr.bytes(4);
            s.off = tr.u32();
            s.len = tr.u32();
            toc.add(s);
        }

        r.u32(); // padding
        mf.maxPos = r.v3();
        mf.minPos = r.v3();
        // header 结束 (136 bytes)

        // 按 TOC 名找段
        // ---- DESC 段 ----
        TocSeg descSeg = findSeg(toc, "DESC");
        if (descSeg != null) {
            mf.descRaw = new byte[descSeg.len];
            System.arraycopy(data, descSeg.off, mf.descRaw, 0, descSeg.len);
            // 简易提取可读字符串
            byte[] descRawCopy = new byte[descSeg.len];
            System.arraycopy(mf.descRaw, 0, descRawCopy, 0, descSeg.len);
            for (int i = 0; i < descRawCopy.length; i++) {
                char c = (char) (descRawCopy[i] & 0xFF);
                if (c < 32 && c != '\n') descRawCopy[i] = (byte) ' ';
            }
            mf.descSummary = new String(descRawCopy).trim();
            if (mf.descSummary.length() > 800) {
                mf.descSummary = mf.descSummary.substring(0, 800) + "...";
            }
        }

        // ---- LOD0 段 ----
        TocSeg lodSeg = findSeg(toc, "LOD0");
        if (lodSeg != null) {
            mf.lod0Raw = new byte[lodSeg.len];
            System.arraycopy(data, lodSeg.off, mf.lod0Raw, 0, lodSeg.len);
        }

        // ---- GEO0 段 ----
        TocSeg geoSeg = findSeg(toc, "GEO0");
        if (geoSeg != null) {
            // 保存完整 GEO0 原始字节 (用于导出时仅替换顶点数据)
            mf.geo0Raw = new byte[geoSeg.len];
            System.arraycopy(data, geoSeg.off, mf.geo0Raw, 0, geoSeg.len);

            Reader gr = new Reader(data, geoSeg.off, geoSeg.len);
            mf.indexCount = gr.u32();
            mf.vertexCount = gr.u32();
            mf.chunkCount = gr.u32();
            mf.cloudCount = gr.u32();
            mf.subchunkCount = gr.u32();

            // meshopt 压缩顶点
            if (mf.vertexCount > 0 && gr.has(4)) {
                int compSize = gr.u32();
                mf.compVertexSize = compSize;  // 保存原始压缩大小
                byte[] comp = gr.bytes(compSize);
                // 用 MeshOptimizer 解码
                byte[] raw = new byte[mf.vertexCount * VERTEX_SIZE];
                int rv = MeshOptimizer.decodeVertexBuffer(raw, mf.vertexCount, VERTEX_SIZE,
                        comp, comp.length);
                if (rv != 0) {
                    mf.error = "meshopt 顶点解码失败";
                    return mf;
                }

                // 解包 36 字节顶点 → MeshVertex
                for (int i = 0; i < mf.vertexCount; i++) {
                    int p = i * VERTEX_SIZE;
                    MeshVertex v = new MeshVertex();
                    // position f32×3
                    v.position.set(
                            ByteBuffer.wrap(raw, p, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat(),
                            ByteBuffer.wrap(raw, p + 4, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat(),
                            ByteBuffer.wrap(raw, p + 8, 4).order(ByteOrder.LITTLE_ENDIAN).getFloat());
                    // normal snorm8×4
                    v.normal[0] = snorm8(raw[p + 12]);
                    v.normal[1] = snorm8(raw[p + 13]);
                    v.normal[2] = snorm8(raw[p + 14]);
                    v.normal[3] = snorm8(raw[p + 15]);
                    // materialIds u8×4
                    for (int k = 0; k < 4; k++)
                        v.materialIds[k] = raw[p + 16 + k] & 0xFF;
                    // materialWeights unorm8×4
                    for (int k = 0; k < 4; k++)
                        v.materialWeights[k] = unorm8(raw[p + 20 + k] & 0xFF);
                    // input2 unorm8×4
                    for (int k = 0; k < 4; k++)
                        v.input2[k] = unorm8(raw[p + 24 + k] & 0xFF);
                    // input3 unorm8×4
                    for (int k = 0; k < 4; k++)
                        v.input3[k] = unorm8(raw[p + 28 + k] & 0xFF);
                    // input4 unorm8×4
                    for (int k = 0; k < 4; k++)
                        v.input4[k] = unorm8(raw[p + 32 + k] & 0xFF);
                    mf.vertices.add(v);
                }

                // 探测 meshopt 版本
                if (compSize > 0) {
                    mf.meshoptVersion = comp[0] & 0x0F;
                }
            }

            // u8 索引
            if (mf.indexCount > 0) {
                mf.localIndices = new byte[mf.indexCount];
                for (int i = 0; i < mf.indexCount; i++) {
                    mf.localIndices[i] = (byte) gr.u8();
                }
            }

            // chunks (地形 + 云)
            int totalChunks = mf.chunkCount + mf.cloudCount;
            for (int i = 0; i < totalChunks; i++) {
                MeshesChunk c = new MeshesChunk();
                c.idxStart = gr.u32();
                c.vtxStart = gr.u32();
                c.subchunkStart = gr.u32();
                c.idxCount = gr.u16();
                c.vtxCount = gr.u8();
                c.subchunkCount = gr.u8();
                c.min = gr.v3();
                c.max = gr.v3();
                gr.bytes(16); // 4×u32 pad
                c.isCloud = (i >= mf.chunkCount);
                mf.chunks.add(c);
            }

            // subchunks
            for (int i = 0; i < mf.subchunkCount; i++) {
                MeshesSubchunk sc = new MeshesSubchunk();
                sc.materialId = gr.u8();
                sc.triCount = gr.u8();
                sc.vtxCount = gr.u8();
                sc.triStart = gr.u8();
                sc.triEnd = gr.u8();
                sc.vtxStart = gr.u8();
                sc.vtxEnd = gr.u8();
                gr.u8(); // pad
                mf.subchunks.add(sc);
            }
        }

        mf.valid = true;
        return mf;
    }

    /**
     * 把解析结果转成可编辑的 SceneObject。
     *
     * @param mf   解析结果
     * @param name 物体名称（可为空）
     * @return SceneObject，或 null 如果解析失败
     */
    public static SceneObject toSceneObject(MeshesFile mf, String name) {
        if (!mf.valid) return null;

        SceneObject obj = new SceneObject();
        obj.name = (name == null || name.isEmpty()) ? "MeshesTerrain" : name;
        obj.kind = ObjKind.MeshesTerrain;

        // 拷贝顶点数据
        for (MeshVertex v : mf.vertices) {
            obj.vertices.add(new MeshVertex(v));
        }

        // 把 u8 局部索引 → 全局 int 三角索引
        // 每个 chunk 的三角形: localIndices[idxStart + i] 是局部顶点号，全局 = vtxStart + local
        for (MeshesChunk c : mf.chunks) {
            for (int i = 0; i < c.idxCount; i++) {
                int li = c.idxStart + i;
                if (li >= mf.localIndices.length) break;
                int local = mf.localIndices[li] & 0xFF;
                int gi = c.vtxStart + local;
                obj.indices.add(gi);
            }
        }

        obj.chunkCount = mf.chunkCount;
        obj.cloudCount = mf.cloudCount;
        obj.subchunkCount = mf.subchunkCount;
        obj.hasClouds = mf.cloudCount > 0;
        obj.sourceMeshes = mf;  // 保存完整解析数据，导出时保留原始结构

        // 计算每顶点的有效材质ID (来自 subchunk)
        // subchunk 的 triStart/triEnd 是相对于所属 chunk 的三角形索引
        // 全局三角形索引 = chunk 的三角形偏移 + subchunk.triStart
        int[] effMatIds = new int[obj.vertices.size()];
        for (int i = 0; i < effMatIds.length; i++) effMatIds[i] = -1;

        int chunkTriOffset = 0;  // 全局三角形偏移
        int chunkIdxOffset = 0;   // 全局索引偏移 (在 obj.indices 中)
        for (int ci = 0; ci < mf.chunks.size(); ci++) {
            MeshesChunk c = mf.chunks.get(ci);
            // 此 chunk 在 obj.indices 中的起始位置
            // obj.indices 是按 chunk 顺序追加的, 每个 chunk 贡献 c.idxCount 个索引
            // c.idxCount 个索引 = c.idxCount/3 个三角形

            // 遍历此 chunk 的 subchunks
            for (int si = 0; si < c.subchunkCount; si++) {
                int scIdx = c.subchunkStart + si;
                if (scIdx >= mf.subchunks.size()) break;
                MeshesSubchunk sc = mf.subchunks.get(scIdx);

                // subchunk 的三角形范围: [sc.triStart, sc.triEnd] (相对于 chunk)
                // 全局索引位置: chunkIdxOffset + sc.triStart * 3
                for (int tri = sc.triStart; tri <= sc.triEnd; tri++) {
                    int idxBase = chunkIdxOffset + tri * 3;
                    if (idxBase + 2 < obj.indices.size()) {
                        int v0 = obj.indices.get(idxBase);
                        int v1 = obj.indices.get(idxBase + 1);
                        int v2 = obj.indices.get(idxBase + 2);
                        if (v0 >= 0 && v0 < effMatIds.length) effMatIds[v0] = sc.materialId;
                        if (v1 >= 0 && v1 < effMatIds.length) effMatIds[v1] = sc.materialId;
                        if (v2 >= 0 && v2 < effMatIds.length) effMatIds[v2] = sc.materialId;
                    }
                }
            }

            chunkIdxOffset += c.idxCount;
        }
        obj.effectiveMaterialIds = effMatIds;

        return obj;
    }

    // ======================== 辅助 ========================

    private static class TocSeg {
        byte[] name;
        int off, len;
    }

    private static TocSeg findSeg(List<TocSeg> toc, String name) {
        for (TocSeg s : toc) {
            String segName = new String(s.name);
            if (segName.startsWith(name)) return s;
        }
        return null;
    }
}
