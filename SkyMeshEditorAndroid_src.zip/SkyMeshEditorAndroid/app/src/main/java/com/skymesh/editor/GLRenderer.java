package com.skymesh.editor;

import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.nio.IntBuffer;
import java.nio.ShortBuffer;
import java.util.ArrayList;
import java.util.List;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES 2.0 渲染器。对应 C++ GLViewport。
 * <p>
 * 着色器使用 GLSL ES 1.00 (#version 100)。
 * 顶点格式: pos(3) + normal(3) + color(3) = 9 floats/vertex (36 bytes)。
 * 线段格式: pos(3) + color(3) = 6 floats/vertex (24 bytes)。
 */
public class GLRenderer implements GLSurfaceView.Renderer {

    // ======================== 着色器源码 (GLSL ES 1.00) ========================

    private static final String VERTEX_SHADER =
            "#version 100\n" +
            "attribute vec3 aPos;\n" +
            "attribute vec3 aNormal;\n" +
            "attribute vec3 aColor;\n" +
            "uniform mat4 uMVP;\n" +
            "uniform mat4 uModel;\n" +
            "uniform mat4 uNormalMat;\n" +
            "varying vec3 vN;\n" +
            "varying vec3 vC;\n" +
            "void main() {\n" +
            "  vN = normalize((uNormalMat * vec4(aNormal, 0.0)).xyz);\n" +
            "  vC = aColor;\n" +
            "  gl_Position = uMVP * vec4(aPos, 1.0);\n" +
            "}\n";

    private static final String FRAGMENT_SHADER =
            "#version 100\n" +
            "precision mediump float;\n" +
            "varying vec3 vN;\n" +
            "varying vec3 vC;\n" +
            "uniform int uSelected;\n" +
            "void main() {\n" +
            // 参照 SkyModelViewer MeshRenderer 的三光照明 (ambient + key + fill)
            "  vec3 ambient = vec3(70.0/255.0, 70.0/255.0, 72.0/255.0);\n" +
            "  vec3 keyDir = normalize(vec3(0.4, 0.9, 0.3));\n" +
            "  vec3 keyColor = vec3(1.0);\n" +
            "  vec3 fillColor = vec3(150.0/255.0, 160.0/255.0, 176.0/255.0);\n" +
            "  vec3 fillDir = normalize(vec3(-0.5, 0.3, -0.4));\n" +
            "  vec3 N = normalize(vN);\n" +
            "  float keyDot = max(dot(N, keyDir), 0.0);\n" +
            "  float fillDot = max(dot(N, fillDir), 0.0);\n" +
            "  vec3 lighting = ambient + keyColor * keyDot + fillColor * fillDot;\n" +
            "  vec3 base = vC * lighting;\n" +
            "  if (uSelected == 1) {\n" +
            "    base = mix(base, vec3(1.0, 0.58, 0.12), 0.4);\n" +
            "  }\n" +
            "  gl_FragColor = vec4(base, 1.0);\n" +
            "}\n";

    private static final String LINE_VERTEX_SHADER =
            "#version 100\n" +
            "attribute vec3 aPos;\n" +
            "attribute vec3 aColor;\n" +
            "uniform mat4 uMVP;\n" +
            "varying vec3 vC;\n" +
            "void main() {\n" +
            "  vC = aColor;\n" +
            "  gl_Position = uMVP * vec4(aPos, 1.0);\n" +
            "}\n";

    private static final String LINE_FRAGMENT_SHADER =
            "#version 100\n" +
            "precision mediump float;\n" +
            "varying vec3 vC;\n" +
            "void main() {\n" +
            "  gl_FragColor = vec4(vC, 1.0);\n" +
            "}\n";

    // ======================== 常量 ========================

    private static final int FLOATS_PER_VERTEX = 9;  // pos(3) + normal(3) + color(3)
    private static final int VERTEX_STRIDE = FLOATS_PER_VERTEX * 4; // 36 bytes
    private static final int LINE_FLOATS_PER_VERTEX = 6; // pos(3) + color(3)
    private static final int LINE_STRIDE = LINE_FLOATS_PER_VERTEX * 4; // 24 bytes
    private static final int MAX_LINE_VERTS = 8192;
    private static final float CLEAR_R = 0.12f;
    private static final float CLEAR_G = 0.13f;
    private static final float CLEAR_B = 0.15f;

    // ======================== 场景与相机 ========================

    private Scene scene;
    private final Camera camera = new Camera();

    // ======================== 程序与位置 ========================

    private int program;
    private int lineProgram;
    /** attribs[0]=aPos, [1]=aNormal, [2]=aColor */
    private final int[] attribs = new int[3];
    /** uniforms[0]=uMVP, [1]=uModel, [2]=uNormalMat, [3]=uSelected */
    private final int[] uniforms = new int[4];
    private int lAPosLoc, lAColorLoc, lUMVPLoc;

    // ======================== GL 缓冲区 ========================

    /** 每个场景物体的 GL 缓冲区 */
    private static class GLMesh {
        final int[] vbo = new int[1];
        final int[] ibo = new int[1];
        int indexCount = 0;
        int indexType = GLES20.GL_UNSIGNED_SHORT;
        boolean dirty = true;
    }
    private final List<GLMesh> meshes = new ArrayList<>();
    private boolean allDirty = true;
    private final int[] lineVbo = new int[1];
    private boolean useIntIndices = false;

    // ======================== 工具 ========================

    public enum Tool { SELECT, MOVE, ROTATE, SCALE, BRUSH }

    /** 笔刷类型: 材质涂抹 / 雕刻凸起 / 雕刻凹陷 */
    public enum BrushType { MATERIAL, SCULPT_RAISE, SCULPT_LOWER }

    /** 可视化模式: 决定顶点着色方式 */
    public enum VisMode {
        MATERIAL,   // 按材质ID着色
        NORMAL,     // 按法线方向着色
        AO,         // 按input2 (AO/粗糙度) 着色
        DETAIL,     // 按input3 (细节纹理) 着色
        MISC,       // 按input4 (其他数据) 着色
        WIREFRAME,  // 线框模式
        CHUNK,      // 分块边界
        CLOUD,      // 仅显示云数据
    }

    private Tool tool = Tool.SELECT;
    private int brushMaterial = 48;
    private float brushRadius = 3.0f;
    private BrushType brushType = BrushType.MATERIAL;
    private VisMode visMode = VisMode.MATERIAL;

    // ======================== 拾取/交互状态 ========================

    private int selectedAxis = -1; // Gizmo 轴
    private boolean dragging = false;
    private boolean brushing = false;
    private boolean hasMoved = false;
    private float lastTouchX, lastTouchY;
    private float startTouchX, startTouchY;
    private Vec3 lastDragPos = null;

    // ======================== 回调 ========================

    public interface Callback {
        void onSelectionChanged();
        void onObjectEdited();
    }
    private Callback callback;

    // ======================== 临时矩阵/向量 ========================

    private final float[] projMatrix = new float[16];
    private final float[] viewMatrix = new float[16];
    private final float[] vpMatrix = new float[16];
    private final float[] mvpMatrix = new float[16];
    private final float[] modelMatrix = new float[16];
    private final float[] invVP = new float[16];
    private final float[] nearNDC = new float[4];
    private final float[] farNDC = new float[4];
    private final float[] nearWorld = new float[4];
    private final float[] farWorld = new float[4];
    private final float[] tmpVec4 = new float[4];
    private final float[] brushModel = new float[16];

    private final Vec3 rayOrigin = new Vec3();
    private final Vec3 rayDir = new Vec3();
    private final Vec3 tmpVec3a = new Vec3();
    private final Vec3 tmpVec3b = new Vec3();
    private final Gizmo gizmo = new Gizmo();

    private int width = 1, height = 1;

    // ======================== 线段缓冲区 ========================

    private final FloatBuffer lineData = ByteBuffer
            .allocateDirect(MAX_LINE_VERTS * LINE_FLOATS_PER_VERTEX * 4)
            .order(ByteOrder.nativeOrder()).asFloatBuffer();
    private int lineVertCount = 0;

    // ======================== 生命周期方法 ========================

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        // 检测 GL_OES_element_index_uint 扩展
        String exts = GLES20.glGetString(GLES20.GL_EXTENSIONS);
        useIntIndices = exts != null && exts.contains("GL_OES_element_index_uint");

        // 编译主着色器
        program = ShaderUtil.createProgram(VERTEX_SHADER, FRAGMENT_SHADER);
        if (program != 0) {
            attribs[0] = GLES20.glGetAttribLocation(program, "aPos");
            attribs[1] = GLES20.glGetAttribLocation(program, "aNormal");
            attribs[2] = GLES20.glGetAttribLocation(program, "aColor");
            uniforms[0] = GLES20.glGetUniformLocation(program, "uMVP");
            uniforms[1] = GLES20.glGetUniformLocation(program, "uModel");
            uniforms[2] = GLES20.glGetUniformLocation(program, "uNormalMat");
            uniforms[3] = GLES20.glGetUniformLocation(program, "uSelected");
        }

        // 编译线段着色器
        lineProgram = ShaderUtil.createProgram(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER);
        if (lineProgram != 0) {
            lAPosLoc = GLES20.glGetAttribLocation(lineProgram, "aPos");
            lAColorLoc = GLES20.glGetAttribLocation(lineProgram, "aColor");
            lUMVPLoc = GLES20.glGetUniformLocation(lineProgram, "uMVP");
        }

        // 创建线段 VBO
        GLES20.glGenBuffers(1, lineVbo, 0);

        GLES20.glClearColor(CLEAR_R, CLEAR_G, CLEAR_B, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDepthFunc(GLES20.GL_LEQUAL);
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        width = Math.max(1, w);
        height = Math.max(1, h);
        GLES20.glViewport(0, 0, width, height);
        perspectiveM(projMatrix, 45.0f, (float) width / (float) height, 0.1f, 2000.0f);
    }

    @Override
    public void onDrawFrame(GL10 gl) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        if (scene == null) return;

        // 每帧更新透视投影 — 使用相机自适应裁剪面 (参照 SkyModelViewer)
        perspectiveM(projMatrix, camera.getFov(), (float) width / (float) height,
                camera.getNear(), camera.getFar());

        // 计算 VP 矩阵
        float[] view = camera.viewMatrix();
        Matrix.multiplyMM(vpMatrix, 0, projMatrix, 0, view, 0);

        // ---- 第 1 批线段: 地面网格 + 世界坐标轴 ----
        resetLines();
        buildGrid();
        buildAxes();
        drawLines();

        // ---- 物体 ----
        ensureMeshBuffers();
        drawObjects();

        // ---- 第 2 批线段: Gizmo + 笔刷圈 + 可视化辅助 ----
        resetLines();
        buildGizmo();
        buildBrushCircle();
        if (visMode == VisMode.WIREFRAME) buildWireframe();
        if (visMode == VisMode.CHUNK) buildChunkBounds();
        drawLines();

        // ---- 导航 Gizmo (Blender 风格, 右上角) ----
        drawNavGizmo();
    }

    // ======================== 线段构建 ========================

    private void resetLines() {
        lineVertCount = 0;
        lineData.clear();
    }

    private void addLine(float x1, float y1, float z1,
                         float x2, float y2, float z2,
                         float r, float g, float b) {
        if (lineVertCount + 2 > MAX_LINE_VERTS) return;
        lineData.put(x1); lineData.put(y1); lineData.put(z1);
        lineData.put(r);  lineData.put(g);  lineData.put(b);
        lineData.put(x2); lineData.put(y2); lineData.put(z2);
        lineData.put(r);  lineData.put(g);  lineData.put(b);
        lineVertCount += 2;
    }

    /** 用 lineProgram 画所有已添加的线段 */
    private void drawLines() {
        if (lineVertCount == 0 || lineProgram == 0) return;
        GLES20.glUseProgram(lineProgram);
        GLES20.glUniformMatrix4fv(lUMVPLoc, 1, false, vpMatrix, 0);

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, lineVbo[0]);
        lineData.position(0);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, lineVertCount * LINE_STRIDE,
                lineData, GLES20.GL_DYNAMIC_DRAW);

        GLES20.glEnableVertexAttribArray(lAPosLoc);
        GLES20.glVertexAttribPointer(lAPosLoc, 3, GLES20.GL_FLOAT, false, LINE_STRIDE, 0);
        GLES20.glEnableVertexAttribArray(lAColorLoc);
        GLES20.glVertexAttribPointer(lAColorLoc, 3, GLES20.GL_FLOAT, false, LINE_STRIDE, 12);

        GLES20.glDrawArrays(GLES20.GL_LINES, 0, lineVertCount);

        GLES20.glDisableVertexAttribArray(lAPosLoc);
        GLES20.glDisableVertexAttribArray(lAColorLoc);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);

        lineData.clear();
    }

    // ======================== 导航 Gizmo (Blender 风格) ========================

    private static final float GIZMO_RADIUS = 38f;
    private static final float GIZMO_MARGIN = 55f;
    private final float[] gizmoOrtho = new float[16];

    /** 绘制右上角导航 Gizmo: Blender 风格 3D 立方体 */
    private void drawNavGizmo() {
        if (lineProgram == 0) return;

        float cx = width - GIZMO_MARGIN;
        float cy = height - GIZMO_MARGIN;

        // 正交投影: 屏幕像素坐标
        Matrix.orthoM(gizmoOrtho, 0, 0, width, 0, height, -1, 1);

        // 从视图矩阵提取世界轴在视图空间的方向
        float[] view = camera.viewMatrix();

        // 立方体顶点 (±s)
        float s = 0.62f;
        float[][] cube = {
            {-s, -s, -s}, {s, -s, -s}, {s, s, -s}, {-s, s, -s},  // 后面
            {-s, -s,  s}, {s, -s,  s}, {s, s,  s}, {-s, s,  s}   // 前面
        };

        // 投影到 2D 屏幕空间 (使用视图矩阵旋转 + 透视效果)
        float[][] p = new float[8][2];
        float[] viewZ = new float[8];
        for (int i = 0; i < 8; i++) {
            float x = cube[i][0], y = cube[i][1], z = cube[i][2];
            float vx = view[0]*x + view[4]*y + view[8]*z;
            float vy = view[1]*x + view[5]*y + view[9]*z;
            viewZ[i] = view[2]*x + view[6]*y + view[10]*z;
            float scale = GIZMO_RADIUS / (1.0f - viewZ[i] * 0.2f);
            p[i][0] = cx + vx * scale;
            p[i][1] = cy + vy * scale;
        }

        resetLines();

        // 背景圆 (暗色)
        int segs = 28;
        for (int i = 0; i < segs; i++) {
            float a1 = i / (float) segs * (float) Math.PI * 2;
            float a2 = (i + 1) / (float) segs * (float) Math.PI * 2;
            addLine(
                cx + (float) Math.cos(a1) * GIZMO_RADIUS, cy + (float) Math.sin(a1) * GIZMO_RADIUS, 0,
                cx + (float) Math.cos(a2) * GIZMO_RADIUS, cy + (float) Math.sin(a2) * GIZMO_RADIUS, 0,
                0.12f, 0.12f, 0.14f);
        }

        // 立方体边 (12 条), 按轴向着色 + 前后亮度区分
        int[][] edges = {
            {0,1},{1,2},{2,3},{3,0},  // 后面
            {4,5},{5,6},{6,7},{7,4},  // 前面
            {0,4},{1,5},{2,6},{3,7}   // 连接边
        };

        for (int[] e : edges) {
            float dx = cube[e[1]][0] - cube[e[0]][0];
            float dy = cube[e[1]][1] - cube[e[0]][1];
            float dz = cube[e[1]][2] - cube[e[0]][2];
            float r, g, b;
            if (Math.abs(dx) > 0.1f) { r = 0.9f; g = 0.25f; b = 0.25f; }      // X 轴 - 红
            else if (Math.abs(dy) > 0.1f) { r = 0.25f; g = 0.9f; b = 0.35f; }  // Y 轴 - 绿
            else { r = 0.25f; g = 0.45f; b = 1.0f; }                            // Z 轴 - 蓝

            // 前面边亮, 后面边暗
            float avgVZ = (viewZ[e[0]] + viewZ[e[1]]) * 0.5f;
            float bright = avgVZ > 0 ? 1.0f : 0.35f;

            addLine(p[e[0]][0], p[e[0]][1], 0,
                    p[e[1]][0], p[e[1]][1], 0,
                    r * bright, g * bright, b * bright);
        }

        // 轴端标记 (X/Y/Z 正方向)
        float[][] axisDirs = {{1, 0, 0}, {0, 1, 0}, {0, 0, 1}};
        float[][] axisCols = {{0.95f, 0.3f, 0.3f}, {0.3f, 0.95f, 0.4f}, {0.3f, 0.5f, 1.0f}};
        for (int i = 0; i < 3; i++) {
            float x = axisDirs[i][0], y = axisDirs[i][1], z = axisDirs[i][2];
            float vx = view[0]*x + view[4]*y + view[8]*z;
            float vy = view[1]*x + view[5]*y + view[9]*z;
            float vz = view[2]*x + view[6]*y + view[10]*z;
            float scale = GIZMO_RADIUS / (1.0f - vz * 0.2f);
            float ex = cx + vx * scale;
            float ey = cy + vy * scale;
            drawGizmoAxisEnd(ex, ey, axisCols[i][0], axisCols[i][1], axisCols[i][2]);
        }

        // 中心点
        addLine(cx - 3, cy, 0, cx + 3, cy, 0, 0.85f, 0.85f, 0.85f);
        addLine(cx, cy - 3, 0, cx, cy + 3, 0, 0.85f, 0.85f, 0.85f);

        // 用正交投影绘制, 禁用深度测试
        GLES20.glUseProgram(lineProgram);
        GLES20.glUniformMatrix4fv(lUMVPLoc, 1, false, gizmoOrtho, 0);

        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, lineVbo[0]);
        lineData.position(0);
        GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, lineVertCount * LINE_STRIDE,
                lineData, GLES20.GL_DYNAMIC_DRAW);

        GLES20.glEnableVertexAttribArray(lAPosLoc);
        GLES20.glVertexAttribPointer(lAPosLoc, 3, GLES20.GL_FLOAT, false, LINE_STRIDE, 0);
        GLES20.glEnableVertexAttribArray(lAColorLoc);
        GLES20.glVertexAttribPointer(lAColorLoc, 3, GLES20.GL_FLOAT, false, LINE_STRIDE, 12);

        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glDrawArrays(GLES20.GL_LINES, 0, lineVertCount);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        GLES20.glDisableVertexAttribArray(lAPosLoc);
        GLES20.glDisableVertexAttribArray(lAColorLoc);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);

        lineData.clear();
    }

    private void drawGizmoAxisEnd(float x, float y, float r, float g, float b) {
        addLine(x - 3, y, 0, x + 3, y, 0, r, g, b);
        addLine(x, y - 3, 0, x, y + 3, 0, r, g, b);
    }

    /** 检查触摸是否在 Gizmo 区域内 (屏幕坐标, Y 向下) */
    public boolean isGizmoArea(float x, float y) {
        float cx = width - GIZMO_MARGIN;
        float cy = GIZMO_MARGIN; // 屏幕坐标 Y 向下 → 右上角
        float dx = x - cx;
        float dy = y - cy;
        return dx * dx + dy * dy < (GIZMO_RADIUS + 15) * (GIZMO_RADIUS + 15);
    }

    /** 处理 Gizmo 点击: 根据点击位置切换标准视角, 返回 true 表示已处理 */
    public boolean handleGizmoClick(float x, float y) {
        float cx = width - GIZMO_MARGIN;
        float cy_screen = GIZMO_MARGIN; // 屏幕坐标 (Y 向下)
        float dx = x - cx;
        float dy = -(y - cy_screen); // 转为 GL Y 向上
        float dist = (float) Math.sqrt(dx * dx + dy * dy);

        if (dist > GIZMO_RADIUS + 15) return false;

        if (dist < 14) {
            camera.setViewFront();
            return true;
        }

        // 从视图矩阵提取轴方向
        float[] view = camera.viewMatrix();
        float[][] axes = {
            {view[0], view[1]},  // X
            {view[4], view[5]},  // Y
            {view[8], view[9]}   // Z
        };

        float nx = dx / dist;
        float ny = dy / dist;

        float bestDot = -2;
        int bestAxis = -1;
        boolean positive = true;

        for (int i = 0; i < 3; i++) {
            float alen = (float) Math.sqrt(axes[i][0] * axes[i][0] + axes[i][1] * axes[i][1]);
            if (alen < 0.001f) continue;
            float ax = axes[i][0] / alen;
            float ay = axes[i][1] / alen;

            float dotP = nx * ax + ny * ay;
            float dotN = -dotP;

            if (dotP > bestDot) { bestDot = dotP; bestAxis = i; positive = true; }
            if (dotN > bestDot) { bestDot = dotN; bestAxis = i; positive = false; }
        }

        if (bestAxis >= 0) {
            switch (bestAxis) {
                case 0: if (positive) camera.setViewRight(); else camera.setViewLeft(); break;
                case 1: if (positive) camera.setViewTop(); else camera.setViewBottom(); break;
                case 2: if (positive) camera.setViewBack(); else camera.setViewFront(); break;
            }
            return true;
        }
        return false;
    }

    private void buildGrid() {
        final float grey = 0.22f;
        final float ext = 10.0f;
        for (int i = -10; i <= 10; i++) {
            float v = i;
            // 沿 X 方向的线
            addLine(-ext, 0, v, ext, 0, v, grey, grey, grey);
            // 沿 Z 方向的线
            addLine(v, 0, -ext, v, 0, ext, grey, grey, grey);
        }
    }

    private void buildAxes() {
        final float len = 3.0f;
        // X = 红
        addLine(0, 0, 0, len, 0, 0, 0.9f, 0.2f, 0.2f);
        // Y = 绿
        addLine(0, 0, 0, 0, len, 0, 0.2f, 0.9f, 0.3f);
        // Z = 蓝
        addLine(0, 0, 0, 0, 0, len, 0.2f, 0.4f, 1.0f);
    }

    private void buildGizmo() {
        if (scene == null || scene.selectedObject() == null) return;
        if (tool != Tool.MOVE && tool != Tool.ROTATE && tool != Tool.SCALE) return;

        SceneObject obj = scene.selectedObject();
        float len = (float) (camera.distance * 0.12);
        float px = obj.position.x, py = obj.position.y, pz = obj.position.z;

        Vec3 cx = Gizmo.axisColor(Gizmo.X);
        Vec3 cy = Gizmo.axisColor(Gizmo.Y);
        Vec3 cz = Gizmo.axisColor(Gizmo.Z);

        addLine(px, py, pz, px + len, py, pz, cx.x, cx.y, cx.z);
        addLine(px, py, pz, px, py + len, pz, cy.x, cy.y, cy.z);
        addLine(px, py, pz, px, py, pz + len, cz.x, cz.y, cz.z);
    }

    private void buildBrushCircle() {
        if (tool != Tool.BRUSH || scene == null || scene.selectedObject() == null) return;
        SceneObject obj = scene.selectedObject();
        float px = obj.position.x, py = obj.position.y, pz = obj.position.z;
        float r, g, b;
        if (brushType == BrushType.SCULPT_RAISE) {
            r = 1.0f; g = 0.6f; b = 0.1f; // 橙色 = 凸起
        } else if (brushType == BrushType.SCULPT_LOWER) {
            r = 0.2f; g = 0.5f; b = 1.0f; // 蓝色 = 凹陷
        } else {
            float[] col = MaterialTable.instance().color(brushMaterial, null);
            r = col[0]; g = col[1]; b = col[2];
        }
        int segs = 32;
        float prevX = px + brushRadius * (float) Math.cos(0);
        float prevZ = pz + brushRadius * (float) Math.sin(0);
        for (int i = 1; i <= segs; i++) {
            float t = i / (float) segs * (float) Math.PI * 2;
            float curX = px + brushRadius * (float) Math.cos(t);
            float curZ = pz + brushRadius * (float) Math.sin(t);
            addLine(prevX, py, prevZ, curX, py, curZ, r, g, b);
            prevX = curX;
            prevZ = curZ;
        }
    }

    /** 线框模式: 绘制选中物体的所有三角边 */
    private void buildWireframe() {
        if (scene == null) return;
        float[] m = null;
        for (int i = 0; i < scene.objects.size(); i++) {
            SceneObject obj = scene.objects.get(i);
            if (obj.vertices.isEmpty() || obj.indices.isEmpty()) continue;
            m = obj.modelMatrix(brushModel);
            float cr = (i == scene.selected) ? 0.9f : 0.4f;
            float cg = (i == scene.selected) ? 0.8f : 0.4f;
            float cb = (i == scene.selected) ? 0.2f : 0.45f;
            for (int j = 0; j + 2 < obj.indices.size(); j += 3) {
                int a = obj.indices.get(j), b = obj.indices.get(j + 1), c = obj.indices.get(j + 2);
                Vec3 va = obj.vertices.get(a).position;
                Vec3 vb = obj.vertices.get(b).position;
                Vec3 vc = obj.vertices.get(c).position;
                float ax = m[0]*va.x + m[4]*va.y + m[8]*va.z + m[12];
                float ay = m[1]*va.x + m[5]*va.y + m[9]*va.z + m[13];
                float az = m[2]*va.x + m[6]*va.y + m[10]*va.z + m[14];
                float bx = m[0]*vb.x + m[4]*vb.y + m[8]*vb.z + m[12];
                float by = m[1]*vb.x + m[5]*vb.y + m[9]*vb.z + m[13];
                float bz = m[2]*vb.x + m[6]*vb.y + m[10]*vb.z + m[14];
                float cx = m[0]*vc.x + m[4]*vc.y + m[8]*vc.z + m[12];
                float cy = m[1]*vc.x + m[5]*vc.y + m[9]*vc.z + m[13];
                float cz = m[2]*vc.x + m[6]*vc.y + m[10]*vc.z + m[14];
                addLine(ax, ay, az, bx, by, bz, cr, cg, cb);
                addLine(bx, by, bz, cx, cy, cz, cr, cg, cb);
                addLine(cx, cy, cz, ax, ay, az, cr, cg, cb);
            }
        }
    }

    /** 分块边界: 绘制每个 chunk 的 AABB 包围盒 */
    private void buildChunkBounds() {
        if (scene == null) return;
        for (int i = 0; i < scene.objects.size(); i++) {
            SceneObject obj = scene.objects.get(i);
            if (obj.kind != ObjKind.MeshesTerrain) continue;
            // 简化: 用顶点 AABB 代替 chunk AABB
            if (obj.vertices.isEmpty()) continue;
            float[] m = obj.modelMatrix(brushModel);
            float minX = Float.MAX_VALUE, minY = Float.MAX_VALUE, minZ = Float.MAX_VALUE;
            float maxX = -Float.MAX_VALUE, maxY = -Float.MAX_VALUE, maxZ = -Float.MAX_VALUE;
            for (MeshVertex v : obj.vertices) {
                float wx = m[0]*v.position.x + m[4]*v.position.y + m[8]*v.position.z + m[12];
                float wy = m[1]*v.position.x + m[5]*v.position.y + m[9]*v.position.z + m[13];
                float wz = m[2]*v.position.x + m[6]*v.position.y + m[10]*v.position.z + m[14];
                if (wx < minX) minX = wx; if (wx > maxX) maxX = wx;
                if (wy < minY) minY = wy; if (wy > maxY) maxY = wy;
                if (wz < minZ) minZ = wz; if (wz > maxZ) maxZ = wz;
            }
            float r = 0.2f, g = 0.9f, b = 0.3f;
            // 8 个顶点 12 条边
            float[][] c = {
                {minX, minY, minZ}, {maxX, minY, minZ},
                {maxX, maxY, minZ}, {minX, maxY, minZ},
                {minX, minY, maxZ}, {maxX, minY, maxZ},
                {maxX, maxY, maxZ}, {minX, maxY, maxZ}
            };
            int[][] edges = {{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
            for (int[] e : edges) {
                addLine(c[e[0]][0], c[e[0]][1], c[e[0]][2],
                        c[e[1]][0], c[e[1]][1], c[e[1]][2], r, g, b);
            }
        }
    }

    // ======================== VBO/IBO 管理 ========================

    private void ensureMeshBuffers() {
        if (scene == null || program == 0) return;
        int n = scene.objects.size();

        // 调整 meshes 列表大小
        while (meshes.size() < n) meshes.add(new GLMesh());
        while (meshes.size() > n) {
            GLMesh m = meshes.remove(meshes.size() - 1);
            if (m.vbo[0] != 0) GLES20.glDeleteBuffers(1, m.vbo, 0);
            if (m.ibo[0] != 0) GLES20.glDeleteBuffers(1, m.ibo, 0);
        }

        for (int i = 0; i < n; i++) {
            GLMesh gm = meshes.get(i);
            if (!allDirty && !gm.dirty) continue;
            gm.dirty = false;

            SceneObject obj = scene.objects.get(i);
            int vc = obj.vertices.size();
            int ic = obj.indices.size();
            if (vc == 0 || ic == 0) {
                gm.indexCount = 0;
                continue;
            }

            // 构建顶点数据: pos(3) + normal(3) + color(3) = 9 floats
            FloatBuffer vb = ByteBuffer.allocateDirect(vc * VERTEX_STRIDE)
                    .order(ByteOrder.nativeOrder()).asFloatBuffer();

            float[] mc = null;
            if (obj.kind != ObjKind.MeshesTerrain) {
                mc = MaterialTable.instance().color(obj.baseMaterialId, null);
            }

            for (int j = 0; j < vc; j++) {
                MeshVertex v = obj.vertices.get(j);
                // position (model space)
                vb.put(v.position.x);
                vb.put(v.position.y);
                vb.put(v.position.z);
                // normal (model space)
                vb.put(v.normal[0]);
                vb.put(v.normal[1]);
                vb.put(v.normal[2]);
                // color — 根据 VisMode 选择着色方式
                float r, g, b;
                switch (visMode) {
                    case NORMAL:
                        r = (v.normal[0] + 1f) * 0.5f;
                        g = (v.normal[1] + 1f) * 0.5f;
                        b = (v.normal[2] + 1f) * 0.5f;
                        break;
                    case AO:
                        r = v.input2[0]; g = v.input2[1]; b = v.input2[2];
                        break;
                    case DETAIL:
                        r = v.input3[0]; g = v.input3[1]; b = v.input3[2];
                        break;
                    case MISC:
                        r = v.input4[0]; g = v.input4[1]; b = v.input4[2];
                        break;
                    case CLOUD:
                        // 云模式: 云材质(80)显示亮白, 其他暗灰
                        if (obj.kind == ObjKind.MeshesTerrain) {
                            // 用加权混合判断是否为云材质
                            int best = 0; float bw = -1;
                            for (int k = 0; k < 4; k++) {
                                if (v.materialWeights[k] > bw) { bw = v.materialWeights[k]; best = k; }
                            }
                            int matId = v.materialIds[best];
                            if (matId == 80) { r = 0.9f; g = 0.95f; b = 1.0f; }
                            else { r = 0.15f; g = 0.15f; b = 0.17f; }
                        } else {
                            r = 0.3f; g = 0.3f; b = 0.32f;
                        }
                        break;
                    default: // MATERIAL — 纯顶点权重混合 (参照 SkyModelViewer LevelMeshesReader)
                        if (obj.kind == ObjKind.MeshesTerrain) {
                            // 顶点为主: 4 槽材质按权重加权平均, 产生材质间渐变
                            Vec3 c = SceneObject.vertexColor(v, tmpVec3a);
                            r = c.x; g = c.y; b = c.z;
                        } else {
                            r = mc[0]; g = mc[1]; b = mc[2];
                        }
                        break;
                }
                vb.put(r); vb.put(g); vb.put(b);
            }
            vb.position(0);

            // 构建索引数据
            int indexType;
            if (useIntIndices) {
                IntBuffer ib = ByteBuffer.allocateDirect(ic * 4)
                        .order(ByteOrder.nativeOrder()).asIntBuffer();
                for (int idx : obj.indices) ib.put(idx);
                ib.position(0);

                if (gm.vbo[0] == 0) GLES20.glGenBuffers(1, gm.vbo, 0);
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo[0]);
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vc * VERTEX_STRIDE, vb, GLES20.GL_STATIC_DRAW);

                if (gm.ibo[0] == 0) GLES20.glGenBuffers(1, gm.ibo, 0);
                GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo[0]);
                GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, ic * 4, ib, GLES20.GL_STATIC_DRAW);

                indexType = GLES20.GL_UNSIGNED_INT;
            } else {
                ShortBuffer ib = ByteBuffer.allocateDirect(ic * 2)
                        .order(ByteOrder.nativeOrder()).asShortBuffer();
                for (int idx : obj.indices) ib.put((short) Math.min(idx, 65535));
                ib.position(0);

                if (gm.vbo[0] == 0) GLES20.glGenBuffers(1, gm.vbo, 0);
                GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo[0]);
                GLES20.glBufferData(GLES20.GL_ARRAY_BUFFER, vc * VERTEX_STRIDE, vb, GLES20.GL_STATIC_DRAW);

                if (gm.ibo[0] == 0) GLES20.glGenBuffers(1, gm.ibo, 0);
                GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo[0]);
                GLES20.glBufferData(GLES20.GL_ELEMENT_ARRAY_BUFFER, ic * 2, ib, GLES20.GL_STATIC_DRAW);

                indexType = GLES20.GL_UNSIGNED_SHORT;
            }
            gm.indexCount = ic;
            gm.indexType = indexType;
        }
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0);
        allDirty = false;
    }

    // ======================== 物体绘制 ========================

    private void drawObjects() {
        if (program == 0 || scene == null) return;
        GLES20.glUseProgram(program);

        int n = Math.min(scene.objects.size(), meshes.size());
        for (int i = 0; i < n; i++) {
            GLMesh gm = meshes.get(i);
            if (gm.indexCount == 0) continue;
            SceneObject obj = scene.objects.get(i);

            float[] model = obj.modelMatrix(modelMatrix);
            Matrix.multiplyMM(mvpMatrix, 0, vpMatrix, 0, model, 0);

            GLES20.glUniformMatrix4fv(uniforms[0], 1, false, mvpMatrix, 0); // uMVP
            GLES20.glUniformMatrix4fv(uniforms[1], 1, false, model, 0);     // uModel
            GLES20.glUniformMatrix4fv(uniforms[2], 1, false, model, 0);     // uNormalMat = model
            GLES20.glUniform1i(uniforms[3], (i == scene.selected) ? 1 : 0);  // uSelected

            GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, gm.vbo[0]);
            GLES20.glEnableVertexAttribArray(attribs[0]);
            GLES20.glVertexAttribPointer(attribs[0], 3, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 0);
            GLES20.glEnableVertexAttribArray(attribs[1]);
            GLES20.glVertexAttribPointer(attribs[1], 3, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 12);
            GLES20.glEnableVertexAttribArray(attribs[2]);
            GLES20.glVertexAttribPointer(attribs[2], 3, GLES20.GL_FLOAT, false, VERTEX_STRIDE, 24);

            GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, gm.ibo[0]);
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, gm.indexCount, gm.indexType, 0);
        }

        GLES20.glDisableVertexAttribArray(attribs[0]);
        GLES20.glDisableVertexAttribArray(attribs[1]);
        GLES20.glDisableVertexAttribArray(attribs[2]);
        GLES20.glBindBuffer(GLES20.GL_ARRAY_BUFFER, 0);
        GLES20.glBindBuffer(GLES20.GL_ELEMENT_ARRAY_BUFFER, 0);
    }

    // ======================== 射线与拾取 ========================

    /** 屏幕坐标 → 世界射线 (结果存入 rayOrigin / rayDir) */
    private void screenToRay(float x, float y) {
        float ndcX = 2.0f * x / width - 1.0f;
        float ndcY = 1.0f - 2.0f * y / height;

        Matrix.invertM(invVP, 0, vpMatrix, 0);

        nearNDC[0] = ndcX; nearNDC[1] = ndcY; nearNDC[2] = -1.0f; nearNDC[3] = 1.0f;
        farNDC[0] = ndcX;  farNDC[1] = ndcY;  farNDC[2] = 1.0f;  farNDC[3] = 1.0f;

        Matrix.multiplyMV(nearWorld, 0, invVP, 0, nearNDC, 0);
        Matrix.multiplyMV(farWorld, 0, invVP, 0, farNDC, 0);

        float nw = nearWorld[3] != 0 ? nearWorld[3] : 1.0f;
        float fw = farWorld[3] != 0 ? farWorld[3] : 1.0f;

        float nx = nearWorld[0] / nw, ny = nearWorld[1] / nw, nz = nearWorld[2] / nw;
        float fx = farWorld[0] / fw, fy = farWorld[1] / fw, fz = farWorld[2] / fw;

        // 射线原点取相机位置
        float[] camPos = camera.position();
        rayOrigin.set(camPos[0], camPos[1], camPos[2]);
        rayDir.set(fx - nx, fy - ny, fz - nz);
        rayDir.normalize();
    }

    /** 射线-球求交, 返回物体索引, -1 表示未命中 */
    private int pickObject(Vec3 origin, Vec3 dir) {
        if (scene == null) return -1;
        int best = -1;
        float bestT = Float.MAX_VALUE;
        for (int i = 0; i < scene.objects.size(); i++) {
            SceneObject obj = scene.objects.get(i);
            float ocx = origin.x - obj.position.x;
            float ocy = origin.y - obj.position.y;
            float ocz = origin.z - obj.position.z;
            float r = obj.pickRadius();
            float b = ocx * dir.x + ocy * dir.y + ocz * dir.z;
            float c = ocx * ocx + ocy * ocy + ocz * ocz - r * r;
            float disc = b * b - c;
            if (disc < 0) continue;
            float sq = (float) Math.sqrt(disc);
            float t = -b - sq;
            if (t < 0) t = -b + sq;
            if (t > 0 && t < bestT) {
                bestT = t;
                best = i;
            }
        }
        return best;
    }

    /**
     * 笔刷操作 — 使用射线-顶点距离法 (不依赖包围球求交)。
     * 对选中物体的每个顶点: 变换到世界空间 → 计算到射线的垂直距离 →
     * 若距离 < brushRadius 则应用笔刷效果 (带衰减)。
     */
    private void applyBrush(Vec3 origin, Vec3 dir) {
        if (scene == null || scene.selectedObject() == null) return;
        SceneObject obj = scene.selectedObject();
        float[] m = obj.modelMatrix(brushModel);
        float r2 = brushRadius * brushRadius;
        boolean changed = false;

        // 模型空间缩放 (用于雕刻时将世界偏移转回模型空间)
        float sx = (float) Math.sqrt(m[0] * m[0] + m[1] * m[1] + m[2] * m[2]);
        float sy = (float) Math.sqrt(m[4] * m[4] + m[5] * m[5] + m[6] * m[6]);
        float sz = (float) Math.sqrt(m[8] * m[8] + m[9] * m[9] + m[10] * m[10]);
        if (sx < 1e-6f) sx = 1;
        if (sy < 1e-6f) sy = 1;
        if (sz < 1e-6f) sz = 1;

        for (int vi = 0; vi < obj.vertices.size(); vi++) {
            MeshVertex v = obj.vertices.get(vi);
            // 顶点 → 世界空间
            float lx = v.position.x, ly = v.position.y, lz = v.position.z;
            float wx = m[0] * lx + m[4] * ly + m[8]  * lz + m[12];
            float wy = m[1] * lx + m[5] * ly + m[9]  * lz + m[13];
            float wz = m[2] * lx + m[6] * ly + m[10] * lz + m[14];

            // 顶点到射线的垂直距离
            // proj = dot(vtx - origin, dir)
            float px = wx - origin.x;
            float py = wy - origin.y;
            float pz = wz - origin.z;
            float t = px * dir.x + py * dir.y + pz * dir.z;
            if (t < 0) continue; // 在相机后面, 跳过

            // 射线上最近点
            float clX = origin.x + dir.x * t;
            float clY = origin.y + dir.y * t;
            float clZ = origin.z + dir.z * t;
            float dx = wx - clX;
            float dy = wy - clY;
            float dz = wz - clZ;
            float dist2 = dx * dx + dy * dy + dz * dz;
            if (dist2 > r2) continue;

            float dist = (float) Math.sqrt(dist2);
            float falloff = 1.0f - dist / brushRadius;
            falloff = falloff * falloff; // 二次衰减

            if (brushType == BrushType.MATERIAL) {
                // 平滑材质混合: 按衰减将新材质混入现有权重 (产生渐变过渡)
                float blend = falloff * 0.6f;  // 混合强度

                // 先减少所有现有权重
                for (int k = 0; k < 4; k++) {
                    v.materialWeights[k] *= (1.0f - blend);
                }

                // 找到新材质的槽位: 已存在则累加, 否则替换权重最小的槽
                int slot = -1;
                float minW = Float.MAX_VALUE;
                for (int k = 0; k < 4; k++) {
                    if (v.materialIds[k] == brushMaterial) { slot = k; break; }
                    if (v.materialWeights[k] < minW) { minW = v.materialWeights[k]; slot = k; }
                }
                v.materialIds[slot] = brushMaterial;
                v.materialWeights[slot] += blend;

                // 归一化权重 (确保 4 个权重之和 = 1.0, 避免着色器 coverage 异常)
                float wsum = v.materialWeights[0] + v.materialWeights[1] +
                             v.materialWeights[2] + v.materialWeights[3];
                if (wsum > 0.001f) {
                    float inv = 1.0f / wsum;
                    for (int k = 0; k < 4; k++) {
                        v.materialWeights[k] *= inv;
                    }
                }

                if (obj.kind != ObjKind.MeshesTerrain) {
                    obj.baseMaterialId = brushMaterial;
                }
                // subchunk 在导出时由 MeshesExporter 用活跃区块算法重建
                // (保持原始三角形顺序, 每个材质的连续三角形范围一个 subchunk)
            } else {
                // 雕刻凸起/凹陷: 沿法线移动顶点
                float direction = (brushType == BrushType.SCULPT_RAISE) ? 1.0f : -1.0f;
                float strength = 0.15f * direction * falloff;

                float nx = v.normal[0], ny = v.normal[1], nz = v.normal[2];
                float nlen = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
                if (nlen > 1e-6f) { nx /= nlen; ny /= nlen; nz /= nlen; }
                else { nx = 0; ny = 1; nz = 0; }

                v.position.x += nx * strength / sx;
                v.position.y += ny * strength / sy;
                v.position.z += nz * strength / sz;
                // 注意: 雕刻后导出时会更新 chunk AABB, 确保碰撞检测覆盖新位置
            }
            changed = true;
        }

        if (changed) {
            obj.vertexModified = true;
            if (scene.selected >= 0 && scene.selected < meshes.size()) {
                meshes.get(scene.selected).dirty = true;
            }
            if (callback != null) callback.onObjectEdited();
        }
    }

    // ======================== 触摸事件 ========================

    public void onTouchDown(float x, float y) {
        lastTouchX = x;
        lastTouchY = y;
        startTouchX = x;
        startTouchY = y;
        dragging = false;
        brushing = false;
        hasMoved = false;

        if (tool == Tool.BRUSH) {
            screenToRay(x, y);
            // 笔刷模式: 自动拾取物体 (如果没有选中, 或点中了别的物体)
            if (scene != null) {
                int picked = pickObject(rayOrigin, rayDir);
                if (picked >= 0 && picked != scene.selected) {
                    scene.selected = picked;
                    if (callback != null) callback.onSelectionChanged();
                }
            }
            // 有选中物体时应用笔刷
            if (scene != null && scene.selectedObject() != null) {
                brushing = true;
                applyBrush(rayOrigin, rayDir);
            }
            return;
        }

        // Gizmo 拾取 (MOVE / ROTATE / SCALE 模式下有选中物体时)
        if (tool != Tool.SELECT && scene != null && scene.selectedObject() != null) {
            screenToRay(x, y);
            SceneObject obj = scene.selectedObject();
            float thr = (float) (camera.distance * 0.06);
            tmpVec3a.set(obj.position.x, obj.position.y, obj.position.z);
            selectedAxis = gizmo.pickAxis(rayOrigin, rayDir, tmpVec3a, thr);
            if (selectedAxis != Gizmo.NONE) {
                dragging = true;
                gizmo.beginDrag(tmpVec3a);
                lastDragPos = null;
            }
        }
    }

    public void onTouchMove(float x, float y) {
        float dx = x - lastTouchX;
        float dy = y - lastTouchY;

        float totalDx = x - startTouchX;
        float totalDy = y - startTouchY;
        if (totalDx * totalDx + totalDy * totalDy > 25.0f) hasMoved = true;

        lastTouchX = x;
        lastTouchY = y;

        if (brushing) {
            screenToRay(x, y);
            applyBrush(rayOrigin, rayDir);
            return;
        }

        if (dragging && scene != null && scene.selectedObject() != null) {
            screenToRay(x, y);
            SceneObject obj = scene.selectedObject();
            switch (tool) {
                case MOVE: {
                    Vec3 np = gizmo.dragMove(selectedAxis, rayOrigin, rayDir, null);
                    obj.position.set(np);
                    break;
                }
                case SCALE: {
                    tmpVec3a.set(obj.position.x, obj.position.y, obj.position.z);
                    float s = gizmo.dragScale(selectedAxis, rayOrigin, rayDir, tmpVec3a);
                    obj.scale.set(s, s, s);
                    break;
                }
                case ROTATE: {
                    Vec3 np = gizmo.dragMove(selectedAxis, rayOrigin, rayDir, tmpVec3b);
                    if (lastDragPos == null) lastDragPos = new Vec3(np);
                    Vec3 axisV = Gizmo.axisV(selectedAxis);
                    Vec3.sub(np, lastDragPos, tmpVec3a);
                    float signedDelta = Vec3.dot(tmpVec3a, axisV);
                    float rotAmount = signedDelta * 30.0f;
                    switch (selectedAxis) {
                        case Gizmo.X: obj.rotation.x += rotAmount; break;
                        case Gizmo.Y: obj.rotation.y += rotAmount; break;
                        case Gizmo.Z: obj.rotation.z += rotAmount; break;
                    }
                    lastDragPos.set(np);
                    break;
                }
                default:
                    break;
            }
            if (callback != null) callback.onObjectEdited();
            return;
        }

        // 非工具拖拽: 旋转视角
        camera.orbit(dx, dy);
    }

    public void onTouchUp() {
        // 点击(无明显移动) 且非拖拽/非笔刷操作 → 选择物体
        // 笔刷模式下如果没刷到东西(brushing=false)也允许选择
        if (!hasMoved && !dragging && !brushing && scene != null) {
            screenToRay(startTouchX, startTouchY);
            int picked = pickObject(rayOrigin, rayDir);
            scene.selected = picked; // -1 表示取消选择
            if (callback != null) callback.onSelectionChanged();
        }
        dragging = false;
        brushing = false;
        selectedAxis = -1;
        hasMoved = false;
    }

    /** 双指缩放: factor = 1/scaleFactor, < 1 = 张开 = 放大 */
    public void onZoom(float factor) {
        camera.zoom(factor);
    }

    /** 双指平移视角 */
    public void onPan(float dx, float dy) {
        camera.pan(dx, dy);
    }

    // ======================== 公开接口 ========================

    public void setScene(Scene scene) {
        this.scene = scene;
        allDirty = true;
    }

    public Scene getScene() { return scene; }
    public Camera getCamera() { return camera; }

    public void setCallback(Callback callback) {
        this.callback = callback;
    }

    public void setTool(Tool tool) {
        this.tool = tool;
        dragging = false;
        brushing = false;
        selectedAxis = -1;
    }

    public Tool getTool() { return tool; }

    public void setBrushMaterial(int id) { this.brushMaterial = id; }
    public int getBrushMaterial() { return brushMaterial; }

    public void setBrushType(BrushType bt) { this.brushType = bt; }
    public BrushType getBrushType() { return brushType; }

    public void setBrushRadius(float r) { this.brushRadius = Math.max(0.1f, r); }
    public float getBrushRadius() { return brushRadius; }

    public void setVisMode(VisMode vm) {
        this.visMode = vm;
        allDirty = true;
    }
    public VisMode getVisMode() { return visMode; }

    public void markDirty() {
        allDirty = true;
    }

    public void markDirty(int index) {
        if (index >= 0 && index < meshes.size()) {
            meshes.get(index).dirty = true;
        }
    }

    // ======================== 辅助 ========================

    /** 手动构建透视投影矩阵 (android.opengl.Matrix 无 perspectiveM) */
    private static void perspectiveM(float[] m, float fovY, float aspect, float near, float far) {
        float f = (float) (1.0 / Math.tan(Math.toRadians(fovY) * 0.5));
        m[0] = f / aspect;  m[1] = 0;  m[2] = 0;                               m[3] = 0;
        m[4] = 0;          m[5] = f;  m[6] = 0;                               m[7] = 0;
        m[8] = 0;          m[9] = 0;  m[10] = (far + near) / (near - far);   m[11] = -1;
        m[12] = 0;         m[13] = 0; m[14] = 2 * far * near / (near - far);  m[15] = 0;
    }
}
